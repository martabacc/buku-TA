# [Lelangapa : Online Auction Platform](https://lelangapa.com)
Conducted as a requirement to graduate - an undergraduate thesis project by Ronauli Silva
Informatics Engineering Department - Sepuluh Nopember Institute of Technology
Surabaya, Indonesia

# Key Features
- Realtime chatting & bidding!
- Automate sending confirmation email - using SMTP Relay
- Modularized & Compiled Javascripts Assets
- Using Amazon Web Services S3 for scalable storage
- CDN for assets & bandwith optimization
- Well-designed and future-visioned software

# Notable Points & Code Reviewers Notice

  - Built using Laravel, implementing Repository Pattern
  - Consists of 4-tiers as follows  : 
    -  Presentation tier : [html, css, js](https://github.com/ronayumik/web-app/tree/master/resources/views), , [jQuery scripts](https://github.com/ronayumik/web-app/tree/master/public), [vue.js + compiled using webpack](https://github.com/ronayumik/web-app/tree/master/resources/assets/js)
    -  Bussiness tier: [Controllers](https://github.com/ronayumik/web-app/tree/master/app/Http/Controllers) and Socket.io (stored in another git)
    -  Integration tier : [Repositories](https://github.com/ronayumik/web-app/tree/master/app/Repositories) and  [Services](https://github.com/ronayumik/web-app/tree/master/app/Services)
    -  Data Access Tier : [Models](https://github.com/ronayumik/web-app/tree/master/app/Services) 
  - Interacting with socket application, coded in vue.js and jquery scripts
  - Using JSON web token to secure socket connection
  - https-secured website
I'd like to thank you for your help. For faster process, I'd like to reccomend to only review these mentioned directories as those are the main logic of these apps.

### License
---
MIT


# **Matur nuwun :D**


[//]: # (These are reference links used in the body of this note and get stripped out when the markdown processor does its job. There is no need to format nicely because it shouldn't be seen. Thanks SO - http://stackoverflow.com/questions/4823468/store-comments-in-markdown-syntax)


   [dill]: <https://github.com/joemccann/dillinger>
   [git-repo-url]: <https://github.com/joemccann/dillinger.git>
   [john gruber]: <http://daringfireball.net>
   [df1]: <http://daringfireball.net/projects/markdown/>
   [markdown-it]: <https://github.com/markdown-it/markdown-it>
   [Ace Editor]: <http://ace.ajax.org>
   [node.js]: <http://nodejs.org>
   [Twitter Bootstrap]: <http://twitter.github.com/bootstrap/>
   [jQuery]: <http://jquery.com>
   [@tjholowaychuk]: <http://twitter.com/tjholowaychuk>
   [express]: <http://expressjs.com>
   [AngularJS]: <http://angularjs.org>
   [Gulp]: <http://gulpjs.com>

   [PlDb]: <https://github.com/joemccann/dillinger/tree/master/plugins/dropbox/README.md>
   [PlGh]: <https://github.com/joemccann/dillinger/tree/master/plugins/github/README.md>
   [PlGd]: <https://github.com/joemccann/dillinger/tree/master/plugins/googledrive/README.md>
   [PlOd]: <https://github.com/joemccann/dillinger/tree/master/plugins/onedrive/README.md>
   [PlMe]: <https://github.com/joemccann/dillinger/tree/master/plugins/medium/README.md>
   [PlGa]: <https://github.com/RahulHP/dillinger/blob/master/plugins/googleanalytics/README.md>

