webpackJsonp([3],{

/***/ 0:
/***/ (function(module, exports) {

throw new Error("Module build failed: SyntaxError: Unexpected token (19:12)\n\n\u001b[0m \u001b[90m 17 | \u001b[39m\u001b[90m */\u001b[39m\n \u001b[90m 18 | \u001b[39m\n\u001b[31m\u001b[1m>\u001b[22m\u001b[39m\u001b[90m 19 | \u001b[39m\u001b[36mconst\u001b[39m window\u001b[33m.\u001b[39m\u001b[33mVue\u001b[39m \u001b[33m=\u001b[39m require(\u001b[32m'vue'\u001b[39m)\u001b[33m;\u001b[39m\n \u001b[90m    | \u001b[39m            \u001b[31m\u001b[1m^\u001b[22m\u001b[39m\n \u001b[90m 20 | \u001b[39m\u001b[36mconst\u001b[39m window\u001b[33m.\u001b[39maxios \u001b[33m=\u001b[39m require(\u001b[32m'axios'\u001b[39m)\u001b[33m;\u001b[39m\n \u001b[90m 21 | \u001b[39mrequire(\u001b[32m'vue-resource'\u001b[39m)\u001b[33m;\u001b[39m\n \u001b[90m 22 | \u001b[39m\u001b[0m\n");

/***/ }),

/***/ 13:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(2);


/***/ }),

/***/ 2:
/***/ (function(module, exports, __webpack_require__) {


__webpack_require__(0);

/***/ })

},[13]);