

// require('./bootstrap');
Vue.component('inbox', require('./components/Inbox.vue'));
const inbox = new Vue({
    el: '#mapHere'
});
