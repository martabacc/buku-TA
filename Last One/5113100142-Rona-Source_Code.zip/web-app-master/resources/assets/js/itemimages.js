
Vue.component('itemimages', require('./components/ItemImage.vue'));
itemImage = new Vue({
    el: '.customtab'
});