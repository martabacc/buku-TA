<template>

    <div class="image product-imageblock" v-if="loaded">
        <div>
            <img :src="imgUrl"  class="img-responsive" />

            <div class="ribbon" v-if="isFavorited" @click.prevent="unFavorite(item)" >
                <div class="border-ribbon">
                </div>
                <i class="fa fa-heart"></i>
            </div>

            <div class="unribbon" v-else @click.prevent="favorite(item)">
                <div class="border-ribbon"></div>
                <i class="fa fa-heart-o"></i>
            </div>
        </div>

        <div class="caption product-detail">
            <h4 class="product-name"><strong>Rp. {{ numberWithCommas(price) }}</strong></h4>
            <h5>

                <span class="price-new">
                    {{ name }}
                    </span>
                <br>
                <span>{{ bid }}x penawaran</span>
            </h5>
            <p class="price product-price">

            </p>
        </div>
    </div>
</template>

<script>
    export default {
        props: ['item', 'favorited'],
        data: function() {
            return {
                isFavorited: '',
                imgUrl : 'https://vignette2.wikia.nocookie.net/okami/images/5/53/Unknown_copyright_symbol.png/revision/latest?cb=20130501193735',
                name : 'Lorem Ipsum',
                price : 0,
                highest_price : 0,
                user_name : 'John Doe',
                user_id : "Lorem Ipsum",
                bid: 0,
                loaded : false

            }
        },
        mounted() {
            this.isFavorited = this.isFavorite ? true : false;
        },
        created() {
            axios.get('ajax/item/snap/' + this.item).
                then(response => {
                 var result = response.data;
                var name = result.name;
                var price = result.price_now.bid_price;
                var bidcount = result.bid_count;
                var username = result.price_now.name;

                this.name = name;
                this.price = price;
                this.bid = bidcount;
                this.user_name = username;

                axios.get("get/img/item/" + this.item)
                    .then( response => {
                        if(response.data.replace(/\s+/g, '') != '' ){
                        var url =  "http://img-s7.lelangapa.com/" + response.data ;
                        this.imgUrl = url.replace(/\s+/g, '');
                        this.loaded = true;
                    }
                });

            });
        },
        computed: {
            isFavorite()
            {
                return this.favorited;
            }
        },
        methods: {
            favorite(item){
                axios.post('/ajax/favourite/'+item)
                    .then(response => this.isFavorited = true)
            .catch(response => console.log(response.data));
            },
            unFavorite(item) {
                axios.post('/ajax/favourite/un/'+item)
                    .then(response => this.isFavorited = false)
            .catch(response => console.log(response.data));
            },
            numberWithCommas(price){
                return price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
            }
        }
    }
</script>