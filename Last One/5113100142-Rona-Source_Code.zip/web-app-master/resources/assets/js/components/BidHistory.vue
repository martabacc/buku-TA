<template>
    <table class="table table-bordered">
        <th>
            <td class="text-center">#</td>
            <td class="text-left">Nama Barang</td>
            <td class="text-left">Penawaran <br> Status </td>
            <td class="text-left">Status Lelang</td>
            <td class="text-right">Waktu Lelang</td>
        </th>
        <tbody v-for="item in items">
            <tr v-bind:class="{ successRow : isWin } " >
                <td class="text-center">
                    <a :href="{{ urlShowItem(item.id_item) }}">
                        <img class="img-thumbnail" title="iPhone" alt="iPhone" src="image/product/2product50x59.jpg">
                    </a>
                </td>
                <td class="text-left">
                    <a :href="{{ urlShowItem(item.id">
                        {{ item.name }}
                    </a>
                </td>
                <td class="text-left">
                    Rp. {{ item.price_bid }}
                    <br>
                    {{ item.win_status ? 'Menang' : 'Tidak memenangkan penawaran' }}
                    <button v-show="submitReview(item.id) " class="btn btn-primary">Beri Review</button>
                    <button v-show="submitCoupon(item.id) " class="btn btn-primary">Masukkan Kupon</button>

                </td>
                <td class="text-left">
                    {{ bid->bid_status==-1 ? 'Sudah selesai' : 'Masih berjalan' }}
                </td>
                <td class="text-center">
                    {{ moment(((bid->max).split("+"))[0]).format('LLL') }}
                </td>
            </tr>
        </tbody>

    </table>

    <!--div submit review -->
    <div class="modal fade" id="submitReview" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                    <h4 class="modal-title" id="myModalLabel">Edit Item</h4>
                </div>
                <div class="modal-body">

                    <form method="POST" enctype="multipart/form-data" v-on:submit.prevent="updateItem(fillItem.id)">

                        <div class="form-group">
                            <label for="title">Title:</label>
                            <input type="text" name="title" class="form-control" v-model="fillItem.title" />
                            <span v-if="formErrorsUpdate['title']" class="error text-danger">@{{ formErrorsUpdate['title'] }}</span>
                        </div>

                        <div class="form-group">
                            <label for="title">Description:</label>
                            <textarea name="description" class="form-control" v-model="fillItem.description"></textarea>
                            <span v-if="formErrorsUpdate['description']" class="error text-danger">@{{ formErrorsUpdate['description'] }}</span>
                        </div>

                        <div class="form-group">
                            <button type="submit" class="btn btn-success">Submit</button>
                        </div>

                    </form>

                </div>
            </div>
        </div>
    </div>
</template>

<script>
    export default{
        data : function() {
            return {
                successRow : 'bg-success',
                lostUnfinishedRow : 'bg-warning',
                url:'https://testing.lelangapa.com/'
            }
        },
        ready : function(){
            this.fetchItemList();
        },
        methods : {
            fetchItemList: function() {
                this.$http.get('api/tasks').then(function (response) {
                    this.list = response.data
                });
            },

            submitCoupon: function(id) {
                axios.post('/ajax/favourite/'+item)
                    .then(response => this.isFavorited = true)
                .catch(response => console.log(response.data));
            },

            submitReview: function(id) {
                this.$http.get('api/task/' + id).then(function(response) {
                    this.task.id = response.data.id
                    this.task.body = response.data.body
                })
                this.$els.taskinput.focus()
                this.edit = true
            },
        }
    }
</script>