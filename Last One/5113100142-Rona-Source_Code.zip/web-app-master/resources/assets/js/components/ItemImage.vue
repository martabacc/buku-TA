<template>
    <div>
        <img :src="imgUrl"  class="img-responsive" />
    </div>
</template>

<script>
    export default {
        props: ['item'],

        data: function() {
            return {
                imgUrl : 'https://vignette2.wikia.nocookie.net/okami/images/5/53/Unknown_copyright_symbol.png/revision/latest?cb=20130501193735'
            }
        },
        created() {
            axios.get("get/img/item/" + this.item)
                .then( response => {
                    if(response.data.replace(/\s+/g, '') != '' ){
                    var url =  "http://img-s7.lelangapa.com/" + response.data ;
                    this.imgUrl = url.replace(/\s+/g, '');
                    console.log(this.imgUrl);
                }
            });
        }
    }
</script>