
<template>
    <ul class="friend-list table-hover table-responsive" v-if="conversations.length>0 && loaded">
        <li  v-for="(conv, index) in conversations">
            <a v-bind:href="getUrl(det[index].partner)" class="clearfix">
                <div class="col-sm-12">
                    <div class="col-sm-1">
                        <img src="https://www.1plusx.com/app/mu-plugins/all-in-one-seo-pack-pro/images/default-user-image.png" alt="" class="img-circle">
                    </div>
                    <div class="col-sm-11">
                        <div class="friend-name">
                            <strong>{{ conv.friend.name }}</strong>
                        </div>
                        <div class="last-message text-muted">
                            <!--i want to show last chat here-->
                            {{ det[index].msg }}
                        </div>
                        <small class="time text-muted">
                            <!-- i want to show the msg timestamp here-->
                            {{ det[index].sent }}
                        </small>
                        <small class="chat-alert text-muted">
                            <i v-if="det[index].isSender" class="fa fa-reply"></i>
                        </small>
                    </div>
                </div>
            </a>
        </li>
    </ul>
    <ul class="friend-list" v-else>
        <li>
            <div class="friend-name">
                No messages!
            </div>
        </li>
    </ul>
</template>

<script>
    export default
    {
        props: ['id'],
        data: function () {
            return {
                conversations: [],
                det : [],
                loaded : false
            }
        },
        created() {
            axios.get('/inbox/data')
                .then(response => {
                    //fetching conversations id and its detail

                    this.conversations = response.data;

                    var promises = [];

                    response.data.forEach(conv => {
                        promises.push(
                            axios.post('/inbox/lastDetail',{
                                room : conv.room
                            })
                        )
                    });

                    axios.all(promises).then( results => {

                        this.det = results.map(result => result.data);
                        this.loaded = true;
                    })
            });
        },
        methods: {
            getUrl(id){
                return ("https://lelangapa.com/chat/" + id);
            }
        }
    }
</script>