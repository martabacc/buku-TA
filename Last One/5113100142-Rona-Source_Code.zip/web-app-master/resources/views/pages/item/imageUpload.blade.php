@extends('layouts.general')

@section('page_title')

@endsection

@section('content')

    <div class="container">
        <div class="row">

            @include('includes.navbar')
            @include('includes.item-navbar')

            <div id="content" class="col-sm-9">

                <div class="row">
                    <div class="col-sm-12" id="content">
                        <h1>{{ trans('item.sell_new_item') }}</h1>

                        <form class="form-horizontal" enctype="multipart/form-data" method="post" action="">
                            <fieldset id="account">
                                <h3>{{ trans('item.upload_item_image') }}</h3>
                                <div class="form-group required">
                                    <label for="exampleInputFile"  class="col-sm-2 control-label">{{ trans('item.item_picture') }}</label>
                                    <div class="col-sm-10">
                                        <input id="input-image-1" name="image[]" type="file" class="file-loading" accept="image/*" multiple>
                                    </div>
                                </div>
                            </fieldset>
                        </form>
                    </div>


                </div>
            </div>

            {{--modal to show --}}
            <div id="kv-success-modal" class="modal fade">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <h4 class="modal-title">Yippee!</h4>
                        </div>
                        <div id="kv-success-box" class="modal-body">
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <script type="text/javascript">

        $("#input-image-1").fileinput({
//            ngakak validasi di javascript -_-
            uploadUrl: "{{ url('item/image') }}",
            allowedFileExtensions: ["jpg", "png", "gif"],
            maxImageWidth: 200,
            maxFileCount: 5,
            resizeImage: true,
            dropZoneTitle : 'Drag and drop file gambar disini ..',
            showCaption : false,
//            showBrowse: false,
            mainClass : 'col-sm-12 file-caption-main',
        }).on('filepreupload', function(e) {
            $('#kv-success-box').html('');
        }).on('fileerror', function(event, data, msg) {
            console.log(data.id);
            console.log(data.index);
            console.log(data.file);
            console.log(data.reader);
            console.log(data.files);
            // get message
            alert(msg);
        }).on('fileuploaded', function(event, data) {
            $('#kv-success-box').append(data.response.link);
            $('#kv-success-modal').modal('show');
        });
    </script>
@endsection


