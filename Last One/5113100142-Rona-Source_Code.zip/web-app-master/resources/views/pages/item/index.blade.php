@extends('layouts.general')

@section('page_title')

@endsection

@section('content')

    @include('includes.navbar')

    <div class="row" id="allStartsHere">

        <div class="container">

            @include('includes.general-leftcolumn')

            <div id="content" class="col-sm-9">
                <div class="category-page-wrapper">
                    <div class="col-md-6 list-grid-wrapper">
                        <div class="btn-group btn-list-grid">
                            <button type="button" id="list-view" class="btn btn-default list" data-toggle="tooltip" title="" data-original-title="List"><i class="fa fa-th-list"></i></button>
                            <button type="button" id="grid-view" class="btn btn-default grid active" data-toggle="tooltip" title="" data-original-title="Grid"><i class="fa fa-th"></i></button>
                        </div>
                        <a href="#" id="compare-total">Product Compare (0)</a> </div>
                    <div class="col-md-1 text-right page-wrapper">
                        <label class="control-label" for="input-limit">Show:</label>
                        <div class="limit">
                            <select id="input-limit" class="form-control">
                                <option value="8" selected="selected">8</option>
                                <option value="25">25</option>
                                <option value="50">50</option>
                                <option value="75">75</option>
                                <option value="100">100</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-2 text-right sort-wrapper">
                        <label class="control-label" for="input-sort">Sort By:</label>
                        <div class="sort-inner">
                            <select id="input-sort" class="form-control">
                                <option value="ASC" selected="selected">Default</option>
                                <option value="ASC">Name (A - Z)</option>
                                <option value="DESC">Name (Z - A)</option>
                                <option value="ASC">Price (Low &gt; High)</option>
                                <option value="DESC">Price (High &gt; Low)</option>
                                <option value="DESC">Rating (Highest)</option>
                                <option value="ASC">Rating (Lowest)</option>
                                <option value="ASC">Model (A - Z)</option>
                                <option value="DESC">Model (Z - A)</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="grid-list-wrapper">

                    @if( $items->count() == 0)
                        <div class='col-xs-12'>

                            <p class="lead text-center">
                                {{ trans('item.no_selling_item') }}
                            </p>
                        </div>
                    @endif
                    @foreach($items as $item)

                        <a href="{{ route('item.show',$item->id) }}">
                            <div class="product-thumb">

                                <favorite :item={{ $item->id }} :favorited={{ Auth::check() && $item->favorited() ? 'true' : 'false' }}>
                                </favorite>
                            </div>
                        </a>
                    @endforeach
                </div>
                {{--<div class="category-page-wrapper">--}}
                    {{--<div class="result-inner">Showing 1 to 8 of 10 (2 Pages)</div>--}}
                    {{--<div class="pagination-inner">--}}
                        {{--<ul class="pagination">--}}
                            {{--<li class="active"><span>1</span></li>--}}
                            {{--<li><a href="category.html">2</a></li>--}}
                            {{--<li><a href="category.html">&gt;</a></li>--}}
                            {{--<li><a href="category.html">&gt;|</a></li>--}}
                        {{--</ul>--}}
                    {{--</div>--}}
                {{--</div>--}}

            </div>
        </div>
    </div>

@endsection

@section('custom-scripts')

    <script src="{{ asset('js/dependencies.js') }}"></script>
    <script src="{{ asset('js/favorites.js') }}"></script>
    @endsection