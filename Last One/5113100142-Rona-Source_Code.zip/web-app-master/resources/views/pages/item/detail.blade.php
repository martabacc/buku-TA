@extends('layouts.general')

@section('content')

    @include('includes.navbar')

    <div class="row">

        <div class="container">

            <div id="content"  style='padding-right:1em; padding-left:1em;'class="col-sm-9">
                <div class="row">
                    <div class="col-sm-4">
                        <ul class="thumbnails">
                            <li><a class="thumbnail fancybox" title="iPod Classic">
                                <img src="{{ url('image/product/product1.jpg') }}" title="iPod Classic" alt="iPod Classic">
                                </a>
                            </li>
                        </ul>
                    </div>
                    @include('pages.bid.biddetail')
                </div>


                <div class="productinfo-tab">
                    <ul class="nav nav-tabs">
                        <li class="active"><a href="#tab-description" data-toggle="tab">Description</a></li>
                    </ul>
                    <div class="tab-content">
                        <div class="tab-pane active" id="tab-description">
                            <div class="cpt_product_description ">
                                <div>
                                    {{ $item->description }}
                                </div>
                            </div>
                            <!-- cpt_container_end -->
                        </div>
                    </div>
                </div>
                <h3 class="productblock-title">Related Products</h3>
                <div class="box">
                    <div id="related-slidertab" class="row owl-carousel product-slider owl-theme" style="opacity: 1; display: block;">
                        <div class="owl-wrapper-outer"><div class="owl-wrapper" style="width: 3360px; left: 0px; display: block;"><div class="owl-item" style="width: 240px;"><div class="item">
                                        <div class="product-thumb transition">
                                            <div class="image product-imageblock"> <a href="#"> <img src="{{  url('image/product/pro-1-220x294.jpg') }}" alt="iPhone" title="iPhone" class="img-responsive"> </a>
                                                <div class="button-group">
                                                    <button type="button" class="wishlist" data-toggle="tooltip" title="" data-original-title="Add to Wish List"><i class="fa fa-heart-o"></i></button>
                                                    <button type="button" class="addtocart-btn">Add to Cart</button>
                                                    <button type="button" class="compare" data-toggle="tooltip" title="" data-original-title="Compare this Product"><i class="fa fa-exchange"></i></button>
                                                </div>
                                            </div>
                                            <div class="caption product-detail">
                                                <h4 class="product-name"><a href="product.html" title="iPhone">iPhone</a></h4>
                                                <p class="price product-price"> <span class="price-new">$254.00</span> <span class="price-old">$272.00</span> <span class="price-tax">Ex Tax: $210.00</span> </p>
                                            </div>  
                                            <div class="button-group">
                                                <button type="button" class="wishlist" data-toggle="tooltip" title="" data-original-title="Add to Wish List"><i class="fa fa-heart-o"></i></button>
                                                <button type="button" class="addtocart-btn">Add to Cart</button>
                                                <button type="button" class="compare" data-toggle="tooltip" title="" data-original-title="Compare this Product"><i class="fa fa-exchange"></i></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="owl-item" style="width: 240px;">
                                    <div class="item">
                                        <div class="product-thumb transition">
                                            <div class="image product-imageblock"> <a href="#">
                                                    <img src="{{  url('image/product/pro-2-220x294.jpg') }}" alt="iPhone" title="iPhone" class="img-responsive"> </a>
                                                <div class="button-group">
                                                    <button type="button" class="wishlist" data-toggle="tooltip" title="" data-original-title="Add to Wish List"><i class="fa fa-heart-o"></i></button>
                                                    <button type="button" class="addtocart-btn">Add to Cart</button>
                                                    <button type="button" class="compare" data-toggle="tooltip" title="" data-original-title="Compare this Product"><i class="fa fa-exchange"></i></button>
                                                </div>
                                            </div>
                                            <div class="caption product-detail">
                                                <h4 class="product-name"><a href="product.html" title="iPhone">iPhone</a></h4>
                                                <p class="price product-price"> <span class="price-new">$254.00</span> <span class="price-old">$272.00</span> <span class="price-tax">Ex Tax: $210.00</span> </p>
                                            </div>
                                            <div class="button-group">
                                                <button type="button" class="wishlist" data-toggle="tooltip" title="" data-original-title="Add to Wish List"><i class="fa fa-heart-o"></i></button>
                                                <button type="button" class="addtocart-btn">Add to Cart</button>
                                                <button type="button" class="compare" data-toggle="tooltip" title="" data-original-title="Compare this Product"><i class="fa fa-exchange"></i></button>
                                            </div>
                                        </div>
                                    </div></div><div class="owl-item" style="width: 240px;"><div class="item">
                                        <div class="product-thumb transition">
                                            <div class="image product-imageblock"> <a href="#"> <img src="image/product/pro-3-220x294.jpg" alt="iPhone" title="iPhone" class="img-responsive"> </a>
                                                <div class="button-group">
                                                    <button type="button" class="wishlist" data-toggle="tooltip" title="" data-original-title="Add to Wish List"><i class="fa fa-heart-o"></i></button>
                                                    <button type="button" class="addtocart-btn">Add to Cart</button>
                                                    <button type="button" class="compare" data-toggle="tooltip" title="" data-original-title="Compare this Product"><i class="fa fa-exchange"></i></button>
                                                </div>
                                            </div>
                                            <div class="caption product-detail">
                                                <h4 class="product-name"><a href="product.html" title="iPhone">iPhone</a></h4>
                                                <p class="price product-price"> <span class="price-new">$254.00</span> <span class="price-old">$272.00</span> <span class="price-tax">Ex Tax: $210.00</span> </p>
                                            </div>
                                            <div class="button-group">
                                                <button type="button" class="wishlist" data-toggle="tooltip" title="" data-original-title="Add to Wish List"><i class="fa fa-heart-o"></i></button>
                                                <button type="button" class="addtocart-btn">Add to Cart</button>
                                                <button type="button" class="compare" data-toggle="tooltip" title="" data-original-title="Compare this Product"><i class="fa fa-exchange"></i></button>
                                            </div>
                                        </div>
                                    </div></div><div class="owl-item" style="width: 240px;"><div class="item">
                                        <div class="product-thumb transition">
                                            <div class="image product-imageblock"> <a href="#"> <img src="image/product/pro-4-220x294.jpg" alt="iPhone" title="iPhone" class="img-responsive"> </a>
                                                <div class="button-group">
                                                    <button type="button" class="wishlist" data-toggle="tooltip" title="" data-original-title="Add to Wish List"><i class="fa fa-heart-o"></i></button>
                                                    <button type="button" class="addtocart-btn">Add to Cart</button>
                                                    <button type="button" class="compare" data-toggle="tooltip" title="" data-original-title="Compare this Product"><i class="fa fa-exchange"></i></button>
                                                </div>
                                            </div>
                                            <div class="caption product-detail">
                                                <h4 class="product-name"><a href="product.html" title="iPhone">iPhone</a></h4>
                                                <p class="price product-price"> <span class="price-new">$254.00</span> <span class="price-old">$272.00</span> <span class="price-tax">Ex Tax: $210.00</span> </p>
                                            </div>
                                            <div class="button-group">
                                                <button type="button" class="wishlist" data-toggle="tooltip" title="" data-original-title="Add to Wish List"><i class="fa fa-heart-o"></i></button>
                                                <button type="button" class="addtocart-btn">Add to Cart</button>
                                                <button type="button" class="compare" data-toggle="tooltip" title="" data-original-title="Compare this Product"><i class="fa fa-exchange"></i></button>
                                            </div>
                                        </div>
                                    </div></div><div class="owl-item" style="width: 240px;"><div class="item">
                                        <div class="product-thumb transition">
                                            <div class="image product-imageblock"> <a href="#"> <img src="image/product/pro-5-220x294.jpg" alt="iPhone" title="iPhone" class="img-responsive"> </a>
                                                <div class="button-group">
                                                    <button type="button" class="wishlist" data-toggle="tooltip" title="" data-original-title="Add to Wish List"><i class="fa fa-heart-o"></i></button>
                                                    <button type="button" class="addtocart-btn">Add to Cart</button>
                                                    <button type="button" class="compare" data-toggle="tooltip" title="" data-original-title="Compare this Product"><i class="fa fa-exchange"></i></button>
                                                </div>
                                            </div>
                                            <div class="caption product-detail">
                                                <h4 class="product-name"><a href="product.html" title="iPhone">iPhone</a></h4>
                                                <p class="price product-price"> <span class="price-new">$254.00</span> <span class="price-old">$272.00</span> <span class="price-tax">Ex Tax: $210.00</span> </p>
                                            </div>
                                            <div class="button-group">
                                                <button type="button" class="wishlist" data-toggle="tooltip" title="" data-original-title="Add to Wish List"><i class="fa fa-heart-o"></i></button>
                                                <button type="button" class="addtocart-btn">Add to Cart</button>
                                                <button type="button" class="compare" data-toggle="tooltip" title="" data-original-title="Compare this Product"><i class="fa fa-exchange"></i></button>
                                            </div>
                                        </div>
                                    </div></div><div class="owl-item" style="width: 240px;"><div class="item">
                                        <div class="product-thumb transition">
                                            <div class="image product-imageblock"> <a href="#"> <img src="image/product/pro-6-220x294.jpg" alt="iPhone" title="iPhone" class="img-responsive"> </a>
                                                <div class="button-group">
                                                    <button type="button" class="wishlist" data-toggle="tooltip" title="" data-original-title="Add to Wish List"><i class="fa fa-heart-o"></i></button>
                                                    <button type="button" class="addtocart-btn">Add to Cart</button>
                                                    <button type="button" class="compare" data-toggle="tooltip" title="" data-original-title="Compare this Product"><i class="fa fa-exchange"></i></button>
                                                </div>
                                            </div>
                                            <div class="caption product-detail">
                                                <h4 class="product-name"><a href="product.html" title="iPhone">iPhone</a></h4>
                                                <p class="price product-price"> <span class="price-new">$254.00</span> <span class="price-old">$272.00</span> <span class="price-tax">Ex Tax: $210.00</span> </p>
                                            </div>
                                            <div class="button-group">
                                                <button type="button" class="wishlist" data-toggle="tooltip" title="" data-original-title="Add to Wish List"><i class="fa fa-heart-o"></i></button>
                                                <button type="button" class="addtocart-btn">Add to Cart</button>
                                                <button type="button" class="compare" data-toggle="tooltip" title="" data-original-title="Compare this Product"><i class="fa fa-exchange"></i></button>
                                            </div>
                                        </div>
                                    </div></div><div class="owl-item" style="width: 240px;"><div class="item">
                                        <div class="product-thumb transition">
                                            <div class="image product-imageblock"> <a href="#"> <img src="image/product/pro-7-220x294.jpg" alt="iPhone" title="iPhone" class="img-responsive"> </a>
                                                <div class="button-group">
                                                    <button type="button" class="wishlist" data-toggle="tooltip" title="" data-original-title="Add to Wish List">   <i class="fa fa-heart-o"></i></button>
                                                    <button type="button" class="addtocart-btn">Add to Cart</button>
                                                    <button type="button" class="compare" data-toggle="tooltip" title="" data-original-title="Compare this Product"><i class="fa fa-exchange"></i></button>
                                                </div>
                                            </div>
                                            <div class="caption product-detail">
                                                <h4 class="product-name"><a href="product.html" title="iPhone">iPhone</a></h4>
                                                <p class="price product-price"> <span class="price-new">$254.00</span> <span class="price-old">$272.00</span> <span class="price-tax">Ex Tax: $210.00</span> </p>
                                            </div>
                                            <div class="button-group">
                                                <button type="button" class="wishlist" data-toggle="tooltip" title="" data-original-title="Add to Wish List"><i class="fa fa-heart-o"></i></button>
                                                <button type="button" class="addtocart-btn">Add to Cart</button>
                                                <button type="button" class="compare" data-toggle="tooltip" title="" data-original-title="Compare this Product"><i class="fa fa-exchange"></i></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div class="owl-controls clickable"><div class="owl-buttons"><div class="owl-prev">prev</div><div class="owl-next">next</div></div></div></div>
                </div>
            </div>


            <div id="column-left" class="col-sm-3 hidden-xs column-left" >
                <div class="column-block">
                    <div class="columnblock-title">Detail Penjual</div>
                    <div class="category_block">
                        <ul class="box-category treeview-list treeview">
                        </ul>
                    </div>
                </div>
                <div class="column-block" style="padding-bottom:3em;">
                    <button class="btn btn-danger col-sm-12"  data-toggle="modal" data-target="#modal">
                        <span class="glyphicon glyphicon-warning-sign" aria-hidden="true"></span>
                        Laporkan
                    </button>
                </div>
                <div class="clearfix"></div>
                <div class="column-block">
                    <div class="columnblock-title">Categories</div>
                    <div class="category_block">
                        <ul class="box-category treeview-list treeview">
                            <li><a href="#" class="activSub">Desktops</a>
                                <ul>
                                    <li><a href="#">PC</a></li>
                                    <li><a href="#">MAC</a></li>
                                </ul>
                            </li>
                            <li><a href="#" class="activSub">Laptops &amp; Notebooks</a>
                                <ul>
                                    <li><a href="#">Macs</a></li>
                                    <li><a href="#">Windows</a></li>
                                </ul>
                            </li>
                            <li><a href="#" class="activSub">Components</a>
                                <ul>
                                    <li><a href="#">Mice and Trackballs</a></li>
                                    <li><a href="#" class="activSub" >Monitors</a>
                                        <ul>
                                            <li><a href="#"  >test 1</a></li>
                                            <li><a href="#"  >test 2</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="#">Windows</a></li>
                                </ul>
                            </li>
                            <li><a href="#">Tablets</a></li>
                            <li><a href="#">Software</a></li>
                            <li><a href="#">Phones & PDAs</a></li>
                            <li><a href="#">Cameras</a></li>
                            <li><a href="#">MP3 Players</a></li>
                        </ul>
                    </div>
                </div>
                <div class="blog">
                    <div class="blog-heading">
                        <h3>Latest Blogs</h3>
                    </div>
                    <div class="blog-inner">
                        <ul id="Latest-blog" class="list-unstyled blog-wrapper">
                            <li class="item blog-slider-item">
                                <div class="panel-default">
                                    <div class="blog-image">
                                        <a class="blog-imagelink" href="#">
                                            <img src="{{ url('blog/blog_1.jpg')}}" alt="#">
                                        </a>
                                    </div>
                                    <div class="blog-content">
                                        <a class="blog-name" href="#">
                                            <h2>Nunc rutrum scel potent</h2>
                                        </a>
                                        <span class="blog-date">06/07/2015</span>
                                    </div>
                                </div>
                            </li>
                            <li class="item blog-slider-item">
                                <div class="panel-default">
                                    <div class="blog-image"> <a class="blog-imagelink" href="#">
                                            <img src="{{ url('blog/blog_2.jpg') }}" alt="#"></a>
                                    </div>
                                    <div class="blog-content"> <a class="blog-name" href="#">
                                            <h2>Nunc rutrum scel potent</h2>
                                        </a>
                                        <span class="blog-date">06/07/2015</span>
                                    </div>
                                </div>
                            </li>
                            <li class="item blog-slider-item">
                                <div class="panel-default">
                                    <div class="blog-image"> <a class="blog-imagelink" href="#">
                                            <img src="{{ url('blog/blog_5.jpg')}}" alt="#"></a> </div>
                                    <div class="blog-content"> <a class="blog-name" href="#">
                                            <h2>Nunc rutrum scel potent</h2>
                                        </a> <span class="blog-date">06/07/2015</span> </div>
                                </div>
                            </li>
                            <li class="item blog-slider-item">
                                <div class="panel-default">
                                    <div class="blog-image"> <a class="blog-imagelink" href="#"><img src="{{ url('blog/blog_4.jpg')}}" alt="#"></a> </div>
                                    <div class="blog-content"> <a class="blog-name" href="#">
                                            <h2>Nunc rutrum scel potent</h2>
                                        </a> <span class="blog-date">06/07/2015</span> </div>
                                </div>
                            </li>
                        </ul>
                        <div class="buttons text-right seeall">
                            <button type="button" onClick="location='blog.html';" class="btn btn-primary">See all Blogs</button>
                        </div>
                    </div>
                </div>
                <h3 class="productblock-title">Latest</h3>
                <div class="row latest-grid product-grid">
                    <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12 product-grid-item">
                        <div class="product-thumb transition">
                            <div class="image product-imageblock"><a href="product.html"><img src="{{ url('product/1product50x59.jpg')}}" alt="iPod Classic" title="iPod Classic" class="img-responsive" /></a>
                                <div class="button-group">
                                    <button type="button" class="wishlist" data-toggle="tooltip" title="Add to Wish List"><i class="fa fa-heart-o"></i></button>
                                    <button type="button" class="addtocart-btn">Add to Cart</button>
                                    <button type="button" class="compare" data-toggle="tooltip" title="Compare this Product" ><i class="fa fa-exchange"></i></button>
                                </div>
                            </div>
                            <div class="caption product-detail">
                                <h4 class="product-name"><a href="#" title="iPod Classic">iPod Classic</a></h4>
                                <p class="price product-price">$122.00<span class="price-tax">Ex Tax: $100.00</span></p>
                                <div class="rating"> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span> </div>
                            </div>
                            <div class="button-group">
                                <button type="button" class="wishlist" data-toggle="tooltip" title="Add to Wish List" ><i class="fa fa-heart-o"></i></button>
                                <button type="button" class="addtocart-btn" >Add to Cart</button>
                                <button type="button" class="compare" data-toggle="tooltip" title="Compare this Product" ><i class="fa fa-exchange"></i></button>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12 product-grid-item">
                        <div class="product-thumb transition">
                            <div class="image product-imageblock"><a href="#"><img src="{{ url('product/2product50x59.jpg')}}" alt="iPod Classic" title="iPod Classic" class="img-responsive" /></a>
                                <div class="button-group">
                                    <button type="button" class="wishlist" data-toggle="tooltip" title="Add to Wish List"><i class="fa fa-heart-o"></i></button>
                                    <button type="button" class="addtocart-btn">Add to Cart</button>
                                    <button type="button" class="compare" data-toggle="tooltip" title="Compare this Product"><i class="fa fa-exchange"></i></button>
                                </div>
                            </div>
                            <div class="caption product-detail">
                                <h4 class="product-name"><a href="#" title="iPod Classic">iPod Classic</a></h4>
                                <p class="price product-price">$122.00<span class="price-tax">Ex Tax: $100.00</span></p>
                                <div class="rating"> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span> </div>
                            </div>
                            <div class="button-group">
                                <button type="button" class="wishlist" data-toggle="tooltip" title="Add to Wish List" ><i class="fa fa-heart-o"></i></button>
                                <button type="button" class="addtocart-btn" >Add to Cart</button>
                                <button type="button" class="compare" data-toggle="tooltip" title="Compare this Product" ><i class="fa fa-exchange"></i></button>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12 product-grid-item">
                        <div class="product-thumb transition">
                            <div class="image product-imageblock"><a href="#"><img src="{{ url('product/3product50x59.jpg')}}" alt="iPod Classic" title="iPod Classic" class="img-responsive" /></a>
                                <div class="button-group">
                                    <button type="button" class="wishlist" data-toggle="tooltip" title="Add to Wish List" ><i class="fa fa-heart-o"></i></button>
                                    <button type="button" class="addtocart-btn">Add to Cart</button>
                                    <button type="button" class="compare" data-toggle="tooltip" title="Compare this Product" ><i class="fa fa-exchange"></i></button>
                                </div>
                            </div>
                            <div class="caption product-detail">
                                <h4 class="product-name"><a href="#" title="iPod Classic">iPod Classic</a></h4>
                                <p class="price product-price">$122.00<span class="price-tax">Ex Tax: $100.00</span></p>
                                <div class="rating"> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span> </div>
                            </div>
                            <div class="button-group">
                                <button type="button" class="wishlist" data-toggle="tooltip" title="Add to Wish List" ><i class="fa fa-heart-o"></i></button>
                                <button type="button" class="addtocart-btn">Add to Cart</button>
                                <button type="button" class="compare" data-toggle="tooltip" title="Compare this Product" ><i class="fa fa-exchange"></i></button>
                            </div>
                        </div>
                    </div>
                </div>
                <h3 class="productblock-title">Specials</h3>
                <div class="row special-grid product-grid">
                    <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12 product-grid-item">
                        <div class="product-thumb transition">
                            <div class="image product-imageblock"> <a href="#"><img src="{{ url('product/4product50x59.jpg')}}" alt="iPhone" title="iPhone" class="img-responsive" /></a>
                                <div class="button-group">
                                    <button type="button" class="wishlist" data-toggle="tooltip" title="Add to Wish List" ><i class="fa fa-heart-o"></i></button>
                                    <button type="button" class="addtocart-btn" >Add to Cart</button>
                                    <button type="button" class="compare" data-toggle="tooltip" title="Compare this Product" ><i class="fa fa-exchange"></i></button>
                                </div>
                            </div>
                            <div class="caption product-detail">
                                <h4 class="product-name"> <a href="product.html" title="iPhone">iPhone</a> </h4>
                                <p class="price product-price"> <span class="price-new">$254.00</span> <span class="price-old">$272.00</span> <span class="price-tax">Ex Tax: $210.00</span> </p>
                            </div>
                            <div class="button-group">
                                <button type="button" class="wishlist" data-toggle="tooltip" title="Add to Wish List" ><i class="fa fa-heart-o"></i></button>
                                <button type="button" class="addtocart-btn" >Add to Cart</button>
                                <button type="button" class="compare" data-toggle="tooltip" title="Compare this Product" ><i class="fa fa-exchange"></i></button>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12 product-grid-item">
                        <div class="product-thumb transition">
                            <div class="image product-imageblock"> <a href="#"><img src="{{ url('product/5product50x59.jpg')}}" alt="iPhone" title="iPhone" class="img-responsive" /></a>
                                <div class="button-group">
                                    <button type="button" class="wishlist" data-toggle="tooltip" title="Add to Wish List" ><i class="fa fa-heart-o"></i></button>
                                    <button type="button" class="addtocart-btn" >Add to Cart</button>
                                    <button type="button" class="compare" data-toggle="tooltip" title="Compare this Product" ><i class="fa fa-exchange"></i></button>
                                </div>
                            </div>
                            <div class="caption product-detail">
                                <h4 class="product-name"> <a href="product.html" title="iPhone">iPhone</a> </h4>
                                <p class="price product-price"> <span class="price-new">$254.00</span> <span class="price-old">$272.00</span> <span class="price-tax">Ex Tax: $210.00</span> </p>
                            </div>
                            <div class="button-group">
                                <button type="button" class="wishlist" data-toggle="tooltip" title="Add to Wish List" ><i class="fa fa-heart-o"></i></button>
                                <button type="button" class="addtocart-btn" >Add to Cart</button>
                                <button type="button" class="compare" data-toggle="tooltip" title="Compare this Product" ><i class="fa fa-exchange"></i></button>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12 product-grid-item">
                        <div class="product-thumb transition">
                            <div class="image product-imageblock"> <a href="#"><img src="{{ url('product/6product50x59.jpg')}}" alt="iPhone" title="iPhone" class="img-responsive" /></a>
                                <div class="button-group">
                                    <button type="button" class="wishlist" data-toggle="tooltip" title="Add to Wish List" ><i class="fa fa-heart-o"></i></button>
                                    <button type="button" class="addtocart-btn" >Add to Cart</button>
                                    <button type="button" class="compare" data-toggle="tooltip" title="Compare this Product" ><i class="fa fa-exchange"></i></button>
                                </div>
                            </div>
                            <div class="caption product-detail">
                                <h4 class="product-name"> <a href="product.html" title="iPhone">iPhone</a> </h4>
                                <p class="price product-price"> <span class="price-new">$254.00</span> <span class="price-old">$272.00</span> <span class="price-tax">Ex Tax: $210.00</span> </p>
                            </div>
                            <div class="button-group">
                                <button type="button" class="wishlist" data-toggle="tooltip" title="Add to Wish List" ><i class="fa fa-heart-o"></i></button>
                                <button type="button" class="addtocart-btn" >Add to Cart</button>
                                <button type="button" class="compare" data-toggle="tooltip" title="Compare this Product" ><i class="fa fa-exchange"></i></button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>



        <div class="modal fade" id="modal"  role="dialog">
            <div class="modal-dialog" role="document"style="z-index: 1060">
                <div class="modal-content" >
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title">Laporkan Pengguna</h4>
                    </div>
                    <div class="modal-body row">
                        <div class="col-md-12" style="margin-bottom:2em">
                            <div class="col-md-4 col-xs-12">
                                <label>Jenis Laporan</label>
                            </div>
                            <div class="col-md-8 col-xs-12">
                                <select class="js-data-example-ajax"  style="width: 100%"></select>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="col-md-4 col-xs-12">
                                <label>Tuliskan laporan anda</label>
                            </div>
                            <div class="col-md-8 col-xs-12">
                                <textarea id="laporBody" class="col-md-12 col-xs-12"></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <img src="{{ url('image/ajaxloading.gif') }}" id="ajaxloading"/>
                        <button type="button" class="btn btn-default" data-dismiss="modal">Batal</button>
                        <button type="button" class="btn btn-primary click">Laporkan</button>
                    </div>
                </div>
                <!-- /.modal-content -->
            </div><!-- /.modal-dialog -->
        </div><!-- /.modal -->

    </div>
    endsection
@endsection

@include('pages.bid.socket')