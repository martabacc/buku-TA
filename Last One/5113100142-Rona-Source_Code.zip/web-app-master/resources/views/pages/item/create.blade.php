@extends('layouts.general')


@section('content')

        @include('includes.navbar')


    <div class="row">


        <div class="container">
            <link href="{{ asset('dropzone.css') }}" type="text/css" rel="stylesheet" />
            <script src="{{ asset('dropzone.js') }}"></script>

            <ul class="breadcrumb">
                <li><a href="{{ url('/') }}"><i class="fa fa-home"></i> Home </a></li>
                <li><a href="{{ route('item.index') }}">{{ trans('item.item_management') }}</a></li>
                <li><a href="{{ route('item.create') }}">{{ trans('item.item_add') }}</a></li>
            </ul>

            {{--@include('includes.item-navbar')--}}

            <div id="content" class="col-sm-9 col-sm-offset-1">

            <div class="col-sm-12" id="content">

                <form class="form-horizontal submititem" method="post" action="{{ route('item.store') }}">
                    <fieldset id="account">
                        <h3 id="xxx">{{ trans('item.sell_new_item') }}</h3>

                            <ul class="alert alert-danger asdf" style="display: none">
                            </ul>
                        <div class="form-group required">
                            <label for="input-firstname" class="col-sm-2 control-label">{{ trans('item.item_name') }}</label>
                            <div class="col-sm-10">
                                <input required type="text" class="form-control" id="input-firstname"  value="" name="name">
                            </div>
                        </div>
                        <div class="form-group required">
                            <label for="input-lastname" class="col-sm-2 control-label">{{ trans('item.item_description') }}</label>
                            <div class="col-sm-10">
                                <textarea required type="text" class="form-control" name='description'id="input-lastname" value="" name="lastname"></textarea>
                            </div>
                        </div>
                        <div class="form-group required">
                            <label for="exampleInputFile"  class="col-sm-2 control-label">{{ trans('item.item_picture') }}</label>
                            <div class="col-sm-10">
                                <div class="dropzone" id="my-awesome-dropzone" style="
	border: 2px dashed #0087F7;
	border-radius: 5px;
	background: white;
	box-sizing:border-box;
    animation: 1s animateBorder ease infinite;
	vertical-align: baseline;">
                                    <div class="dz-message needsclick">
                                        Klik atau seret untuk menambahkan gambar

                                </div>
                                <div class="dropzone-previews" id="dropzonePreview"></div>

                            </div>
                        </div>
                    </fieldset>
                    <fieldset id="address">
                        <legend>{{ trans('item.auction_detail') }}</legend>
                        <div class="form-group required">
                            <label for="input-email" class="col-sm-2 control-label">{{ trans('item.start_time') }}</label>
                            <div class="col-sm-10">
                                <div style="overflow:hidden;">
                                    <div class="form-group">
                                        <div class="row">
                                            <div class="col-md-8">
                                                <div class="datetimepicker12" id="start_time"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group required">
                            <label for="input-email" class="col-sm-2 control-label" >{{ trans('item.end_time') }}</label>
                            <div class="col-sm-10">
                                <div style="overflow:hidden;">
                                    <div class="form-group">
                                        <div class="row">
                                            <div class="col-md-8">
                                                <div class="datetimepicker12" id="end_time"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group required">
                            <label class="col-sm-2 control-label">{{ trans('item.starting_price') }}</label>
                            <div class="col-sm-6">
                                <input type="number" required class="form-control" id="input-firstname"  value="" name="starting_price">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-2 control-label">{{ trans('item.expected_price') }}</label>
                            <div class="col-sm-6">
                                <input type="number" class="form-control" id="input-firstname"  value="" name="expected_price">
                                <input type="hidden" name="timezone_offset" >
                            </div>
                        </div>

                    </fieldset>
                    <hr>
                    <div class="buttons">
                        <div class="pull-left">
                            <button type="button" id="click" class="btn btn-lg btn-success" >
                                {{ trans('item.add_new_item_submit') }}
                            </button>
                        </div>
                    </div>
                </form>
            </div>


        </div>
    </div>

        {{--modal to show --}}
        <div id="kv-success-modal" class="modal fade">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title">Yippee!</h4>
                    </div>
                    <div id="kv-success-box" class="modal-body">
                    </div>
                </div>
            </div>
        </div>
</div>

</div>

<script type="text/javascript">

$(document).ready(function(){


    function addTimebasedTZ(string){
        var offset = new Date().getTimezoneOffset();
        return moment(string, 'DD MM YYYY HH:mm')
            .add(-offset,'minutes')
            .format('DD-MM-YYYY HH:mm');

    }
    $(function () {
        $('.datetimepicker12').datetimepicker({
            //use24hours: true,
            inline: true,
            format: 'DD MM YYYY HH:mm',
            //locale: 'id',
            sideBySide: true,
            icons: {
                time: "fa fa-clock-o",
                date: "fa fa-calendar",
                up: "fa fa-arrow-up",
                down: "fa fa-arrow-down"
            },
            minDate: new Date()
        });
    });
    var iditem = 0;
    new Dropzone("div#my-awesome-dropzone", {
        url: "{{ route('uploadimage')  }}",
        autoProcessQueue: false,
        allowOutsideClick: false,
        method : 'post',
        paramName : "image",
        uploadMultiple: false,
//    previewsContainer: '#dropzonePreview',
        addRemoveLinks: true,
        dictRemoveFile: 'Remove',
        dictFileTooBig: 'Image is bigger than 8MB',

        // The setting up of the dropzone
        init: function() {
            var submitButton = document.querySelector("#click");
            var myDropzone = this; // closure
            console.log(myDropzone.files.length);
            submitButton.addEventListener("click", function() {
                swal({
                    text: 'Mensubmit data barang anda...',
                    allowOutsideClick: false,
                    showConfirmButton: false,
                    onOpen: function (){
                            var dataSubmission = $('.submititem').serialize();
                            var startime='&start_time=' + addTimebasedTZ($('#start_time').data().date);
                            var endtime = '&end_time=' + addTimebasedTZ($('#end_time').data().date);
                            dataSubmission += startime;
                            dataSubmission += endtime;
                            $.ajax({
                                type: "POST",
                                url: '{{ route('item.store') }}',
                                data: { _token: '{{csrf_token()}}', data : dataSubmission },
                                success: function( msg ) {
                                    console.log (msg);
                                    if(msg.success == false){
                                        $('.asdf').css('display','block');
                                        $('.asdf').empty();
                                        $.each(msg.msg, function(i, val){
                                            $('.asdf').append(
                                                '<li>'+val+'</li>'
                                            );
                                        });
                                        swal('Oops','Maaf, data anda belum valid. Silahkan cek kembali','error');

                                    }
                                    else{
                                        if(myDropzone.files.length >0){
                                            iditem = msg.id;
                                            myDropzone.processQueue();
                                        }

                                        else{

                                            swal({
                                                title: 'Sukses!',
                                                type:'success',
                                                allowOutsideClick : false,
                                                showConfirmButton : false,
                                                text: "Sukses menambahkan barang!",
                                                timer: 1000
                                            }).then(function () {
                                                document.location = "{{ url('item/') }}" + iditem;
                                            });
                                        }
                                    }

                                }
                            });
//                        });
                    }
                });
            });

            this.on("processing", function() {
                swal('Uploading image..');
            });

            this.on("sending", function(file, xhr, data) {
                if(iditem != 0){
                    data.append("_token", "{{ csrf_token() }}");
                    data.append("itemid", iditem);
                }
            });


        },
        error: function(file, response) {
            swal({
                title: 'Oops',
                type:'error',
                allowOutsideClick: false,
                showConfirmButton:false,
                text: "Maaf ada kesalahan upload gambar, silahkan upload gambar di halaman edit gambar.",
                timer: 2000
            }).then(function () {
                document.location = "{{ url('item') }}/" + iditem;
            });

        },
        success: function(file,done) {
            swal({
                title: 'Sukses!',
                allowOutsideClick: false,
                showConfirmButton:false,
                type:'success',
                text: "Sukses menambahkan barang!",
                timer: 1000
            }).then(function () {
                document.location = "{{ url('item/') }}" + iditem;
            });
        }

    });


});

    </script>
@endsection


