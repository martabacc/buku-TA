    @extends('layouts.general')

@section('content')

<div class="container">
    <div class="row">

        @include('includes.navbar')


        <div class="row">


            <div class="container">
                <link href="{{ asset('dropzone.css') }}" type="text/css" rel="stylesheet" />
                <script src="{{ asset('dropzone.js') }}"></script>

                <ul class="breadcrumb">
                    <li><a href="{{ url('/') }}"><i class="fa fa-home"></i> Home </a></li>
                    <li><a href="{{ route('item.index') }}">{{ trans('item.item_management') }}</a></li>
                    <li><a href="{{ route('item.update', $item->id) }}">{{ trans('item.update_item') }}</a></li>
                </ul>

                {{--@include('includes.item-navbar')--}}

                <div id="content" class="col-sm-9 col-sm-offset-1">

                <form class="form-horizontal" enctype="multipart/form-data" method="post" action="{{ route('item.update',$item->id) }}">
                    <fieldset id="account">
                        <h3>{{ trans('item.sell_new_item') }}</h3>


                        <ul class="alert alert-danger asdf" style="display: none">
                        </ul>
                        {{ csrf_field() }}
                        <input name="_method" type="hidden" value="PATCH">

                        <div class="form-group required">
                            <label for="input-firstname" class="col-sm-2 control-label">{{ trans('item.item_name') }}</label>
                            <div class="col-sm-10">
                                <input required type="text" class="form-control" id="input-firstname"  value="{{ $item->name }}" name="name">
                            </div>
                        </div>
                        <div class="form-group required">
                            <label for="input-lastname" class="col-sm-2 control-label">{{ trans('item.item_description') }}</label>
                            <div class="col-sm-10">
                                <textarea required type="text" class="form-control" name='description'id="input-lastname" value="" name="lastname">{{ $item->description }}</textarea>
                            </div>
                        </div>
                        <div class="form-group required">
                            <label for="exampleInputFile"  class="col-sm-2 control-label">{{ trans('item.item_picture') }}</label>
                            <div class="col-sm-10">
                                <div class="dropzone" id="my-awesome-dropzone" style="
	border: 2px dashed #0087F7;
	border-radius: 5px;
	background: white;
	box-sizing:border-box;
    animation: 1s animateBorder ease infinite;
	vertical-align: baseline;">
                                    <div class="dz-message needsclick">
                                        Klik atau seret untuk menambahkan gambar

                                    </div>
                                    <div class="dropzone-previews" id="dropzonePreview"></div>

                                </div>
                            </div>
                        </div>
                    </fieldset>
                    <fieldset id="address">
                        <legend>{{ trans('item.auction_detail') }}</legend>
                        <div class="form-group required">
                            <label for="input-email" class="col-sm-2 control-label">{{ trans('item.start_time') }}</label>
                            <div class="col-sm-10">
                                <div class="input-append date form_datetime" >
                                    <input required size="16" type="text" name='start_time' value="{{ 
                                    date_format(DateTime::createFromFormat('Y-m-d H:i:s', explode('+',$item->start_time)[0]),"d F Y H:i") }}" readonly>
                                    <span class="add-on"><i class="icon-remove"></i></span>
                                    <span class="add-on"><i class="icon-calendar"></i></span>
                                </div>
                            </div>
                        </div>
                        <div class="form-group required">
                            <label for="input-email" class="col-sm-2 control-label">{{ trans('item.end_time') }}</label>
                            <div class="col-sm-10">
                                <div class="input-append date form_datetime" >
                                    <input size="16" name="end_time" required type="text" value="{{ 
                                    date_format(DateTime::createFromFormat('Y-m-d H:i:s', explode('+',$item->end_time)[0]),"d F Y H:i") }}" readonly>
                                    <span class="add-on"><i class="icon-remove"></i></span>
                                    <span class="add-on"><i class="icon-calendar"></i></span>
                                </div>
                            </div>
                        </div>
                        <div class="form-group required">
                            <label class="col-sm-2 control-label">{{ trans('item.starting_price') }}</label>
                            <div class="col-sm-10">
                                <input type="number" required name="starting_price" class="form-control" id="input-firstname"  value="{{ $item->starting_price }}" name="starting_price">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-2 control-label">{{ trans('item.expected_price') }}</label>
                            <div class="col-sm-10">
                                <input type="number" name="expected_price" class="form-control" id="input-firstname"  value="{{ $item->expected_price }}">

                            </div>
                        </div>

                    </fieldset>
                    <div class="buttons">
                        <div class="pull-left">
                            <input type="submit" class="btn btn-primary" value="{{ trans('item.add_new_item_submit') }}">
                        </div>
                    </div>
                </form>
            </div>


        </div>
    </div>

        {{--modal to show --}}
        <div id="kv-success-modal" class="modal fade">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title">Yippee!</h4>
                    </div>
                    <div id="kv-success-box" class="modal-body">
                    </div>
                </div>
            </div>
        </div>
</div>

</div>

    <script type="text/javascript">


    $(document).ready(function(){

        function addTimebasedTZ(string){
            var offset = new Date().getTimezoneOffset();
            return moment(string, 'DD MM YYYY HH:mm')
                .add(-offset,'minutes')
                .format('DD-MM-YYYY HH:mm');

        }
        $(function () {
            $('.datetimepicker12').datetimepicker({
                //use24hours: true,
                inline: true,
                format: 'DD MM YYYY HH:mm',
                //locale: 'id',
                sideBySide: true,
                icons: {
                    time: "fa fa-clock-o",
                    date: "fa fa-calendar",
                    up: "fa fa-arrow-up",
                    down: "fa fa-arrow-down"
                },
                minDate: new Date()
            });
        });
        var iditem = 0;
        new Dropzone("div#my-awesome-dropzone", {
            url: "{{ route('item.updateimage')  }}",
            autoProcessQueue: false,
            allowOutsideClick: false,
            method : 'post',
            paramName : "image",
            uploadMultiple: false,
//    previewsContainer: '#dropzonePreview',
            addRemoveLinks: true,
            dictRemoveFile: 'Remove',
            dictFileTooBig: 'Image is bigger than 8MB',

            // The setting up of the dropzone
            init: function() {
                var submitButton = document.querySelector("#click");
                var myDropzone = this; // closure
                console.log(myDropzone.files.length);
                submitButton.addEventListener("click", function() {
                    swal({
                        text: 'Memperbarui data barang anda...',
                        allowOutsideClick: false,
                        showConfirmButton: false,
                        onOpen: function (){
                            var dataSubmission = $('.submititem').serialize();
                            var startime='&start_time=' + addTimebasedTZ($('#start_time').data().date);
                            var endtime = '&end_time=' + addTimebasedTZ($('#end_time').data().date);
                            dataSubmission += startime;
                            dataSubmission += endtime;
                            $.ajax({
                                type: "POST",
                                url: '{{ route('item.update') }}',
                                data: { _token: '{{csrf_token()}}', data : dataSubmission },
                                success: function( msg ) {
                                    console.log (msg);
                                    if(msg.success == false){
                                        $('.asdf').css('display','block');
                                        $('.asdf').empty();
                                        $.each(msg.msg, function(i, val){
                                            $('.asdf').append(
                                                '<li>'+val+'</li>'
                                            );
                                        });
                                        swal('Oops','Maaf, data anda belum valid. Silahkan cek kembali','error');

                                    }
                                    else{
                                        if(myDropzone.files.length >0){
                                            iditem = msg.id;
                                            myDropzone.processQueue();
                                        }

                                        else{

                                            swal({
                                                title: 'Sukses!',
                                                type:'success',
                                                allowOutsideClick : false,
                                                showConfirmButton : false,
                                                text: "Sukses menambahkan barang!",
                                                timer: 1000
                                            }).then(function () {
                                                document.location = "{{ url('item/') }}" + iditem;
                                            });
                                        }
                                    }

                                }
                            });
//                        });
                        }
                    });
                });

                this.on("processing", function() {
                    swal('Uploading image..');
                });

                this.on("sending", function(file, xhr, data) {
                    if(iditem != 0){
                        data.append("_token", "{{ csrf_token() }}");
                        data.append("itemid", iditem);
                    }
                });


            },
            error: function(file, response) {
                swal({
                    title: 'Oops',
                    type:'error',
                    allowOutsideClick: false,
                    showConfirmButton:false,
                    text: "Maaf ada kesalahan memperbarui gambar, silahkan upload gambar di halaman edit gambar.",
                    timer: 2000
                }).then(function () {
                    document.location = "{{ url('item') }}/" + iditem;
                });

            },
            success: function(file,done) {
                swal({
                    title: 'Sukses!',
                    allowOutsideClick: false,
                    showConfirmButton:false,
                    type:'success',
                    text: "Sukses memperbarui barang!",
                    timer: 1000
                }).then(function () {
                    document.location = "{{ url('item/') }}" + iditem;
                });
            }

        });


        });

    </script>
@endsection


