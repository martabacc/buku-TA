@extends('layouts.general')

@section('page_title')

@endsection
@section('content')

    @include('includes.navbar')

    <div class="row">

        <div class="container">

            @include('includes.general-leftcolumn')
            <div id="content" class="col-sm-9">
                <style type="text/css">
                    .lol {
                        padding-top: 0;
                        font-size: 15px;
                        max-height:60%!important;
                        overflow-y:scroll;
                        color: #777;
                        background: #f9f9f9;
                        font-family: 'Open Sans',sans-serif;
                        margin-top:20px;
                    }

                    .bg-white {
                        background-color: #fff;
                    }

                    .friend-list {
                        list-style: none;
                        /*margin-left: -40px;*/
                    }

                    .friend-list li {
                        border-bottom: 1px solid #eee;
                    }

                    .friend-list li a img {
                        float: left;
                        width: 45px;
                        height: 45px;
                        margin-right: 0px;
                    }

                    .friend-list li a {
                        position: relative;
                        display: block;
                        padding: 10px;
                        transition: all .2s ease;
                        -webkit-transition: all .2s ease;
                        -moz-transition: all .2s ease;
                        -ms-transition: all .2s ease;
                        -o-transition: all .2s ease;
                    }

                    .friend-list li.active a {
                        background-color: #f1f5fc;
                    }

                    .friend-list li a .friend-name,
                    .friend-list li a .friend-name:hover {
                        color: #777;
                    }

                    .friend-list li a .last-message {
                        width: 65%;
                        white-space: nowrap;
                        text-overflow: ellipsis;
                        overflow: hidden;
                    }

                    .friend-list li a .time {
                        position: absolute;
                        top: 10px;
                        right: 8px;
                    }

                    small, .small {
                        font-size: 85%;
                    }

                    .friend-list li a .chat-alert {
                        position: absolute;
                        right: 8px;
                        top: 27px;
                        font-size: 10px;
                        padding: 3px 5px;
                    }

                    .chat-message {
                        padding: 60px 20px 115px;
                    }

                    .chat {
                        list-style: none;
                        margin: 0;
                    }

                    .chat-message{
                        background: #f9f9f9;
                    }

                    .chat li img {
                        width: 45px;
                        height: 45px;
                        border-radius: 50em;
                        -moz-border-radius: 50em;
                        -webkit-border-radius: 50em;
                    }

                    img {
                        max-width: 100%;
                    }

                    .chat-body {
                        padding-bottom: 20px;
                    }

                    .chat li.left .chat-body {
                        margin-left: 70px;
                        background-color: #fff;
                    }

                    .chat li .chat-body {
                        position: relative;
                        font-size: 15px;
                        padding: 10px;
                        border: 1px solid #f1f5fc;
                        box-shadow: 0 1px 1px rgba(0,0,0,.05);
                        -moz-box-shadow: 0 1px 1px rgba(0,0,0,.05);
                        -webkit-box-shadow: 0 1px 1px rgba(0,0,0,.05);
                    }

                    .chat li .chat-body .header {
                        padding-bottom: 5px;
                        border-bottom: 1px solid #f1f5fc;
                    }

                    .chat li .chat-body p {
                        margin: 0;
                    }

                    .chat li.left .chat-body:before {
                        position: absolute;
                        top: 10px;
                        left: -8px;
                        display: inline-block;
                        background: #fff;
                        width: 16px;
                        height: 16px;
                        border-top: 1px solid #f1f5fc;
                        border-left: 1px solid #f1f5fc;
                        content: '';
                        transform: rotate(-45deg);
                        -webkit-transform: rotate(-45deg);
                        -moz-transform: rotate(-45deg);
                        -ms-transform: rotate(-45deg);
                        -o-transform: rotate(-45deg);
                    }

                    .chat li.right .chat-body:before {
                        position: absolute;
                        top: 10px;
                        right: -8px;
                        display: inline-block;
                        background: #fff;
                        width: 16px;
                        height: 16px;
                        border-top: 1px solid #f1f5fc;
                        border-right: 1px solid #f1f5fc;
                        content: '';
                        transform: rotate(45deg);
                        -webkit-transform: rotate(45deg);
                        -moz-transform: rotate(45deg);
                        -ms-transform: rotate(45deg);
                        -o-transform: rotate(45deg);
                    }

                    .chat li {
                        margin: 15px 0;
                    }

                    .chat li.right .chat-body {
                        margin-right: 70px;
                        background-color: #fff;
                    }

                    .chat-box {
                        /*position: absolute;*/
                        bottom: 0;
                        left: 444px;
                        right: 0;
                        padding: 15px;
                        border-top: 1px solid #eee;
                        transition: all .5s ease;
                        -webkit-transition: all .5s ease;
                        -moz-transition: all .5s ease;
                        -ms-transition: all .5s ease;
                        -o-transition: all .5s ease;
                    }

                    .primary-font {
                        color: #3c8dbc;
                    }

                    a:hover, a:active, a:focus {
                        text-decoration: none;
                        outline: 0;
                    }
                </style>
                <!--=========================================================-->
                <!-- selected chat -->
                <div class="lol col-md-12 bg-white ">
                    <div class="chat-message">
                        <ul class="chat">
                        </ul>
                    </div>
                    <div class="chat-box bg-white right">
                        <div class="input-group">
                            <input class="body form-control border no-shadow no-rounded" placeholder="Type your message here">
                            <span class="input-group-btn">
                                <button class="dd btn btn-success no-rounded" type="submit  ">Send</button>
                            </span>
                        </div><!-- /input-group -->
                    </div>
                </div>

            </div>


        </div>
    </div>

    <script type="text/javascript"  src="{{ CHAT_SERVER }}/socket.io/socket.io.js"></script>
    <script>
        $(document).ready(function(){

            function showStatus(text, status){
                if(!status){
                    swal(
                        'Oops...',
                        'Tidak dapat tersambung ke server. Silahkan coba lagi.',
                        'error');
                }

                else{
                    swal(text);
                    sweetAlert.showLoading();
                }
            }
            function appendNewChat(value){
                if(value.sender=={{ Auth::user()->id }}){
                    $('.chat').append('<li class="right clearfix"> <span class="chat-img pull-right"><img src="http://bootdey.com/img/Content/user_1.jpg" alt="User Avatar"></span><div class="chat-body clearfix"><div class="header"><a href="{{ url('user/'. Auth::user()->id) }}"><strong class="primary-font"> Anda </strong> </a><small class="pull-right text-muted"><i class="fa fa-clock-o"></i>' + moment(value.sent).fromNow() + '</small> </div> <p>' + value.msg + '</p> </div> </li>');
                }
                else{
                    $('.chat').append('<li class="left clearfix"> <span class="chat-img pull-left"><img src="http://bootdey.com/img/Content/user_1.jpg" alt="User Avatar"></span><div class="chat-body clearfix"><div class="header"><a href="{{ url('user/'. $user->id) }}"><strong class="primary-font"> {{ $user->name }} </strong> </a><small class="pull-right text-muted"><i class="fa fa-clock-o"></i>' + moment(value.sent).fromNow() + '</small> </div> <p>' + value.msg + '</p> </div> </li>');
                }
            }

            showStatus('Accessing credentials..', true);
            $.ajax({
                url: "{{ route('tokenreq') }}",
                xhrFields: {
                    withCredentials: true
                }
            })
                .fail(function (jqXHR, textStatus, errorThrown) {
                    showStatus(textStatus, false);
                })
                .done(function (result, textStatus, jqXHR) {
                    showStatus('Authenticating to chat server...', true);
                    var socket = io.connect('{{ CHAT_SERVER }}', {
                        'query': 'token=' + result.token
                    });

                    showStatus('Connected to SocketIO, Authenticating', true);
                    socket.on('handshake', function () {
                        swal({
                            allowOutsideClick: false,
                            type:'success',
                            text: 'Tersambung ke server',
                            showConfirmButton : false,
                            timer: 2000
                        });
                    });
                    socket.on('unauthorized', function (data) {
                        swal({
                            type:'error',
                            title : 'Error!',
                            text: 'Anda belum login. Silahkan login terlebih dahulu',
                            showConfirmButton : false,
                            timer: 3000,
                            allowOutsideClick : false
                        }).then(
                            function (dismiss) {
                                window.location = "{{ url('login') }}";
                            }
                        )
                    });

                    var room = '{{ Auth::user()->id }}-{{ $user->id }}';
                    var prepstat = '{ "room" : "' + room + '", "body" : "';
                    var closetag ='"}';
                    socket.on('connect_failed', function () {
                        swal({
                            type:'error',
                            title : 'Ups! Anda tidak dapat tersambung.',
                            html: 'Anda akan <i>diredirect</i> ke Home setelah beberapa saat.',
                            showConfirmButton : false,
                            timer: 3000,
                            allowOutsideClick : false
                        }).then(
                            function (dismiss) {
                                window.location = "{{ url('/') }}";
                            }
                        )
                    });

                    socket.emit('join-room', room);

                    socket.on('chathistory', function(data){
                        console.log(data);
                        $(data).each(function(index,value){
                            appendNewChat(value);
                        });
                    });

                    $('.dd').click(function(){
                        var msg = prepstat + $('.body').val() + closetag ;
                        $(".body").attr("disabled", true);
                        socket.emit('send', msg );
                        socket.on('send-status', function(data){
                            if(!data.status){
                                swal('Oops','Pesan anda tidak dapat terkirim, silahkan coba lagi','error');
                                $(".body").attr("disabled", false);
                            }
                            else if(data.status){
                                $('.body').val('');
                                $(".body").attr("disabled", false);

                            }

                        }, function(){
                            $(".body").attr("disabled", false);
                        });
                    });

                    socket.on('new-msg', function (value) {
                        appendNewChat(value);
                    });

                    socket.on("disconnect", function(){

                            swal({
                                allowOutsideClick: false,
                                type:'warning',
                                title : 'Menghubungkan..',
                                html: 'Koneksi anda sedang tidak stabil .. <br>' +
                                'Anda dapat kembali ke <a href="{{ url('/') }}" >Home</a>.'
                            });
                            swal.showLoading();

                    });
                });

        });


    </script>


@endsection

