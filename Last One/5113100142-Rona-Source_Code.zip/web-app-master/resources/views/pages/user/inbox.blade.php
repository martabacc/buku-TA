@extends('layouts.general')

@section('page_title')

@endsection
@section('content')

    @include('includes.navbar')

    <div class="row">

        <div class="container">

            @include('includes.general-leftcolumn')
            <div id="content" class="col-sm-9">
                <div class="page-header">
                    <h3><i class="fa fa-inbox" style="font-size:.8em"></i>   Kotak Pesan Anda</h3>
                </div>
                <style type="text/css">

    .bg-white {
      background-color: #fff;
    }

    .friend-list {
      list-style: none;
    /*margin-left: -40px;*/
    }

    .friend-list li {
      border-bottom: 1px solid #eee;
        padding-top:10px;
    }

    .friend-list li a img {
      float: left;
      width: 70px;
      margin-right: 0px;
    }

     .friend-list li a {
      position: relative;
      display: block;
      padding: 10px;
      transition: all .2s ease;
      -webkit-transition: all .2s ease;
      -moz-transition: all .2s ease;
      -ms-transition: all .2s ease;
      -o-transition: all .2s ease;
    }

    .friend-list li.active a {
      background-color: #f1f5fc;
    }

    .friend-list li a .friend-name, 
    .friend-list li a .friend-name:hover {
      color: #777;
    }

    .friend-list li a .last-message {
      width: 65%;
      white-space: nowrap;
      text-overflow: ellipsis;
      overflow: hidden;
    }

    .friend-list li a .time {
      position: absolute;
      top: 10px;
      right: 8px;
    }

    small, .small {
      font-size: 100%;
    }

    .friend-list li a .chat-alert {
      position: absolute;
      right: 8px;
      top: 27px;
      font-size: 1.2em;
      padding: 3px 5px;
    }

    .chat-message {
      padding: 60px 20px 115px;
    }

    .chat {
        list-style: none;
        margin: 0;
    }

    .chat-message{
        background: #f9f9f9;  
    }

    .chat li img {
      width: 45px;
      height: 45px;
      border-radius: 50em;
      -moz-border-radius: 50em;
      -webkit-border-radius: 50em;
    }

    img {
      max-width: 100%;
    }

    .chat-body {
      padding-bottom: 20px;
    }

    .chat li.left .chat-body {
      /*margin-left: 70px;*/
      background-color: #fff;
    }

    .chat li .chat-body {
      position: relative;
      font-size: 1.2em;
      padding: 10px;
      border: 1px solid #f1f5fc;
      box-shadow: 0 1px 1px rgba(0,0,0,.05);
      -moz-box-shadow: 0 1px 1px rgba(0,0,0,.05);
      -webkit-box-shadow: 0 1px 1px rgba(0,0,0,.05);
    }

    .chat li .chat-body .header {
      padding-bottom: 5px;
      border-bottom: 1px solid #f1f5fc;
    }

    .chat li .chat-body p {
      margin: 0;
    }

    .chat li.left .chat-body:before {
      position: absolute;
      top: 10px;
      left: -8px;
      display: inline-block;
      background: #fff;
      width: 16px;
      height: 16px;
      border-top: 1px solid #f1f5fc;
      border-left: 1px solid #f1f5fc;
      content: '';
      transform: rotate(-45deg);
      -webkit-transform: rotate(-45deg);
      -moz-transform: rotate(-45deg);
      -ms-transform: rotate(-45deg);
      -o-transform: rotate(-45deg);
    }

    .chat li.right .chat-body:before {
      position: absolute;
      top: 10px;
      right: -8px;
      display: inline-block;
      background: #fff;
      width: 16px;
      height: 16px;
      border-top: 1px solid #f1f5fc;
      border-right: 1px solid #f1f5fc;
      content: '';
      transform: rotate(45deg);
      -webkit-transform: rotate(45deg);
      -moz-transform: rotate(45deg);
      -ms-transform: rotate(45deg);
      -o-transform: rotate(45deg);
    }

    .chat li {
      margin: 15px 0;
    }

    .chat li.right .chat-body {
      margin-right: 70px;
      background-color: #fff;
    }

    a:hover, a:active, a:focus {
      text-decoration: none;
      outline: 0;
    }

    li:hover {
        background: lightgray;
    }
    </style>
                <div class="col-md-12 fluid-container bg-white" id="mapHere">
                    <!-- =============================================================== -->

                    <inbox :id={{ Auth::user()->id }}>
                    </inbox>
                </div>
        
        <!--=========================================================-->
        <!-- selected chat -->

            </div>
            

    </div>

        {{--<script src="{{ asset('js/manifest.js') }}"></script>--}}
        {{--<script src="{{ asset('js/vendor.js') }}"></script>--}}
        <script src="{{ asset('js/dependencies.js') }}"></script>
        <script src="{{ asset('js/chat.js') }}"></script>
<script>
</script> 


@endsection

