@extends('layouts.general')

@section('page_title')

@endsection

@section('content')

    @include('includes.navbar')

    <div class="row">

        <div class="container">

            <div id="content" class="col-sm-12">
                <div class="row">
                    <div class="col-sm-3">
                        <ul class="thumbnails">
                            <li>
                                <a class="thumbnail fancybox" title="iPod Classic">
                                    <img src="{{ url('image/profile-example.jpg') }}" title="iPod Classic" alt="iPod Classic">
                                </a>
                            </li>
                            <div id="product-thumbnail" class="owl-carousel owl-theme" style="opacity: 1; display: block;">
                                <div class="owl-wrapper-outer">
                                </div>
                            </div>
                        </ul>
                    </div>
                    <div class="col-sm-9" style="border: 1px solid #ddd">
                        <h3 class="page-header">
                            {{ $user->name }}
                            @if( $flag )
                                <strong>( Profil Anda )</strong>
                            @endif
                        </h3>
                        <ul class="list-unstyled product_info">
                            <li>
                                <label>Alamat : </label>
                                <span> {{ $user->address }}</span></li>
                            <li>
                                <label>Status :</label>
                                <span> {{ $user->isVerified() ? 'Terverifikasi' : 'Belum Terverifikasi' }}</span></li>
                            <li>
                                <label> Terdaftar sejak :</label>
                                <span> {{ $user->created_at }}</span></li>
                        </ul>
                            @if(!$flag)
                        <div id="product">
                            <div class="form-group">
                                <div class="">
                                    <a href="{{ route('chat.user', $user->id) }}">
                                        <button class="btn btn-primary"
                                                 <!--data-toggle="modal" data-target="#chat-modal" --> >
                                            <i class="fa fa-comments" aria-hidden="true"></i>
                                            Kirim Pesan
                                        </button>
                                    </a>
                                    <button class="btn btn-danger" data-toggle="modal" data-target="#modal">
                                        <span class="glyphicon glyphicon-warning-sign" aria-hidden="true"></span>
                                        Laporkan Pengguna</button>
                                </div>
                            </div>
                        </div>
                        @endif
                    </div>
                </div>
                <div class='container'>

                </div>
            </div>
        </div>
    </div>


    <div class="modal fade" id="modal"  role="dialog">
        <div class="modal-dialog" role="document"style="z-index: 1060">
            <div class="modal-content" >
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title">Laporkan Pengguna</h4>
                </div>

                <div class="modal-body row">
                    <div class="col-md-12">
                        <div class="col-md-4 col-xs-12">
                            <label>Tuliskan laporan anda</label>
                        </div>
                        <div class="col-md-8 col-xs-12">
                            <textarea id="laporBody" class="col-md-12 col-xs-12"></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <img src="{{ url('image/ajaxloading.gif') }}"  style="display:none; max-height:32px" class="ajaxloading" />
                    <button type="button" class="btn btn-default" data-dismiss="modal">Batal</button>
                    <button type="button" class="btn btn-primary click">Laporkan</button>
                </div>
            </div>
            <!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->

    <div class="modal fade" id="chat-modal"  role="dialog">
        <div class="modal-dialog" role="document"style="z-index: 1060">
            <div class="modal-content" >
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title">Kirim Pesan ke {{ $user->name }}
                    </h4>
                </div>

                <div class="modal-body row">

                    <div class="col-md-12">
                        <p class="pull-right">....atau lihat percakapan kalian disini
                            <a href="{{ route('chat.user', $user->id) }}">
                                <button class="btn btn-primary btn-sm">
                                    <i class="fa fa-envelope" aria-hidden="true"></i>
                                    Percakapan
                                </button>
                            </a>
                        </p>
                        <div class="col-md-8 col-xs-12">
                            <label>Pesan anda :</label>
                            <textarea id="chatmessage" placeholder="Pesan anda ...." class="col-md-12 col-xs-12"></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <img src="{{ url('image/ajaxloading.gif') }}"  style="display:none; max-height:32px" class="ajaxloading" />
                    <button type="button" class="btn btn-default" data-dismiss="modal">Batal</button>
                    <button type="button" class="btn btn-primary click">Kirimkan</button>
                </div>
            </div>
            <!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->

    <script>
        $(document).ready(function(){

            @if( Auth::check())
                function disableModal(){
                    $('#laporBody').prop('disabled', true);
                    $('.ajaxloading').css('display', 'block');
                    $('.click').prop('disabled', true);
                }
                function enableModal(){
                    $('#laporBody').prop('disabled', false);
                    $('.ajaxloading').css('display', 'none');
                    $('.click').prop('disabled', false);
                }

                $('.click').click(function(){
                    var lala = $('#laporBody').val();
                    disableModal();
                    $.ajax({
                        type : 'post',
                        url : '{{ url("ajax/report/user") }}',
                        data : { _token : '{{ csrf_token() }}', description : lala , id_user : {{ Auth::user()->id }}, id_issued_user : {{ $user->id }} },
                        success : function(data)
                        {   if(data.success){
                                swal({
                                    title: 'Terima kasih',
                                    text: 'Kami akan memproses secepatnya.',
                                    imageUrl: 'https://unsplash.it/400/200',
                                    imageWidth: 400,
                                    imageHeight: 200,
                                    animation: false
                                });
                            }
                            else{
                                swal('Oops', 'Maaf ada kesalahan, silahkan coba lagi','error');
                            }
                            enableModal();
                        }

                    });
                });
            @endif

        });
    </script>

@endsection

