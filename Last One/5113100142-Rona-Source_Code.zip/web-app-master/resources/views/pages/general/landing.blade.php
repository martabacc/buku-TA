<!DOCTYPE html>
<html lang="en">
<head>
    @include('includes.head')
</head>
<body>
<div class="preloader loader" style="display: block;"> <img src="image/loader.gif"  alt="#"/></div>
    @include('includes.header')
    @include('includes.navbar')
<div class="container col-2">

    <div class="row" id="allStartsHere">
        @include('includes.general-leftcolumn')
        <div id="content" class="col-sm-9">
            <div class="customtab">
                <div id="tabs" class="customtab-wrapper">
                    <ul class='customtab-inner'>
                        <li class='tab'><a href="#tab-latest">Lelang Panas</a></li>
                        <li class='tab'><a href="#tab-special">Barang Baru</a></li>
                    </ul>
                </div>

                <div id="tab-latest" class="tab-content" style="display: block;">
                    <div class="box">
                        <div id="latest-slidertab" class="row owl-carousel product-slider owl-theme" style="opacity: 1; display: block;">
                            @foreach($activebid as $item)
                                <a href="{{ route('item.show',$item->id) }}">
                                    <div class="item product-slider-item">
                                        <div class="product-thumb transition">

                                            <favorite :item={{ $item->id }} :favorited={{ Auth::check() && $item->favorited() ? 'true' : 'false' }}>
                                            </favorite>
                                        </div>
                                    </div>
                                 </a>
                            @endforeach
                        </div>
                    </div>
                            <div class="owl-controls clickable">
                                <div class="owl-buttons">
                                    <div class="owl-prev">prev</div>
                                    <div class="owl-next">next</div>
                                </div>
                            </div>
                        </div>
                <!-- tab-latest-->
                <div id="tab-special" class="tab-content">
                    <div class="box">
                        <div id="special-slidertab" class="row owl-carousel product-slider">

                        </div>
                    </div>
                </div>

                <h3 class="productblock-title">Hot Item</h3>
                <div class="box">
                    <div id="feature-slider" class="row owl-carousel product-slider">
                        @foreach($items as $item)
                            <a href="{{ route('item.show',$item->id) }}">
                                <div class="item product-slider-item">
                                    <div class="product-thumb transition">

                                        <favorite :item={{ $item->id }} :favorited={{ Auth::check() && $item->favorited() ? 'true' : 'false' }}>
                                        </favorite>
                                    </div>
                                </div>
                            </a>
                        @endforeach
                    </div>
                </div>
                <div class="blog">
                    <div class="blog-heading">
                        <h3>Latest Blogs</h3>
                    </div>
                    <div class="blog-inner box">
                        <ul class="list-unstyled blog-wrapper" id="latest-blog">
                            <li class="item blog-slider-item">
                                <div class="panel-default">
                                    <div class="blog-image"> <a href="#" class="blog-imagelink"><img src="image/blog/blog_1.jpg" alt="#"></a> <span class="blog-hover"></span> <span class="blog-date">06/07/2015</span> <span class="blog-readmore-outer"><a href="#" class="blog-readmore">read more</a></span> </div>
                                    <div class="blog-content"> <a href="#" class="blog-name">
                                            <h2>Nunc rutrum scel potent</h2>
                                        </a>
                                        <div class="blog-desc">Lorem ipsum doLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna.Lorem ipsum doLorem ipsum dolor sit amet, consectetur adipisicing...</div>
                                        <a href="#" class="blog-readmore">read more</a> <span class="blog-date">06/07/2015</span> </div>
                                </div>
                            </li>
                            <li class="item blog-slider-item">
                                <div class="panel-default">
                                    <div class="blog-image"> <a href="#" class="blog-imagelink"><img src="image/blog/blog_2.jpg" alt="#"></a> <span class="blog-hover"></span> <span class="blog-date">06/07/2015</span> <span class="blog-readmore-outer"><a href="#" class="blog-readmore">read more</a></span> </div>
                                    <div class="blog-content"> <a href="#" class="blog-name">
                                            <h2>Nunc rutrum scel potent</h2>
                                        </a>
                                        <div class="blog-desc">Lorem ipsum doLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna.Lorem ipsum doLorem ipsum dolor sit amet, consectetur adipisicing...</div>
                                        <a href="singale-blog.html" class="blog-readmore">read more</a> <span class="blog-date">06/07/2015</span> </div>
                                </div>
                            </li>
                            <li class="item blog-slider-item">
                                <div class="panel-default">
                                    <div class="blog-image"> <a href="#" class="blog-imagelink"><img src="image/blog/blog_3.jpg" alt="#"></a> <span class="blog-hover"></span> <span class="blog-date">06/07/2015</span> <span class="blog-readmore-outer"><a href="singale-blog.html" class="blog-readmore">read more</a></span> </div>
                                    <div class="blog-content"> <a href="#" class="blog-name">
                                            <h2>Nunc rutrum scel potent</h2>
                                        </a>
                                        <div class="blog-desc">Lorem ipsum doLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna.Lorem ipsum doLorem ipsum dolor sit amet, consectetur adipisicing...</div>
                                        <a href="singale-blog.html" class="blog-readmore">read more</a> <span class="blog-date">06/07/2015</span> </div>
                                </div>
                            </li>
                            <li class="item blog-slider-item">
                                <div class="panel-default">
                                    <div class="blog-image"> <a href="#" class="blog-imagelink"><img src="image/blog/blog_4.jpg" alt="#"></a> <span class="blog-hover"></span> <span class="blog-date">06/07/2015</span> <span class="blog-readmore-outer"><a href="#" class="blog-readmore">read more</a></span> </div>
                                    <div class="blog-content"> <a href="#" class="blog-name">
                                            <h2>Nunc rutrum scel potent</h2>
                                        </a>
                                        <div class="blog-desc">Lorem ipsum doLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna.Lorem ipsum doLorem ipsum dolor sit amet, consectetur adipisicing...</div>
                                        <a href="#" class="blog-readmore">read more</a> <span class="blog-date">06/07/2015</span> </div>
                                </div>
                            </li>
                            <li class="item blog-slider-item">
                                <div class="panel-default">
                                    <div class="blog-image"> <a href="#" class="blog-imagelink"><img src="image/blog/blog_5.jpg" alt="#"></a> <span class="blog-hover"></span> <span class="blog-date">06/07/2015</span> <span class="blog-readmore-outer"><a href="#" class="blog-readmore">read more</a></span> </div>
                                    <div class="blog-content"> <a href="#" class="blog-name">
                                            <h2>Nunc rutrum scel potent</h2>
                                        </a>
                                        <div class="blog-desc">Lorem ipsum doLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna.Lorem ipsum doLorem ipsum dolor sit amet, consectetur adipisicing...</div>
                                        <a href="#" class="blog-readmore">read more</a> <span class="blog-date">06/07/2015</span> </div>
                                </div>
                            </li>
                        </ul>
                        <div class="buttons text-right seeall">
                            <button class="btn btn-primary" onClick="location='blog.html';" type="button">See all Blogs</button>
                        </div>
                    </div>
                </div>
            </div>
            <div id="brand_carouse" class="owl-carousel brand-logo">
                <div class="item text-center"> <a href="#"><img src="image/brand/brand1.png" alt="Disney" class="img-responsive" /></a> </div>
                <div class="item text-center"> <a href="#"><img src="image/brand/brand2.png" alt="Dell" class="img-responsive" /></a> </div>
                <div class="item text-center"> <a href="#"><img src="image/brand/brand3.png" alt="Harley" class="img-responsive" /></a> </div>
                <div class="item text-center"> <a href="#"><img src="image/brand/brand4.png" alt="Canon" class="img-responsive" /></a> </div>
                <div class="item text-center"> <a href="#"><img src="image/brand/brand5.png" alt="Canon" class="img-responsive" /></a> </div>
                <div class="item text-center"> <a href="#"><img src="image/brand/brand6.png" alt="Canon" class="img-responsive" /></a> </div>
                <div class="item text-center"> <a href="#"><img src="image/brand/brand7.png" alt="Canon" class="img-responsive" /></a> </div>
                <div class="item text-center"> <a href="#"><img src="image/brand/brand8.png" alt="Canon" class="img-responsive" /></a> </div>
                <div class="item text-center"> <a href="#"><img src="image/brand/brand9.png" alt="Canon" class="img-responsive" /></a> </div>
                <div class="item text-center"> <a href="#"><img src="image/brand/brand5.png" alt="Canon" class="img-responsive" /></a> </div>
            </div>
        </div>
    </div>
</div>
<footer>
    <div class="container">
        <div class="footer-top-cms">
            <div class="footer-logo"> <a href="#"><img alt="index.html" src="image/logo-footer.png"></a> </div>
            <div class="footer-desc"> <span>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. </span> </div>
            <div class="footer-social">
                <h5>Social</h5>
                <ul>
                    <li class="facebook"><a href="#"><i class="fa fa-facebook"></i></a></li>
                    <li class="linkedin"><a href="#"><i class="fa fa-linkedin"></i></a></li>
                    <li class="twitter"><a href="#"><i class="fa fa-twitter"></i></a></li>
                    <li class="gplus"><a href="#"><i class="fa fa-google-plus"></i></a></li>
                    <li class="youtube"><a href="#"><i class="fa fa-youtube-play"></i></a></li>
                </ul>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-3 footer-block">
                <h5 class="footer-title">Information</h5>
                <ul class="list-unstyled ul-wrapper">
                    <li><a href="about-us.html">About Us</a></li>
                    <li><a href="checkout.html">Delivery Information</a></li>
                    <li><a href="#">Privacy Policy</a></li>
                    <li><a href="#">Terms &amp; Conditions</a></li>
                </ul>
            </div>
            <div class="col-sm-3 footer-block">
                <h5 class="footer-title">Customer Service</h5>
                <ul class="list-unstyled ul-wrapper">
                    <li><a href="contact.html">Contact Us</a></li>
                    <li><a href="#">Returns</a></li>
                    <li><a href="#">Site Map</a></li>
                    <li><a href="#">Wish List</a></li>
                </ul>
            </div>
            <div class="col-sm-3 footer-block">
                <h5 class="footer-title">Extras</h5>
                <ul class="list-unstyled ul-wrapper">
                    <li><a href="#">Brands</a></li>
                    <li><a href="gift.html">Gift Vouchers</a></li>
                    <li><a href="affiliate.html">Affiliates</a></li>
                    <li><a href="#">Specials</a></li>
                </ul>
            </div>
            <div class="col-sm-3 footer-block">
                <div class="content_footercms_right">
                    <div class="footer-contact">
                        <h5 class="contact-title footer-title">Contact Us</h5>
                        <ul class="ul-wrapper">
                            <li><i class="fa fa-map-marker"></i><span class="location2"> Warehouse & Offices,<br>
                                12345 Street name, California<br>
                                USA</span></li>
                            <li><i class="fa fa-envelope"></i><span class="mail2"><a href="#">info@localhost.com</a></span></li>
                            <li><i class="fa fa-mobile"></i><span class="phone2">+ 0987-654-321</span></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <a id="scrollup">Scroll</a> </footer>


<div class="footer-bottom">
    <div class="container">
        <div class="copyright">Powered By<a class="yourstore" href="http://www.lionode.com/">lionode &copy; 2016 </a> </div>
        <div class="footer-bottom-cms">
            <div class="footer-payment">
                <ul>
                    <li class="mastero"><a href="#"><img alt="" src="image/payment/mastero.jpg"></a></li>
                    <li class="visa"><a href="#"><img alt="" src="image/payment/visa.jpg"></a></li>
                    <li class="currus"><a href="#"><img alt="" src="image/payment/currus.jpg"></a></li>
                    <li class="discover"><a href="#"><img alt="" src="image/payment/discover.jpg"></a></li>
                    <li class="bank"><a href="#"><img alt="" src="image/payment/bank.jpg"></a></li>
                </ul>
            </div>
        </div>
    </div>
</div>
</body>
<script src="{{ asset('js/dependencies.js') }}"></script>
<script src="{{ asset('js/favorites.js') }}"></script>
</html>
