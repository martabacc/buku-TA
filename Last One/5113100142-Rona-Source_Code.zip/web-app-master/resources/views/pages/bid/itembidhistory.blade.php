@extends('layouts.general')

@section('content')

    <div class="container">
        <div class="row">

            @include('includes.navbar')
            @include('includes.item-navbar')

            <div id="content" class="col-sm-9">

                <div class="row">
                    <div class="col-sm-12" id="content">
                        <h1 class="page-title">  Lihat Riwayat Lelang </h1>

                        <hr>
                        <div class="product-layout product-list col-xs-12">
                            <div class="product-thumb">
                                <div class="image product-imageblock"> <a href="product.html"> <img src="image/product/pro-1-220x294.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> </a>
                                </div>
                                <div class="caption product-detail">
                                    <h4 class="product-name"> <a href="{{ route('item.show', $item->id ) }}" title="iPod Classic"> {{  $item->name }} </a> </h4>
                                    <p class="product-desc">
                                        {{  $item->description }}
                                    </p>
                                    <p class="price product-price">
                                        Harga Awal : Rp. {{  number_format($item->starting_price) }}
                                        <br>
                                </div>
                            </div>
                        </div>


                        <hr>

                        <h2 class='page-subtitle'>Daftar Penawaran</h2>
                        <table id="table_id" class="display">
                            <thead>
                            {{-- <th>#</th> --}}
                            <th>Harga yang Ditawarkan</th>
                            {{-- <th>#</th> --}}
                            <th>Penawar</th>
                            <th>Penawar</th>
                            <th>Waktu Penawaran</th>
                            </thead>
                            <tbody>
                            </tbody>
                        </table>
                    </div>
                </div>


            </div>
        </div>
    </div>

    </div>

    <link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.10.13/css/jquery.dataTables.css">

    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.13/js/jquery.dataTables.min.js"></script>

    <script type="text/javascript">
        $(document).ready( function () {
            moment.updateLocale('en', {
                months : 'Januari_Februari_Maret_April_Mei_Juni_Juli_Agustus_September_Oktober_November_Desember'.split('_'),
                monthsShort : 'Jan_Feb_Mar_Apr_Mei_Jun_Jul_Ags_Sep_Okt_Nov_Des'.split('_'),
                weekdays : 'Minggu_Senin_Selasa_Rabu_Kamis_Jumat_Sabtu'.split('_'),
                weekdaysShort : 'Min_Sen_Sel_Rab_Kam_Jum_Sab'.split('_'),
                weekdaysMin : 'Mg_Sn_Sl_Rb_Km_Jm_Sb'.split('_'),
                longDateFormat : {
                    LT : 'HH.mm',
                    LTS : 'HH.mm.ss',
                    L : 'DD/MM/YYYY',
                    LL : 'D MMMM YYYY',
                    LLL : 'D MMMM YYYY [pukul] HH.mm',
                    LLLL : 'dddd, D MMMM YYYY [pukul] HH.mm'
                },
                meridiemParse: /pagi|siang|sore|malam/,
                meridiemHour : function (hour, meridiem) {
                    if (hour === 12) {
                        hour = 0;
                    }
                    if (meridiem === 'pagi') {
                        return hour;
                    } else if (meridiem === 'siang') {
                        return hour >= 11 ? hour : hour + 12;
                    } else if (meridiem === 'sore' || meridiem === 'malam') {
                        return hour + 12;
                    }
                },
                meridiem : function (hours, minutes, isLower) {
                    if (hours < 11) {
                        return 'pagi';
                    } else if (hours < 15) {
                        return 'siang';
                    } else if (hours < 19) {
                        return 'sore';
                    } else {
                        return 'malam';
                    }
                },
                calendar : {
                    sameDay : '[Hari ini pukul] LT',
                    nextDay : '[Besok pukul] LT',
                    nextWeek : 'dddd [pukul] LT',
                    lastDay : '[Kemarin pukul] LT',
                    lastWeek : 'dddd [lalu pukul] LT',
                    sameElse : 'L'
                },
                relativeTime : {
                    future : 'dalam %s',
                    past : '%s sebelum akhir lelang',
                    s : 'beberapa detik',
                    m : 'semenit',
                    mm : '%d menit',
                    h : 'sejam',
                    hh : '%d jam',
                    d : 'sehari',
                    dd : '%d hari',
                    M : 'sebulan',
                    MM : '%d bulan',
                    y : 'setahun',
                    yy : '%d tahun'
                },
            });

            @if(session('error'))
                 swal('Oops', '{{   session('error') }}', 'error');
            @elseif(session('success'))
                swal('Sukses!', '{{   session('success') }}', 'success');
                    @endif

            var listBid = [];
            $.getJSON( '{{  url("ajax/getitembidlist/". $item->id) }}', function( data ) {

                $.each( data, function( key, val ) {
                    listBid.push([ val.price_bid, val.name , val.id_user , val.bid_timestamp]   );
                });

                $('#table_id').DataTable({
                    data: listBid,
                    columnDefs: [
                        {
                            targets:0,
                            render: $.fn.dataTable.render.number( ',', '.', 2, 'Rp. ' )
                        },
                        {   targets : 1,
                            render :  function ( data, type, row ) {
                                return '<a href="'+ row[2]+ '">' + data + '<a>';
                            }
                        },
                        { targets : [2], visible: false },
                        {
                            data: null, targets : 3,
                            render :  function ( data, type, row ) {
                                return moment('{{$item->end_time}}').to(moment(row[3]));
                            }
                        }
                    ],
                    order : [[3, 'asc']]
                });

            });


        });
    </script>
@endsection


