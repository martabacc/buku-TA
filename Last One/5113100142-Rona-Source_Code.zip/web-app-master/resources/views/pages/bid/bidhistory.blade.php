@extends('layouts.general')


@section('content')

    @include('includes.navbar')

    <div class="row">
        <div class="container">

            @include('includes.general-leftcolumn')

            <div id="content" class="col-sm-9">
                <table class="table table-responsive table-hover" id="bidhistory-table">
                    <thead style="font-size: 1.7rem;">
                        <tr>
                            <th class="text-center"><b>Barang</b></th>
                            <th class="text-center"><b>Penawaran ( Status )</b></th>
                            <th class="text-center"><b>Status Lelang</b></th>
                            <th class="text-center"><b>Waktu Lelang</b></th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($results as $bid)
                          <tr class="{{ $bid->win_status ? 'success' : ($bid->bid_status==-1 ? '': 'warning' ) }}">
                            <td class="text-center">
                                <a href="{{ route('item.show', $bid->id_item) }}">
                                    <img class="img-thumbnail" title="iPhone" alt="iPhone" src="image/product/2product50x59.jpg">
                                        <br>
                                        {{  $bid->name }}
                                </a>
                            </td>
                            <td class="text-center">
                                Rp. {{ number_format($bid->price_bid) }} ( {{ $bid->win_status ? 'Menang' : 'Tidak memenangkan penawaran' }} )
                                <br>
                                @if($bid->win_status)
                                    <button class="btn btn-xs btn-primary action" data-action="review" data-bid="{{ $bid->bid_id_r }}">Beri Review</button>
                                    <button class="btn btn-xs btn-primary action" data-action="coupon" data-bid="{{ $bid->bid_id_r }}">Masukkan Kupon</button>
                                @endif
                            </td>
                            <td class="text-left">
                                @if($bid->bid_status==-1)
                                    <a class="btn btn-sm btn-info">Sudah selesai</a>
                                @else
                                    <a class="btn btn-sm btn-success">Masih berjalan</a>
                                @endif
                            </td>
                            <td class="text-center">
                                {{ date_format(DateTime::createFromFormat('Y-m-d H:i:s', explode('+',$bid->max)[0]),"d F Y H:i") }}
                            </td>
                          </tr>
                      @endforeach
                    </tbody>
                  </table>

            </div>
        </div>
    </div>
@endsection

@section('custom-scripts')

    <script type="text/javascript">
        $(document).ready(function(){

            function showStatus(text, status){
                if(!status){
                    swal(
                        'Oops...',
                        (text) ? text : "Tidak dapat tersambung ke server. Silahkan coba lagi.",
                        'error');
                }
                else{
                    swal(text);
                    swal.showLoading();
                }
            }
            function showInformation(title, text){
                swal(
                    title,
                    text,
                    'info'
                )
            }
            function dumpAbort(title, text){

                swal(
                    (title) ? title : 'Oops...',
                    (text) ? text : "Tidak dapat tersambung ke server. Silahkan coba lagi.",
                    'error')
                    .then(function(){
                        window.location= "{{ url('/') }}";
                    });


            }

            var token = function () {
                var tmp = null;
                $.ajax({
                    url: "{{ route('tokenreq') }}",
                    xhrFields: {
                        withCredentials: true
                    }
                })
                    .fail(function (jqXHR, textStatus, errorThrown) {
                        tmp = false ;
                    })
                    .done(function (result, textStatus, jqXHR){
                        swal(token);
                        tmp = result.token;
                    });
                return tmp;
            }();




           $(".action").click(function(){
               var action = $(this).data('action');
               var bid = $(this).data('bid');
               showStatus('Checking credentials...',true);
               $.ajax({
                   url : "{{ url('bidhistory/status') }}/" + bid,
                   xhrFields: {
                       withCredentials: true
                   }
               })
               .fail(function (jqXHR, textStatus, errorThrown)
               {
                   showStatus(textStatus, false);
                   console.log('fucking failed');
               })
               .done(function (res, textStatus, jqXHR) {
                   var stat = res;
                   if(!stat.status){
                       dumpAbort('Error!', stat.msg);
                   }
                   else {
                       var status = res.result;
                       if(action=="review"){
                           if(status.review) showStatus ('Anda sudah pernah memberikan review untuk transaksi ini!', false);
                           else{
                               swal.setDefaults({
                                   input: 'text',
                                   confirmButtonText: 'Next &rarr;',
                                   showCancelButton: true,
                                   animation: false,
                                   progressSteps: ['1','2']
                               });

                               var steps = [
                                   {
                                       title: 'Rating',
                                       text: 'Beri rating untuk transaksi ini',
                                       input: 'range',
                                       inputAttributes: {
                                           min: 1,
                                           max: 5,
                                           step: 1
                                       },
                                       inputValue: 3
                                   },
                                   {
                                       title: 'Review',
                                       text: '(Optional) Beri komentar untuk transaksi ini..',
                                       input: 'textarea'
                                   }
                               ];

                               swal.queue(steps).then(function (result) {
                                   alert(JSON.stringify(result));
                                   swal.resetDefaults();
                                   $.ajax({
                                       url : "{{ url('review/submit') }}/" + bid,
                                       data: { info : JSON.stringify(result) },
                                       xhrFields: {
                                           withCredentials: true
                                       }
                                   })
                                       .fail(function (jqXHR, textStatus, errorThrown) {
                                           dumpAbort("Oops","Kesalahan server, silahkan coba lagi");
                                       })
                                       .done(function (result, textStatus, jqXHR) {
                                           if(result.valid)
                                               swal('Sukses!','Review anda berhasil disimpan.','success');
                                           else
                                           {
                                               var constructString = '';
                                               $(result.msg).each(function(t){
                                                   constructString = constructString + t;
                                                });
                                               showStatus(constructString, false);
                                               return false;
                                           }
                                           return true;
                                       });
                               }, function (status)
                               {
                                   if(status) swal.resetDefaults();
                               });
                           }
                       }
                       else if(action=='coupon'){
                           if(status.coupon)
                           {
                               $.ajax({
                                   url : "{{ url('ajax/coupon/usages') }}/" + bid,
                                   data: { token : token},
                                   xhrFields: {
                                       withCredentials: true
                                   }
                               })
                               .done(function (result, textStatus, errorThrown)
                               {
                                   if(result.valid)
                                       showInformation("Oops!",result.msg);
                                       else dumpAbort('Maaf terjadi kesalahan, silahkan coba lagi.');
                               })
                               .fail(function (jqXHR, textStatus, errorThrown)
                               {
                                   dumpAbort('Error',textStatus);
                               });
                           }
                           else{
                               swal({
                                   title: 'Masukkan kupon',
                                   input: 'text',
                                   showCancelButton: true,
                                   inputValidator: function (value) {
                                       return new Promise(function (resolve, reject) {
                                           if (value) {
                                               resolve()
                                           } else {
                                               reject('Kupon tidak boleh kosong!')
                                           }
                                       })
                                   }
                               }).then(function (couponName) {
                                   $.ajax({
                                       url : "{{ route('coupon.submit') }}",
                                       type : 'post',
                                       data: { token : token,
                                                _token : "{{ csrf_token() }}",
                                                bid : bid ,
                                                coupon: "couponName" },
                                       xhrFields: {
                                           withCredentials: true
                                       }
                                   })
                                       .fail(function (jqXHR, textStatus, errorThrown) {
                                           return new Promise(function (resolve, reject) {
                                               if (value) {
                                                   resolve()
                                               } else {
                                                   reject(errorThrown)
                                               }
                                           });

                                       })
                                       .done(function (result, textStatus, jqXHR) {
                                           var resp = JSON.parse(result);

                                           if(resp.status){
                                               var msgShow;
                                               if(resp.new_price == -1) msgShow = 'Anda mendapat promo ongkos kirim';
                                               else if(resp.new_price>0) msgShow = 'Harga barang menjadi ' + result.new_price;
                                               msgShow = msgShow +  "Anda akan dihubungi admin untuk lebih lanjutnya :)";

                                               swal(
                                                   'Sukses!',
                                                   msgShow,
                                                   'success'
                                               );
                                           }
                                           else showStatus(resp.msg, false);
                                       });
                               })
                           }
                       }
                   }
               });
               });


        });
    </script>
@endsection


