
<div class="col-sm-8">
    <h1 class="page-title"> {{ $item->name }} </h1>
    <ul class="list-unstyled product_info">
        <li>
            <label>{{ trans('item.starting_price') }}</label>
            <span><span class="productinfo-tax">Rp. {{ number_format($item->starting_price) }}</span>
        </li>
        <li>
            <label>Akhir lelang :</label>
            <span> {{ $item->end_time }}</span></li>
    </ul>
    @if($item->bid_status==1)
        <ul class="list-unstyled productinfo-details-top">
            <li>
                <div class="col-sm-5 col-sm-offset-3">
                    <h2 class="bg-success text-center" >Rp.
                        <span class='priceongoing'> {{ number_format($currentPrice->bid_price) }} </span>
                    </h2>
                    <p class="text-center">
                        Penawar : <a href='{{  url("user/".$currentPrice->id_user) }}'>
                            <span class='winninguser'>{{  $currentPrice->name }}</span>
                        </a>
                    </p>
                </div>

                <div id="product">
                    @if(Auth::user()->id != $item->id_user )
                        <div class="form-group">
                            <label for="input-firstname" class="col-sm-2 control-label">{{ trans('item.bid_this_item') }}<br></label>
                            <div class="col-sm-6">
                                <input type="number" class="form-control"  id="submitted_price"  >
                            </div>
                            <div class="col-sm-4">
                                <button type="button" data-toggle="tooltip" class="btn btn-default compare tawar" title="">Tawar</button>
                            </div>
                        </div>
                    @endif
                    <br>
                </div>
                <div class="clearfix"></div>
                <div class="col-sm-12">
                    <div class="col-sm-4">

                        <button class="btn btn-md btn-primary incr1">
                            Tawarkan
                            <br>
                            Rp. <span id="increment-price-1">10000</span>
                        </button>
                    </div>
                    <div class="col-sm-4">

                        <button class="btn btn-md btn-primary incr2">
                            Tawarkan
                            <br>
                            Rp. <span id="increment-price-2">20000</span>
                        </button>
                    </div>
                    <div class="col-sm-4">

                        <button class="btn btn-md btn-success" id="button-buyout">
                            Buyout seharga
                            <br>
                            Rp. {{ number_format($item->expected_price) }}
                            <form method="post" style="display:none" id="xkcd">
                                {{ csrf_field() }}
                            </form>
                        </button>
                    </div>
                </div>
            </li>
            @if(Auth::user()->id == $item->id_user)
                <li>
                    <a href='{{  url('choosewinner', $item->id) }}'>
                        <button type="button" class="btn btn-lg btn-primary">Pilih Pemenang</button>
                    </a>
                </li>
            @endif
        </ul>
    @elseif($item->cancel_status)
        <div id="product">
            <div class="col-sm-12">
                <label for="input-firstname" class="btn btn-danger">
                    Pelelangan barang ini dibatalkan oleh penjual.
                </label>
            </div>
        </div>

    @elseif($item->bid_status==0)
        <ul class="list-unstyled productinfo-details-top">
            <li>
                </h1>
                <h1 class="productpage-price">Harga Awal : Rp. {{ $item->starting_price }}</h1>
            </li>
        </ul>

    @elseif($item->bid_status==-1 && $item->winner_chosen_status)
        <ul class="list-unstyled productinfo-details-top">
            <li>
                {{-- todo --}}
                <h1 class="productpage-price winninguser">
                    Pemenang : <a href='{{  url("user/".$item->id_user) }}'>
                        {{  $winnername }}
                    </a>
                </h1>
                <h1 class="productpage-price">Harga Final : Rp. {{ $item->bid_price }}</h1>
            </li>
            <li>
                <label for="input-firstname" class="control-label">
                    Masa lelang barang ini sudah selesai.
                </label>
            </li>
        </ul>

        <div id="product">
        </div>

    @elseif($item->bid_status==-1 && !$item->winner_chosen_status)
        <ul class="list-unstyled productinfo-details-top">
            <li>
                <h1 class="productpage-price winninguser">
                    Penawar Tertinggi : <a href='{{  url("user/".$currentPrice->id_user) }}'>
                        {{  $currentPrice->name }}
                    </a>
                </h1>
            </li>
            <li>
                <h1 class="productpage-price">Harga Final : Rp. {{ $currentPrice->bid_price }}</h1>
            </li>
            <li>
                <label for="input-firstname" class="control-label">
                    Masa lelang barang ini sudah selesai, namun pemenang lelang belum ditentukan penjual.
                </label>
            </li>
            <li>
                <a href='{{  url('itembidhistory/', $item->id) }}'>
                    <button type="button" class="addtocart-btn">Riwayat Lelang</button>
                </a>
            </li>
            @if(Auth::user()->id == $item->id_user)
                <li>
                    <a href='{{  url('choosewinner/', $item->id) }}'>
                        <button type="button" class="addtocart-btn">Pilih Pemenang</button>
                    </a>
                </li>
            @endif
        </ul>
    @elseif($item->bid_status==-1 && !$item->winner_chosen_status)
        <ul class="list-unstyled productinfo-details-top">
            <li>
                <h1 class="productpage-price winninguser">
                    Penawar Tertinggi : <a href='{{  url("user/".$currentPrice->id_user) }}'>
                        {{  $currentPrice->name }}
                    </a>
                </h1>
            </li>
            <li>
                <h1 class="productpage-price">Harga Final : Rp. {{ $currentPrice->bid_price }}</h1>
            </li>
            <li>
                <label for="input-firstname" class="control-label">
                    Masa lelang barang ini sudah selesai, namun pemenang lelang belum ditentukan penjual.
                </label>
            </li>
            <li>
                <a href='{{  url('itembidhistory/', $item->id) }}'>
                    <button type="button" class="addtocart-btn">Riwayat Lelang</button>
                </a>
            </li>
            @if(Auth::user()->id == $item->id_user)
                <li>
                    <a href='{{  url('choosewinner/', $item->id) }}'>
                        <button type="button" class="addtocart-btn">Pilih Pemenang</button>
                    </a>
                </li>
            @endif
        </ul>


    @endif

</div>