@section('custom-scripts')
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js"></script>
    <script src="{{ BID_SERVER }}/socket.io/socket.io.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.18.1/moment.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/countdown/2.6.0/countdown.min.js"></script>
    <script src="{{ url('timely-script/moment-countdown.min.js') }}"></script>
    <script>
        $(window).load(function(){

                var time = "{{ $item->end_time }}";
                time = moment(time).countdown().toString();
                var min_price = 1000;
                console.log(time);
                //place your code here, the scripts are all loaded
                function showStatus(text, status){
                    if(!status){
                        swal(
                            'Oops...',
                            'Tidak dapat tersambung ke server. Silahkan coba lagi.',
                            'error');
                    }

                    else{
                        swal(text);
                        sweetAlert.showLoading();
                    }
                }

                function numberWithCommas(price){
                    return price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
                }

                function updatePriceOnButton(){

//                  updating price
                    $.ajax({
                        url: "{{ route('price.suggestion', $item->id) }}",
                        xhrFields: {
                            withCredentials: true
                        }
                    })
                        .fail(function (jqXHR, textStatus, errorThrown) {
                            toastr.info('Debugging');
                        })
                        .done(function (result, textStatus, jqXHR) {
//                                        console.log(result[0]);
//                                        console.log(result[1]);
                            $('#increment-price-1').html(numberWithCommas(result[0]));
                            $('#increment-price-2').html(numberWithCommas(result[1]));
                        });
                };

                function numberWithCommas(price){
                    return price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
                }
                showStatus('Connecting to server...', true);

                $.ajax({
                    url: "{{ route('tokenreq') }}",
                    xhrFields: {
                        withCredentials: true
                    }
                })
                    .fail(function (jqXHR, textStatus, errorThrown) {
                        showStatus(textStatus, false);
                    })
                    .done(function (result, textStatus, jqXHR) {
                        showStatus('Authenticating to chat server...', true);
                        var socket = io.connect('{{ BID_SERVER }}', {
                            'query': 'token=' + result.token
                        });

                        showStatus('Connected to SocketIO, Authenticating', true);

                        socket.on('connected', function ()
                        {
                            toastr.success('Selamat lelang, {{ Auth::user()->name }} ');
                            socket.emit('join-room', '{{  $item->id }}');
                            updatePriceOnButton();
                            swal.close();
                        });

                        socket.on('unauthorized', function (data) {
                            swal({
                                type:'error',
                                title : 'Error!',
                                text: 'Anda belum login. Silahkan login terlebih dahulu',
                                showConfirmButton : false,
                                timer: 3000,
                                allowOutsideClick : false
                            }).then(
                                function (dismiss) {
                                    window.location = "{{ url('register') }}";
                                }
                            )
                        });

                        socket.on('connect_failed', function ()
                        {
                            toastr.error('Koneksi tidak stabil... ');
                            swal({
                                type:'error',
                                title : 'Ups! Anda tidak dapat tersambung.',
                                html: 'Anda akan <i>diredirect</i> ke Home setelah beberapa saat.',
                                showConfirmButton : false,
                                timer: 3000,
                                allowOutsideClick : false
                            }).then(
                                function (dismiss) {
                                    window.location = "{{ url('/') }}";
                                }
                            )
                        });

                        $('.tawar').click(function()
                        {
                            var harga = $('#submitted_price').val();
                            var priceNow = parseFloat(($('.priceongoing').html()).replace(/,/g, ''));

                            if(harga==""){
                                swal(
                                    'Oops...',
                                    'Anda belum memasukkan harga lelang!',
                                     'error'
                                );
                            }
                            else if(harga<priceNow) {
                                swal(
                                    'Oops...',
                                    'Harga yang anda masukkan lebih kecil dari harga tertinggi',
                                    'error'
                                );
                            }
                            else if( (harga - priceNow) < min_price || (harga) % min_price != 0 ) {

                                swal(
                                    'Oops...',
                                    "Nominal tawaran anda harus diatas Rp. " + numberWithCommas(min_price) + "<br>dan harus valid.",
                                    'error'
                                );
                            }
                            else {
                                var prepstat = '{ "id_bidder" : {{ Auth::user()->id }}, "id_item" : {{ $item->id }}, "harga_bid" : ';
                                socket.emit('submitbid', prepstat + harga + '}');
//                                    function()
//                                    {

                                socket.on('bidfailed', function (result) {
                                    swal(
                                        'Oops...',
                                        'Maaf, terjadi kesalahan. Coba ulangi lagi.',
                                        'error'
                                    );
                                });

                                socket.on('bidsuccess', function (result) {
                                    toastr.info('Penawaran baru masuk!');
                                    $('.priceongoing').html( numberWithCommas(result.bid_price_return) );
                                    $('.winninguser').html(result.bidder_name_return);

//                                    updating price
                                    $.ajax({
                                        url: "{{ route('price.suggestion', $item->id) }}",
                                        xhrFields: {
                                            withCredentials: true
                                        }
                                    })
                                    .fail(function (jqXHR, textStatus, errorThrown) {
                                        toastr.info('Debugging');
                                    })
                                    .done(function (result, textStatus, jqXHR) {
//                                        console.log(result[0]);
//                                        console.log(result[1]);
                                        $('#increment-price-1').html(result[0]);
                                        $('#increment-price-2').html(result[1]);
                                    });
                                });
                            }
                        });

                        socket.on("disconnect", function(){

                            swal({
                                allowOutsideClick: false,
                                type:'warning',
                                title : 'Menghubungkan..',
                                html: 'Koneksi anda sedang tidak stabil .. <br>' +
                                'Anda dapat kembali ke <a href="{{ url('/') }}" >Home</a>.'
                            });
                            swal.showLoading();
                        });
                    });



            function disableModal(){
                $('#laporBody').prop('disabled', true);
                $(".js-data-example-ajax").prop('disabled', true);
                $('#ajaxloading').show();
                $('.click').prop('disabled', true);
            }
            function enableModal(){
                $('#laporBody').prop('disabled', false);
                $(".js-data-example-ajax").prop('disabled', false);
                $('#ajaxloading').hide();
                $('.click').prop('disabled', false);
            }

            $('#button-buyout').click(function(){
                swal({
                    title: 'Buyout barang?',
                    text: "Apakah anda yakin ingin buyout barang ini?",
                    type: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    cancelButtonText: 'Batal',
                    confirmButtonText: 'Ya'
                }).then(function () {
                    $('#xkcd').submit();
                });
            });

            $('.incr1').click(function(){
                $('#submitted_price').val( parseFloat(($('.priceongoing').html()).replace(/,/g, '')) +
                                            parseFloat(($('#increment-price-1').html()).replace(/,/g, '')) );
                $('.tawar').click();
            });
            $('.incr2').click(function(){
                $('#submitted_price').val( parseFloat(($('.priceongoing').html()).replace(/,/g, '')) +
                    parseFloat(($('#increment-price-2').html()).replace(/,/g, '')) );
                $('.tawar').click();
            });

            disableModal();

            $.ajax({
                type : 'get',
                dataType:'json',
                url : '{{ route("report.types") }}',
                success : function(data)
                {
                    $(".js-data-example-ajax").select2({
                        data : data
                    });
                    enableModal();
                }

            });



            @if( Auth::check())
            $('.click').click(function(){
                var lala = $('#laporBody').val();
                disableModal();
                $.ajax({
                    type : 'post',
                    url : '{{ url("ajax/report/item") }}',
                    data : { _token : '{{ csrf_token() }}', description : lala , id_user : {{ Auth::user()->id }}, id_issued_object : {{ $item->id }}, id_issue_type:$('.js-data-example-ajax').val() },
                    success : function(data)
                    {   if(data.success){
                        swal({
                            title: 'Terima kasih',
                            text: 'Kami akan memproses secepatnya.',
                            imageUrl: 'https://unsplash.it/400/200',
                            imageWidth: 400,
                            imageHeight: 200,
                            animation: false
                        });
                    }
                    else{
                        swal('Oops', 'Maaf ada kesalahan, silahkan coba lagi','error');
                    }
                        enableModal();
                        $('#modal').close();
                    }

                });
            });
            @endif
            @if(session('error'))
                 swal('Oops', '{{   session('error') }}', 'error');
            @elseif(session('fail'))
                 swal('Oops', '{{   session('fail') }}', 'error');
            @elseif(session('success'))
                swal('Sukses!', '{{   session('success') }}', 'success');
            @endif
        });


    </script>

@endsection