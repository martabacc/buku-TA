        @extends('layouts.general')

    @section('content')

    <div class="container">
        <div class="row">

            @include('includes.navbar')
            @include('includes.item-navbar')

            <div id="content" class="col-sm-9">

            <div class="row">
                <div class="col-sm-12" id="content">
                    <h1 class="page-title">  Pilih Pemenang Lelang </h1>

                    <hr>
                    <div class="product-layout product-list col-xs-12">
                              <div class="product-thumb">
                                <div class="image product-imageblock"> <a href="product.html"> <img src="image/product/pro-1-220x294.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> </a>
                                </div>
                                <div class="caption product-detail">
                                  <h4 class="product-name"> <a href="{{ route('item.show', $item->id ) }}" title="iPod Classic"> {{  $item->name }} </a> </h4>
                                  <p class="product-desc">
                                    {{  $item->description }}
                                  </p>
                                  <p class="price product-price">
                                            Harga Awal : Rp. {{  number_format($item->starting_price) }}
                                        <br>
                                            Harga yang Diinginkan : Rp. {{  number_format($item->expected_price) }}
                                </div>
                            </div>
                        </div>


                        <hr>

                        <h2 class='page-subtitle'>Daftar Penawaran</h2>
                        <table id="table_id" class="display">
                            <thead>
                                    {{-- <th>#</th> --}}
                                    <th>Harga yang Ditawarkan</th>
                                    {{-- <th>#</th> --}}
                                    <th>Penawar</th>
                                    <th>Penawar</th>
                            </thead>
                            <tbody>
                            </tbody>
                        </table>
                </div>
                </div>


            </div>
        </div>
    </div>

    <form class='xx'style='display: none' method='post' action='{{ url("submitwinner") }}'>
        <input type='hidden' class='bidx' name='bidx'>
        {{  csrf_field() }}
    </form>

    </div>

        <link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.10.13/css/jquery.dataTables.css">

        <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.13/js/jquery.dataTables.min.js"></script>

        <script type="text/javascript">
            $(document).ready( function () {


            @if(session('error'))
                 swal('Oops', '{{   session('error') }}', 'error');
            @elseif(session('success'))
                swal('Sukses!', '{{   session('success') }}', 'success');
            @endif

                var listBid = [];
                $.getJSON( '{{  url("ajax/getitembidlist/". $item->id) }}', function( data ) {

                      $.each( data, function( key, val ) {
                             listBid.push([ val.price_bid, val.name , val.id_user , val.id]   );
                      });

                    $('#table_id').DataTable({
                            data: listBid,
                            columnDefs: [
                                {
                                    targets:0,
                                    render: $.fn.dataTable.render.number( ',', '.', 2, 'Rp. ' )
                                },
                                {   targets : 1,
                                    render :  function ( data, type, row ) {
                                        return '<a href="'+ row[2]+ '">' + data + '<a>';
                                    }
                                },
                                { targets : [2], visible: false },
                                {
                                    data: null, targets : 3,
                                    render :  function ( data, type, row ) {
                                        return '<button class="btn btn-success" id="'+ row[3] +'">Pilih Pemenang</button>';
                                    }
                                }
                            ],
                        order : [[3, 'asc']]
                    });

                     $('#table_id tbody').on( 'click', 'button', function () {
                            var data = $(this).attr('id');
                            console.log(data);
                            $('.bidx').val(data);
                            swal({
                              title: 'Are you sure?',
                              text: "Apakah anda yakin memilih pemenang ini?",
                              type: 'warning',
                              showCancelButton: true,
                              confirmButtonColor: '#3085d6',
                              cancelButtonColor: '#d33',
                              confirmButtonText: 'Ya!'
                            }).then(function () {

                                    $('.xx').submit();
                            });
                    });


                });


            });
        </script>
    @endsection


