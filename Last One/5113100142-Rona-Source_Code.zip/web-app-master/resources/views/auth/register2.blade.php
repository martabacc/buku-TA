<!doctype html>
<head>
    <meta charset="utf-8">
    <meta name="robots" content="noindex">

    <title>LelangKita | Register </title>

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

    <link href='https://fonts.googleapis.com/css?family=Raleway:500' rel='stylesheet' type='text/css'>
    <link href="{{ url('bootstrap-social.css') }}" rel="stylesheet" id="bootstrap-css">
    <script>
        window.Laravel = <?php echo json_encode([
            'csrfToken' => csrf_token(),
        ]); ?>
    </script>
    <style type="text/css">
        @charset "UTF-8";
        /* CSS Document */

        body {
            /*width:100px;*/
            /*height:100px;*/
            background:white;
            /*background: -webkit-linear-gradient(90deg, #16222A 10%, #3A6073 90%); !* Chrome 10+, Saf5.1+ *!*/
            /*background:    -moz-linear-gradient(90deg, #16222A 10%, #3A6073 90%); !* FF3.6+ *!*/
            /*background:     -ms-linear-gradient(90deg, #16222A 10%, #3A6073 90%); !* IE10 *!*/
            /*background:      -o-linear-gradient(90deg, #16222A 10%, #3A6073 90%); !* Opera 11.10+ *!*/
            /*background:         linear-gradient(90deg, #16222A 10%, #3A6073 90%); !* W3C *!*/
            font-family: 'Raleway', sans-serif;
        }

        p {
            color:#CCC;
        }

        .spacing {
            padding-top:7px;
            padding-bottom:7px;
        }
        .middlePage {
            /*width: 680px;*/
            /*height: 500px;*/
            position: absolute;
            /*top:0;*/
            /*bottom: 0;*/
            /*left: 0;*/
            /*right: 0;*/
            margin: auto;
        }

        .logo {
            color:#CCC;
        }
    </style>
    <script
            src="https://code.jquery.com/jquery-2.1.1.min.js"
            integrity="sha256-h0cGsrExGgcZtSZ/fRz4AwV+Nn6Urh/3v3jFRQ0w9dQ="
            crossorigin="anonymous">
    </script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js"></script>
</head>

<body>
<div class="container">

    <div class="row">
        <div class="col-sm-9 col-sm-offset-1 col-md-8 col-md-offset-2">
            <div class="page-header">
                <h1 class="logo">Lelangapa
                    <small>
                        Bid your items. Get your price.
                    </small>
                </h1>
            </div>

            <div class="panel panel-info">
                <div class="panel-heading">
                    <h3 class="panel-title">Daftar</h3>
                </div>
                <div class="panel-body" style="height:auto;">



                  <div class="col-md-5" style="  pointer-events: none; opacity: 0.4;" >
                        <div class="middle">
                            <h2> Social Media Login<br>Coming Soon! </h2>
                            <img src="https://media.giphy.com/media/RFgY2jhk6xKzS/source.gif" class="img img-responsive">
                        </div>
                            <a class="btn btn-block btn-social btn-twitter">
                                <span class="fa fa-twitter"></span> Sign up with Twitter
                            </a>
                            <a class="btn btn-block btn-social btn-facebook">
                                <span class="fa fa-facebook"></span> Sign up with Facebook
                            </a>
                            <a class="btn btn-block btn-social btn-google">
                                <span class="fa fa-google"></span> Sign up with Google
                            </a>
                    </div>

                    <div class="col-md-7" style="border-left: 1px #fff solid">

                        <form class="form-horizontal"  method="POST" action="{{ url('register') }}" >
                            {{csrf_field()}}
                            <label>Nama</label>
                            <input id="textinput" name="name" type="text" placeholder="Nama anda" class="form-control input-md" value="{{ old('name') }}" >

                            @if ($errors->has('name'))
                                <span class="small text-danger">
                                        <strong>{{ $errors->first('name') }}</strong>
                                    </span>
                            @endif

                            <br>
                            <label>Email</label>
                            <input id="textinput" name="email" type="email" required placeholder="Email anda" class="form-control input-md" value="{{ old('email') }}" >

                            @if ($errors->has('email'))
                                <span class="small text-danger">
                                            <strong>{{ $errors->first('email') }}</strong>
                                        </span>
                            @endif


                            <br>
                            <label>Username</label>
                            <input id="textinput" name="username" type="text" required placeholder="Username anda" class="form-control input-md" value="{{ old('username') }}" >

                            @if ($errors->has('username'))
                                <span class="small text-danger">
                                            <strong>{{ $errors->first('username') }}</strong>
                                        </span>
                            @endif

                            <br>

                            <label>Password</label>
                            <input id="textinput" name="password" type="password" required placeholder="Password" class="form-control input-md" value="{{ old('password') }}" >

                            @if ($errors->has('password'))
                                <span class="small text-danger">
                                    <strong>{{ $errors->first('password') }}</strong>
                                </span>
                            @endif

                            <br>

                            <label>Konfirmasi Password</label>
                            <input id="textinput" name="password_confirmation" type="password" required placeholder="Konfirmasi Password" class="form-control input-md" value="{{ old('password') }}" >

                            @if ($errors->has('password'))
                                <span class="small text-danger">
                                    <strong>{{ $errors->first('password_confirmation') }}</strong>
                                </span>
                            @endif

                            <br>

                            <label>Alamat</label>
                            <textarea id="textinput" name="address" type="text" placeholder="Alamat anda" class="form-control input-md" value="{{ old('address') }}" ></textarea>

                            @if ($errors->has('address'))
                                <span class="help-block">
                                        <strong>{{ $errors->first('address') }}</strong>
                                    </span>
                            @endif

                            <br>

                            <label>Phone</label>
                            <input id="textinput" name="phone" type="number" placeholder="Phone number" class="form-control input-md" value="{{ old('phone') }}" >

                            @if ($errors->has('phone'))
                                <span class="text-danger">
                                        <strong>{{ $errors->first('phone') }}</strong>
                                    </span>
                            @endif

                            <br>


                            <!--<label>Kota</label><br>
                            <div class="col-md-10">
                                <div class="form-group">
                                    <select class="select2 col-md-12" >
                                        <option selected="selected">Alabama</option>
                                        <option>Alaska</option>
                                        <option>California</option>
                                        <option>Delaware</option>
                                        <option>Tennessee</option>
                                        <option>Texas</option>
                                        <option>Washington</option>
                                    </select>
                                </div>
                            </div>-->

                            @if ($errors->has('city'))
                                <span class="small text-danger">
                                    <strong>{{ $errors->first('city') }}</strong>
                                </span>
                            @endif
                            <br>
                            <hr>

                            <div class="spacing">
                                <button id="singlebutton" name="singlebutton" class="btn btn-primary btn-md pull-left">
                                    Daftar</button>
                            </div>
                            <br>
                        </form>
                    </div>

                </div>

            </div>
        </div>

    </div>
</div>
</body>
<script>
    $(document).ready(function(){


        $(".select2").select2();
    });
</script>
</html>