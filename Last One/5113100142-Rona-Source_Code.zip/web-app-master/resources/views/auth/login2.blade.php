<!doctype html>
<head>
    <meta charset="utf-8">
    <meta name="robots" content="noindex">

    <title>Lelangapa | Login</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

    <link href='https://fonts.googleapis.com/css?family=Raleway:500' rel='stylesheet' type='text/css'>
    <link href="{{ url('bootstrap-social.css') }}" rel="stylesheet" id="bootstrap-css">

    <script>
        window.Laravel = <?php echo json_encode([
            'csrfToken' => csrf_token(),
        ]); ?>
    </script>
    <style type="text/css">
        @charset "UTF-8";
        /* CSS Document */

        body {
            background:white;
            font-family: 'Raleway', sans-serif;
        }

        p {
            color:#CCC;
        }

        .spacing {
            padding-top:7px;
            padding-bottom:7px;
        }
        .middlePage {
            /*width: 680px;*/
            /*height: 500px;*/
            position: absolute;
            /*top:0;*/
            /*bottom: 0;*/
            /*left: 0;*/
            /*right: 0;*/
            margin: auto;
        }

        .logo {
            color:#CCC;
        }
    </style>
    <script
            src="https://code.jquery.com/jquery-2.1.1.min.js"
            integrity="sha256-h0cGsrExGgcZtSZ/fRz4AwV+Nn6Urh/3v3jFRQ0w9dQ="
            crossorigin="anonymous">
    </script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    <script type="text/javascript">
        window.alert = function(){};
        var defaultCSS = document.getElementById('bootstrap-css');
    </script>
</head>

<body>
    <div class="container">
        <div class="row">

            <div class="">

                <div class="col-sm-9 col-sm-offset-1 col-md-8 col-md-offset-2">
                    <div class="page-header">
                        <h1 class="logo">Lelangapa
                            <small>
                                Bid your items. Get your price.
                            </small>
                        </h1>
                    </div>

                    <div class="panel panel-info">
                        <div class="panel-heading">
                            <h3 class="panel-title">Log In</h3>
                        </div>
                        <div class="panel-body" style="height:auto;">

                            <div class="row">

                                <div class="col-md-5" style="pointer-events: none; opacity: 0.4;"" >
                                    <div class="middle">
                                        <h2>Coming Soon! </h2>
                                        <img src="https://media.giphy.com/media/RFgY2jhk6xKzS/source.gif" class="img img-responsive">
                                    </div>
                                    <a class="btn btn-block btn-social btn-twitter">
                                        <span class="fa fa-twitter"></span> Sign in with Twitter
                                    </a>
                                    <a class="btn btn-block btn-social btn-facebook">
                                        <span class="fa fa-facebook"></span> Sign in with Facebook
                                    </a>
                                    <a class="btn btn-block btn-social btn-google">
                                        <span class="fa fa-google"></span> Sign in with Google
                                    </a>
                                </div>

                                <div class="col-md-7">
                                    <form class="form-horizontal"  method="POST" action="{{ url('/login') }}" >
                                        <fieldset>
                                            {{csrf_field()}}
                                            <label> Email </label>
                                            <input id="textinput" name="email" type="email" placeholder="Email anda" class="form-control input-md" value="{{ old('email') }}" >

                                            @if ($errors->has('email'))
                                                <span class="help-block">
                                        <strong>{{ $errors->first('email') }}</strong>
                                    </span>
                                            @endif
                                            <br>
                                            <label> Password </label>
                                            <input id="textinput"  name="password" id="password" type="password" placeholder="Password anda" class="form-control input-md">
                                            @if ($errors->has('password'))
                                                <span class="help-block">
                                        <strong>{{ $errors->first('password') }}</strong>
                                    </span>
                                            @endif

                                            <div class="spacing">
                                                <input type="checkbox"  name="remember" id="checkboxes-0" value="0">
                                                <small> Remember me</small>
                                                <button id="singlebutton" name="singlebutton" class="btn btn-info btn-sm pull-right">
                                                    Log In</button>
                                            </div>
                                            <br>

                                            <div class="spacing">
                                                <p>
                                                    <a href="{{ url('/password/reset') }}">Lupa Password?</a>
                                                </p>
                                                <p>
                                                    <a href="{{ url('register') }}"> Belum punya akun? Login disini</a>
                                                </p>
                                            </div>


                                        </fieldset>
                                    </form>
                                </div>

                            </div>

                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</body>
</html>