<div class="footer-bottom">
    <div class="container">
        <div class="copyright">Powered By<a class="yourstore" href="http://www.lionode.com/">Lelangapa</a> </div>
        <div class="footer-bottom-cms">
            <div class="footer-payment">
                <ul>
                    <li class="mastero"><a href="#"><img alt="" src="image/payment/mastero.jpg"></a></li>
                    <li class="visa"><a href="#"><img alt="" src="image/payment/visa.jpg"></a></li>
                    <li class="currus"><a href="#"><img alt="" src="image/payment/currus.jpg"></a></li>
                    <li class="discover"><a href="#"><img alt="" src="image/payment/discover.jpg"></a></li>
                    <li class="bank"><a href="#"><img alt="" src="image/payment/bank.jpg"></a></li>
                </ul>
            </div>
        </div>
    </div>

</div>