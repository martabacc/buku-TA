<div class="col-sm-3 hidden-xs column-left" id="column-left">
    <div class="column-block">
        <div class="columnblock-title">{{ trans('item.item_management') }}</div>
<!--        TODO!!!!-->
        <div class="account-block">
            <div class="list-group">
                <a class="list-group-item" href="login.html">{{ trans('item.item_list') }}</a>
                <a class="list-group-item" href="register.html">{{ trans('item.item_add') }} </a>
                <a class="list-group-item" href="forgetpassword.html">{{ trans('item.bidding_history') }}</a>
            </div>
        </div>
    </div>
</div>