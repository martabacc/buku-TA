<header>
    <div class="header-top" style="background-color:whitesmoke">
        <div class="container-fluid">

            <div class="row">
                <div class="col-sm-12">
                    <div class="top-left pull-left col-sm-3 col-md-3 col-xs-12">
                        <a href="{{ url('/') }}">
                            <img src="{{ url('full-logo.png') }}" style="padding-top: 5px;max-height:50px;padding-left:5px;" title="la-logo" alt="Lelangapa" class="img-responsive" />
                        </a>
                    </div>

                    <div id="search" class="input-group col-sm-9 col-md-9 col-xs-9"
                        style="padding-top:5px;">
                        <div class="row">
                            <div class="col-sm-4 col-md-4 col-xs-12 ">
                                <form method="get" action="{{ route('item.search') }}" class="pull-left" style="margin-top:5px">
                                    <div class="form-group">
                                        <div class="col-md-10 col-sm-10 col-xs-10">
                                            <input type="text" disabled name="key" placeholder="Still developing..." class="input-lg input-group col-sm-12 col-md-12 col-xs-12" style="font-size:13px">
                                        </div>
                                        <div class="col-md-2 col-sm-2 col-xs-2">
                                            <button type="submit" disabled class=" btn-lg btn-primary" >
                                                <i class="fa fa-search"></i>
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                            <div class="col-sm-8 col-md-8 col-xs-12 pull-right">
                                <div id="top-links" class="nav pull-right" style="padding-top:6px">
                                    <ul class="list-inline">
                                        <li class="dropdown">
                                            <a href="#" title="My Account" class="dropdown-toggle" data-toggle="dropdown">
                                                <i class="fa fa-user"></i>
                                                <span>{{ trans('header.my_account') }}</span>
                                                <span class="caret"></span>
                                            </a>
                                            <ul class="dropdown-menu dropdown-menu-right">
                                                @if(Auth::check())

                                                    <li>
                                                        <a href="{{ url('/logout') }}"
                                                           onclick="event.preventDefault();
         document.getElementById('logout-form').submit();">
                                                            Logout
                                                        </a>
                                                        <form id="logout-form"
                                                              action="{{ url('/logout') }}"
                                                              method="POST"
                                                              style="display: none;">
                                                            {{ csrf_field() }}
                                                        </form>
                                                    </li>
                                                    <li>
                                                        <a href="{{ route('user.show', Auth::user()->id ) }}">{{ trans('header.my_profil') }}</a>
                                                    </li>
                                                    <li>
                                                        <a href="{{ url('bidhistory') }}">{{ trans('header.bid_history') }}</a>
                                                    </li>

                                                @else

                                                    <li><a href="{{ url('register') }}">Register</a></li>
                                                    <li><a href="{{ url('login') }}">Login</a></li>

                                                @endif


                                            </ul>
                                        </li>
                                        @if(Auth::check())
                                            <li class="dropdown">
                                                <a href="#" title="My Account" class="dropdown-toggle" data-toggle="dropdown">
                                                    <i class="fa fa-product-hunt"></i>
                                                    <span>{{ trans('header.sell_item') }}</span>
                                                    <span class="caret"></span>
                                                </a>
                                                <ul class="dropdown-menu dropdown-menu-right">
                                                    <li><a href="{{ url('item/create') }}">{{ trans('header.add_item') }} </a></li>
                                                    <li><a href="{{ url('item') }}">{{ trans('header.manage_item') }} </a></li>
                                                </ul>
                                            </li>
                                            <li>
                                                <a href="{{ url('/inbox') }}" id="wishlist-total" title="{{ trans('header.wish_list') }} (0)">
                                                    <i class="fa fa-envelope-o"></i>
                                                    <span>{{ trans('header.msg_inbox') }}</span>
                                                    <span> </span>
                                                </a>
                                            </li>
                                        @endif
                                        <li>
                                            <a href="#" id="wishlist-total" title="{{ trans('header.wish_list') }} (0)">
                                                <i class="fa fa-heart"></i>
                                                <span>{{ trans('header.wish_list') }}</span>
                                                <span> (0)</span>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>

            </div>
        </div>
    </div>

</header>