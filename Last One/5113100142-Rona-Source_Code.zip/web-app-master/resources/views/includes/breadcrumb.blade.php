@if($breadcrumbs)
    <ul class="breadcrumb">
        <li><a href={{ url('/') }}index.html"><i class="fa fa-home"></i></a></li>
        @foreach($breadcrumbs as $i=>$b)
            <li>{{ $b }}</li>
        @endforeach
    </ul>
 @endif