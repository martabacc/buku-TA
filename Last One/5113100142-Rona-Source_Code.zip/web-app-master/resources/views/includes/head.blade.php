
    <meta http-equiv="content-type" content="text/html;charset=utf-8" />
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="e-commerce site well design with responsive view." />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link href='https://fonts.googleapis.com/css?family=Roboto+Slab' rel='stylesheet' type='text/css'>
    <link href="{{ asset('image/catalog/cart.png ') }}" rel="icon" />
    <!-- Latest compiled and minified JavaScript -->

    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

    <script
            src="https://code.jquery.com/jquery-2.2.4.min.js"
            integrity="sha256-BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44="
            crossorigin="anonymous"></script>
    <link href='https://fonts.googleapis.com/css?family=Arimo' rel='stylesheet' type='text/css'>
    <link href="{{ asset('javascript/owl-carousel/owl.carousel.css') }} " type="text/css" rel="stylesheet" media="screen" />
    <link href="{{ asset('javascript/owl-carousel/owl.transitions.css') }}" type="text/css" rel="stylesheet" media="screen" />
    <!-- Latest compiled and minified JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>

    <script type="text/javascript" src="{{ asset('javascript/template_js/jstree.min.js') }}"></script>
    <script type="text/javascript" src="{{ asset('javascript/template_js/template.js') }}"></script>
    <script src="{{ asset('javascript/common.js') }}" type="text/javascript"></script>
    <script src="{{ asset('javascript/global.js') }}" type="text/javascript"></script>
    <script src="{{ asset('javascript/owl-carousel/owl.carousel.min.js') }}" type="text/javascript"></script>
    <script src="{{ asset('js/moment.min.js') }}" type="text/javascript"></script>
    <script src="{{ asset('sweetalert2.min.js') }}" type="text/javascript"></script>
    <link href="{{ asset('css/stylesheet.css') }} " rel="stylesheet">
    <link href="{{ asset('css/responsive.css ') }}" rel="stylesheet">
    <link href="{{ asset('sweetalert2.min.css') }} " rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css">
    <link href="{{ asset('added.css ') }}" rel="stylesheet">


        @if(isset($additionAsset))
            @if(isset($additionAsset['css']))
                @foreach($additionAsset['css'] as $css)
                    <link href="{{ asset($css) }}" rel="stylesheet" type="text/css" />
                @endforeach
            @endif
            @if(isset($additionAsset['js']))
                @foreach($additionAsset['js'] as $js)
                    <script src='{{ asset($js) }}' type='text/javascript'></script>
                @endforeach
            @endif
        @endif

