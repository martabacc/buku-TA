<!DOCTYPE html>
<html lang="en">
<head>
    @include('includes.head')
    <title>
    	Lelangapa
	</title>
</head>
<body>
{{--<div class="preloader loader" style="display: block;"> <img src="{{ url('image/loader.gif') }}"  alt="#"/></div>--}}
    @include('includes.header')

    @yield('content')

    @include('includes.footer')
    @include('includes.footer-bottom')

	<!--store autoloads script-->
	<!--include('scripts.autoload')-->


</body>
@yield('custom-scripts')
</html>

