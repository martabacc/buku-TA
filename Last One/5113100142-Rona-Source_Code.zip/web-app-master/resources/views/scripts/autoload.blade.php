<script type="text/javascript">
    $(document).ready(function(){

        $.getScript( "https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js")
            .done(function(){
                console.log('tloaded');
            });
    });
</script>