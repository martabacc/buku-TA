<?php
/**
 * Created by PhpStorm.
 * User: rona
 * Date: 01/12/2016
 * Time: 16:04
 */

return [
    'add_review' => 'Tambahkan Review',
    'review_list' => 'Daftar Review',
    'rate' => 'Rating',
    'rate_1' => 'Buruk',
    'rate_2' => 'Tidak terlalu buruk',
    'rate_3' => 'Cukup',
    'rate_4' => 'Baik',
    'rate_5' => 'Sangat baik',
    'add_success' => 'Sukses menambahkan Review',
    
];