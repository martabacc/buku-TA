<?php
/**
 * Created by PhpStorm.
 * User: rona
 * Date: 16/11/2016
 * Time: 23:46
 */
return [

    /*
    |--------------------------------------------------------------------------
    | Baris-baris bahasa untuk autentifikasi
    |--------------------------------------------------------------------------
    |
    | Baris bahasa berikut digunakan selama proses autentifikasi untuk beberapa
    | pesan yang perlu kita tampilkan ke pengguna. Anda bebas untuk memodifikasi
    | baris bahasa sesuai dengan keperluan aplikasi anda.
    |
    */


    'sell_new_item'   => 'Jual Barang',
    'update_item'   => 'Perbarui Barang',
    'sell_new_item_description' => 'Tambahkan barang untuk anda lelang',
    'item_details' => 'Detail Barang Anda',
    'item_name' => 'Nama Barang',
    'item_description' => 'Deskripsi Barang',
    'item_category' => 'Kategori Barang',
    'start_time' => 'Waktu Mulai Lelang',
    'category' => 'Category',
    'end_time' => 'Batas Akhir Lelang',
    'starting_price' => 'Harga Awal',
    'expected_price' => 'Harga yang Diharapkan',
    'item_list' => 'Daftar Barang',
    'item_management' => 'Kelola Barang',
    'item_add' => 'Tambah Barang',
    'bidding_history' => 'Riwayat Lelang Barang',
    'winning_status' => 'Pemenang Lelang',
    'auction_detail' => 'Detail Lelang',
    'add_new_item_submit' => 'Lelang Barang',
    'item_picture' => 'Foto Barang',
    'finish_detail_item' => 'Selesai isi data barang, lanjutkan upload gambar barang',
    'upload_item_picture' => 'Upload foto barang',
    

    'no_selling_item' => "Anda tidak menjual / melelang barang apapun.",

    'seller' => "Penjual",
    'bid_this_item' => "Tawarkan harga",
    'bid_this_item_help' => "Tawarkan harga untuk barang ini",

];