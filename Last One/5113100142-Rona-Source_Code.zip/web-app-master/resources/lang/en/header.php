<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Pagination Language Lines
    |--------------------------------------------------------------------------
    |
    | For Header
    |
    */

    'my_account' => 'Akun saya',
    'my_profil' => 'Profil saya',
    'previous' => '&laquo; Previous',
    'next'     => 'Next &raquo;',
    'sell_item' => 'Barang Anda',
    'add_item' => 'Tambah Barang',
    'manage_item' => 'Kelola Barang',
    'wish_list' => 'Wish List',
    'message' => 'Pesan',
    'msg_inbox' => 'Kotak Pesan',
    'new_msg' => 'Pesan baru',
    'bid_history' => 'Riwayat Lelang',
    


];