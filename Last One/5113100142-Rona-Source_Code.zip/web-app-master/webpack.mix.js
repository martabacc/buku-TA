/**
 * Created by rona on 19/04/2017.
 */
const { mix } = require('laravel-mix');
/*
 |--------------------------------------------------------------------------
 | Mix Asset Management
 |--------------------------------------------------------------------------
 |
 | Mix provides a clean, fluent API for defining some Webpack build steps
 | for your Laravel application. By default, we are compiling the Sass
 | file for the application as well as bundling up all the JS files.
 |
 */

//for requiring script
mix.js('resources/assets/js/dependencies.js', 'public/js');
mix.js('resources/assets/js/favorites.js', 'public/js');
mix.js('resources/assets/js/itemimages.js', 'public/js');
mix.js('resources/assets/js/chat.js', 'public/js');