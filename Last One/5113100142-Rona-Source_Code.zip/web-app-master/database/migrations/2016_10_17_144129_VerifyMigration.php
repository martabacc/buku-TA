<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class VerifyMigration extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('verified', function(Blueprint $table){
           $table->increments('id_verified');
           $table->integer('id_user');
            $table->boolean('is_verified')->default(false);
            $table->integer('verification_img');
            $table->integer('verified_by')->nullable();
            $table->timestamp('verified_date')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('verified');
    }
}
