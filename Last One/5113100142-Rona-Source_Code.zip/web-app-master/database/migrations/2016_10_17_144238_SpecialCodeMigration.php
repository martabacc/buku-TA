<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class SpecialCodeMigration extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('specialcodes', function (Blueprint $table) {
            $table->increments('id_code');
            $table->string('codename', 10);
            $table->boolean('codestatus');
            $table->float('discount')->nullable();
            $table->boolean('free_shippingfee');
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('specialcodes');
    }
}
