<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class ItemImageMigration extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('itemimages', function (Blueprint $table){
            $table->integer('id_item');
            $table->integer('id_image');
        });
    }

    public function down()
    {
        Schema::drop('itemimages');
    }
}
