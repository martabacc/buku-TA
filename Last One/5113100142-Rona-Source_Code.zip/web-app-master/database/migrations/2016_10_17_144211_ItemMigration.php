<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class ItemMigration extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('items', function(Blueprint $table){
            $table->increments('id_item');
            $table->string('name');
            $table->mediumText('description');
            $table->dateTime('start_time');
            $table->dateTime('end_time');
            $table->integer('id_user');
            $table->integer('starting_price');
            $table->integer('expected_price')->nullable();
            $table->integer('winning_status')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('items');
    }
}
