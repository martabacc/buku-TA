<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class IssueMigration extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('issues', function(Blueprint $table){
           $table->increments('id_issue');
            $table->integer('id_issue_type');
            $table->integer('id_user');
            $table->integer('id_issued_user')->nullable();
            $table->mediumText('description');
            $table->boolean('resolve_status')->nullable();
            $table->text('resolve_description')->nullable();
            $table->timestamps();

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('issues');
    }
}
