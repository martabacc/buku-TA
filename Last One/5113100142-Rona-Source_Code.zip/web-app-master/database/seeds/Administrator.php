<?php

use Illuminate\Database\Seeder;

class Administrator extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $x = factory(App\User::class, 20)->create();
    }
}
