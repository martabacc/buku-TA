<?php

use Illuminate\Database\Seeder;

class SpecialCode extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        factory(App\SpecialCode::class, 20)
            ->create();

        factory(App\CodeUsage::class, 30)
            ->create();
    }
}
