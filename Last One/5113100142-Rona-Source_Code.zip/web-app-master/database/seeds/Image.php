<?php

use Illuminate\Database\Seeder;

class Image extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        foreach(range(1,60) as $z){
            factory(App\Image::class)
                -> create(['url' => $z]);
        }
    }
}
