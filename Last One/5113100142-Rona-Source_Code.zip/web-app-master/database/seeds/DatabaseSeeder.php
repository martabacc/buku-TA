
<?php

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // $this->call(Administrator::class);
        // $this->call(Announcement::class);
        // $this->call(Bid::class);
        // $this->call(Image::class);
        // $this->call(Issue::class);
        // $this->call(Issuetype::class);
        // $this->call(Image::class);
        // $this->call(Item::class);
        // $this->call(Itemimage::class);
        // $this->call(Review::class);
        // $this->call(SpecialCode::class);
        $this->call(User::class);
    }
}
