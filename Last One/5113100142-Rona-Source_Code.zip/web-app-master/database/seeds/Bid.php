<?php

use Illuminate\Database\Seeder;

class Bid extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {

        factory(App\Bid::class, 120)->create();
    }
}
