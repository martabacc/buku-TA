<?php

use Illuminate\Database\Seeder;

class Issuetype extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {

    }
}
