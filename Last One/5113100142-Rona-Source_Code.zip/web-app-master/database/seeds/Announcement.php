<?php

use Illuminate\Database\Seeder;

class Announcement extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {

        factory(App\Announcement::class, 10)->create();
    }
}
