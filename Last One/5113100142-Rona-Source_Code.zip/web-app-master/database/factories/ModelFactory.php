<?php

/*
|--------------------------------------------------------------------------
| Model Factories
|--------------------------------------------------------------------------
|
| Here you may define all of your model factories. Model factories give
| you a convenient way to create models for testing and seeding your
| database. Just tell the factory how a default model should look.
|
*/

function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

function generateRandomBool($probs){
    return Faker\Factory::create()->boolean($probs);
}

$factory->define(App\Verified::class, function (Faker\Generator $faker) {

    return [
        'id_user' => 1,
        'verification_img' => 1,
        'verified_by' => 1,
        'verified_date' => $faker->dateTimeThisMonth($max = 'now'),
    ];
});

$factory->define(App\Administrator::class, function (Faker\Generator $faker) {
    static $password;

    return [
        'name' => $faker->name,
        'username' => $faker->userName,
        'password' => $password ?: $password = bcrypt('secret'),
    ];
});

$factory->define(App\User::class, function (Faker\Generator $faker) {
    static $password;

    return [
        'name' => $faker->name,
        'email' => $faker->unique()->safeEmail,
        'password' => $password ?: $password = bcrypt('secret'),
        'address' => $faker->address,
        'id_verify' => 1,
        'phone' => $faker->phoneNumber,
        'id_city' => $faker->numberBetween($min = 1, $max = 3),
        'remember_token' => str_random(10),
    ];
});

$factory->define(App\Review::class, function (Faker\Generator $faker) {

    return [
        'description' => $faker->text($maxNbChars = 100),
        'id_user' => $faker->numberBetween($min = 1, $max = 20),
        'id_reviewer' => $faker->numberBetween($min = 1, $max = 20),
        'star_count' => $faker->numberBetween($min = 1, $max = 5),
        'timestamp' => $faker->dateTimeThisMonth($max = 'now')
    ];
});

$factory->define(App\Issue::class, function (Faker\Generator $faker) {

    return [
        'id_issue_type' => $faker->numberBetween($min = 1, $max = 3),
        'description' => $faker->text($maxNbChars = 100),
        'id_user' => $faker->numberBetween($min = 1, $max = 10),
        'id_issued_user' => $faker->numberBetween($min = 1, $max = 6),
        'resolve_status' => $faker->boolean(20),
        'resolve_description' => $faker->boolean(20) ? null : $faker->text($maxNbChars = 100),
        'created_at' => $faker->dateTimeBetween($startDate = '-5 weeks', $endDate = '-4 weeks'),
        'updated_at' => $faker->dateTimeBetween($startDate = '-4 weeks', $endDate = '-1 weeks'),
    ];
});

$factory->define(App\Image::class, function (Faker\Generator $faker) {

    return [
        'url' =>  '1',
    ];
});

$factory->define(App\Item::class, function (Faker\Generator $faker) {

    return [
        'name' => $faker->sentence($nbWords = 6, $variableNbWords = true),
        'description' => $faker->text($maxNbChars = 200),
        'id_user' => $faker->numberBetween($min = 1, $max = 20),
        'start_time' => $faker->dateTimeBetween($startDate = '-5 weeks', $endDate = '-2 weeks'),
        'end_time' => $faker->dateTimeBetween($startDate = '+2 weeks', $endDate = '+3 months'),
        'starting_price' => $faker->numberBetween($min = 200, $max = 5000) * 1000,
        'expected_price' => $faker->numberBetween($min = 51000, $max = 10000)*1000,
    ];
});

$factory->define(App\ItemImage::class, function (Faker\Generator $faker) {

    return [
        'id_item' => $faker->numberBetween($min=1, $max=20),
        'id_image' => $faker->numberBetween($min=1, $max=60),
    ];
});


$factory->define(App\Bid::class, function (Faker\Generator $faker) {

    return [
        'item_id' => $faker->numberBetween($min = 1, $max = 40),
        'user_id' => $faker->numberBetween($min = 1, $max = 20),
        'price' => $faker->numberBetween($min = 1000, $max = 7000) * 1000,
        'win_status' => null,
        'timestamp' => $faker->dateTimeBetween($startDate = '-7 days', $endDate = 'now'),
    ];
});


$factory->define(App\Announcement::class, function (Faker\Generator $faker) {

    return [
        'title' => $faker->text($maxNbChars = 50),
        'description' => $faker->text($maxNbChars = 200),
        'start_time' => $faker->dateTimeBetween($startDate = '-7 days', $endDate = '+2 weeks'),
        'end_time' => $faker->dateTimeBetween($startDate = '-7 days', $endDate = '+2 weeks'),
        'html_code' => $faker->text($maxNbChars = 200),
    ];
});

$factory->define(App\SpecialCode::class, function (Faker\Generator $faker) {
    $y = generateRandomBool(80);
    $z = $y ? false : true;

    return [
        'codename' => generateRandomString(),
        'codestatus' => $y,
        'discount' =>  $y ? $faker->randomFloat($nbMaxDecimals = NULL, $min = 0, $max = 1) : null,
        'free_shippingfee' => $z,
    ];
});

$factory->define(App\CodeUsage::class, function (Faker\Generator $faker) {
    return [
        'id_user' => $faker->numberBetween($min = 1, $max = 20),
        'id_code' => $faker->numberBetween($min = 1, $max = 20),
        'timestamp' =>  $faker->dateTimeBetween($startDate = '-7 days', $endDate = 'now'),
    ];
});