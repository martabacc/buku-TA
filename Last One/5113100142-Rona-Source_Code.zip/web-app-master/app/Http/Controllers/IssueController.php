<?php

namespace App\Http\Controllers;

use App\Models\Issue;
use App\Models\UserIssue;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use DB;

class IssueController extends Controller
{

    public function user(Request $request){
        $user = Auth::user()->id;

        if( (int)$user != $request['id_user']) return ['success' => false];

        if( UserIssue::create($request->except('_token'))){
            return [ 'success' => true ];
        }
        else return ['success' => false];
    }


    public function item(Request $request){
        $user = Auth::user()->id;

        if( (int)$user != $request['id_user']) return ['success' => false];

        if( Issue::create($request->except('_token'))){
            return [ 'success' => true ];
        }
        else return ['success' => false];
    }


    public function types(){
        $result = DB::select('select id, name as text from issuetypes');
        return response()->json($result);

    }
}
