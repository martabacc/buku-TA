<?php

namespace App\Http\Controllers;

use App\Repositories\CategoryRepository;
use App\Repositories\TransactionRepository;
use Illuminate\Http\Request;
use App\Repositories\BidRepository;
use App\Repositories\ItemRepository;
class AjaxController extends Controller
{
	private $bidRep;

	function __construct( BidRepository $bidRep, ItemRepository $itemRep ){
		$this->bidRep = $bidRep;
		$this->itemRep = $itemRep;
	}

    public function getBidItemDetail($id, Request $request){
    		// $id_item = $request->only('id_item');
    	$result = $this->bidRep->getItemHistoryBid($id, $this->itemRep->find($id)->bid_time);

    	return response()->json($result);
    }

    public function getCategory(){
        return response()
                ->json(CategoryRepository::all());
    }

    public function getItemProperties($id)
    {
        return ItemRepository::getDashboardDetail($id);
    }

    public function suggestion($id_item)
    {
        return response()
            ->json(
                TransactionRepository::priceSuggestion($id_item)
            );
    }

}
