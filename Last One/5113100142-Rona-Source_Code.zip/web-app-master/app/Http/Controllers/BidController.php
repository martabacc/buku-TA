<?php

namespace App\Http\Controllers;

use App\Repositories\CouponRepository;
use App\Repositories\ReviewRepository;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Repositories\BidRepository;
use App\Repositories\ItemRepository;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Collection;


class BidController extends Controller
{
	private $bidRepository;
	function __construct(BidRepository $bidRepository,
                             ItemRepository $itemRepository){
		$this->middleware('auth');
		$this->bidRepository = $bidRepository;
        $this->itemRepository = $itemRepository;
	}

	public function userHistory(Request $request)
    {
       $results = $this->bidRepository->getHistoryBid(Auth::user()->id);
        //Get current page form url e.g. &page=6
        $currentPage = LengthAwarePaginator::resolveCurrentPage();

        //Create a new Laravel collection from the array data
        $collection = new Collection($results);

        //Define how many items we want to be visible in each page
        $per_page = 20;

        //Slice the collection to get the items to display in current page
        $currentPageResults = $collection->slice(($currentPage-1) * $per_page, $per_page)->all();

        //Create our paginator and add it to the data array
        $data['results'] = new LengthAwarePaginator($currentPageResults, count($collection), $per_page);

        //Set base url for pagination links to follow e.g custom/url?page=6
        $data['results']->setPath($request->url());

    	return view('pages.bid.bidhistory', $data);
	}

    public function pickWinner($id)
    {
            $data['item'] = $this->itemRepository->find($id);
            if ($data['item']->winner_chosen_status) {
                return redirect('item/'.$id)->with('error','Pemenang lelang telah terpilih!');
            }
            if( Auth::user()->id != $data['item']->id_user )
                return redirect('item/'.$id)->with('error','Anda tidak berhak untuk mengakses halaman ini');

            return view('pages.bid.pickwinner', $data);
    }

    public function itemBidHistory($id)
    {
        $data['item'] = $this->itemRepository->find($id);

        return view('pages.bid.itembidhistory', $data);
    }

    public function getStatus(Request $request, $idbid){
	    $bid = BidRepository::getBidDetail($idbid);
	    $result = [];
	    try{
            if(Auth::check())
            {
                $ifUserValid = ReviewRepository::isReviewSubmitted($idbid, $request->user()->id);
                if( $ifUserValid['valid'] )
                {
                    $result['review']=$ifUserValid['bool'];
                }

//          check for coupon submission
                $couponStat = CouponRepository::isCouponSubmitted($idbid, Auth::user()->id);

                if(is_array($couponStat['valid']) || !$ifUserValid['valid'] )
                    throw new \Exception('Invalid argument!');

                else $result['coupon'] = $couponStat;

                return response()->json(['status'=>true, 'result'=>$result]);
            }
            throw new \Exception('Unauthorized Access');
        }
        catch(\Exception $e){
//                dd($e);
            return response()->json(['status'=>false, 'msg'=>$e->getMessage()]);
        }
    }
    
}
