<?php

namespace App\Http\Controllers;

use App\Repositories\BidRepository;
use App\Repositories\ReviewRepository;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;
use Illuminate\Http\Request;

class ReviewController extends Controller
{
    private $reviewRep;


    function __construct()
    {
        $this->middleware('auth');
    }
    
    public function submit(Request $request, $idbid)
    {
        $informationNeeded = json_decode($request['info']);

//        invalid request
        $bid = BidRepository::getBidDetail($idbid);
        $user = $request->user();
        if( !$bid || ($user->id != $bid->id_user && $user->id!= $bid->item->user->id) )
            abort(403);

        return response()
            ->json(
                ReviewRepository::submit($bid, $informationNeeded, $user)
            );
    }
}
