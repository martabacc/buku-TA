<?php

namespace App\Http\Controllers;

use App\Repositories\ItemImageRepository;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ImageController extends Controller
{
    private $itemImageRepository;

    function __construct(ItemImageRepository $itemImageRepository)
    {
        $this->itemImageRepository = $itemImageRepository;
    }

    public function uploadItemImage(Request $request){
        //passed here if csrf token is already passed
        $_POST['image'] = $request->file('image');
        $_POST['id_user'] = Auth::user()->id;
        $_POST['ext'] = $request->file('image')->extension();
//        dd($_POST);
        require ('/home/img/upload-aws.php');

        return $res;
    }

    public function updateItemImage(Request $request){
        //passed here if csrf token is already passed
        if( $request->file('image') ){
            $_POST['image'] = $request->file('image');
            $_POST['id_user'] = Auth::user()->id;
            $_POST['ext'] = $request->file('image')->extension();
//        dd($_POST);
            require ('/home/img/update-aws.php');

        }
        else
            $res = array('status' => 'success', 'result' => '1');
        return $res;
    }

    public function getImageUrl($id_img){
        $url = $this->itemImageRepository->getItemImage($id_img);

        if(isset($url))
            return $url->url;
        else
            return '';
    }

}
