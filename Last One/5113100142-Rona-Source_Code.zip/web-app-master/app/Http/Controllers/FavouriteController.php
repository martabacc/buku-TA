<?php

namespace App\Http\Controllers;

use App\Models\Item;
use Illuminate\Http\Request;

class FavouriteController extends Controller
{
    public function fav(Item $item, Request $request)
    {
        return $request->user()->favorites()->attach($item->id);

    }
    public function unfav(Item $item, Request $request)
    {
        return $request->user()->favorites()->detach($item->id);
    }
}
