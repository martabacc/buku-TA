<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;

class TestController extends Controller
{
    //

    public function test(){
        return dd(User::all());
    }

    public function auth(){
        return view('auth.auth')->with('title','Coba Autentikasi');
    }
}
