<?php
/**
 * Created by PhpStorm.
 * User: rona
 * Date: 21/04/2017
 * Time: 12:07
 */

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Tymon\JWTAuth\JWTAuth;

class TokenController extends Controller
{
    private $jwtAuth;

    function __construct(JWTAuth $auth)
    {
        $this->jwtAuth = $auth;
    }

    public function token( )
    {
        if( !Auth::check() )
        {
            return response()->json(['error' => 'Not logged in' , 401]);
        }

        $user = Auth::user();
        $claims = ['name' => $user->name, 'email' => $user->email];
        // Create token from user + add claims data
        $token = $this->jwtAuth->fromUser($user, $claims);
        return response()->json(['token' => $token]);
    }

    public function tokenize()
    {
        if( !Auth::check() )
        {
            return response()->json(['error' => 'Not logged in' , 401]);
        }

        $user = Auth::user();
        $claims = ['name' => $user->name, 'email' => $user->email];
        // Create token from user + add claims data
        return $this->jwtAuth->fromUser($user, $claims);
    }



    public function getUserByToken($token, Request $request)
    {
        try {
            if (! $user = $this->jwtAuth->toUser($token)) {
                return response()->json(['user_not_found'], 404);
            }

        } catch (\Tymon\JWTAuth\Exceptions\TokenExpiredException $e)
        {
            try {
                $newToken = $this->jwtAuth->setRequest($request)
                    ->parseToken()
                    ->refresh();

                $user =  $this->getUserByToken($newToken);

            } catch (TokenExpiredException $e) {
                return response()->json(['token_expired'], $e->getStatusCode());
            } catch (JWTException $e) {
                return response()->json(['token_invalid'], $e->getStatusCode());
            }
        } catch (\Tymon\JWTAuth\Exceptions\TokenInvalidException $e) {

            return response()->json(['token_invalid'], $e->getStatusCode());

        } catch (\Tymon\JWTAuth\Exceptions\JWTException $e) {

            return response()->json(['token_absent'], $e->getStatusCode());

        }
        // the token is valid and we have found the user via the sub claim
        return User::find($user->id);
    }
}