<?php

namespace App\Http\Controllers;

use App\Models\Coupon;
use App\Models\User;
use App\Repositories\BidRepository;
use App\Repositories\CouponRepository;
use App\Repositories\ItemRepository;
use App\Repositories\UserRepository;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Tymon\JWTAuth\JWTAuth;

class CouponController extends Controller
{
    private $couponRepository, $tc;

    function __construct(CouponRepository $couponRepository,
                          TokenController $tokenController)
    {
        $this->couponRepository= $couponRepository;
        $this->tc = $tokenController;
    }


    public function submitCoupon(Request $request)
    {
//        if($request->isMethod('post'))
//        dd($request['bid']);
            $id_bid = $request['bid'];
            $bid = BidRepository::getBidDetail($id_bid);
//            edit adding request whether the coupon is expired

            $user = Auth::user();



//                dd($user);
//                if($user instanceof User)
//                {
//                Checking that bid is won or user is not authorized
//                is done in the function submitCoupon

            $result = $this->couponRepository
                ->submitCoupon(
                    $user
                    , $bid
                    , $request['coupon']
                );
            return response()
                ->json($result);

//                }



//        }
//        abort(400);

    }

    public function couponUsageDetail(Request $request, $idbid)
    {
        return response()->json(CouponRepository::couponUsageDetails($idbid, $request->user()->id));
    }
}
