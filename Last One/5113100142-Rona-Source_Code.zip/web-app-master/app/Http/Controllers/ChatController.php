<?php

namespace App\Http\Controllers;

use App\Repositories\ChatRepository;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\User;

class ChatController extends Controller
{
    private $chatRep;
    function __construct(ChatRepository $chatRepository)
    {
        $this->middleware('auth');
        $this->chatRep = $chatRepository;
    }

    public function getLastMsgDetail(Request $request)
    {
        return
            response()
            ->json(
                ChatRepository::getLastChatDetail(
                    $request->user(),
                    $request['room']
                )
            );
    }
    public function chat($id)
    {
        if(intval($id)){
            $data['from'] = Auth::user()->id;
            $data['to'] = $id;
            $data['user'] = User::findOrFail($id);

            if($data['user']){
                return view('pages.user.chat', $data);
            }
        }

        return redirect('/')->with('error','User yang anda cari tidak dapat ditemukan.');

    }

    public function retrieveInbox($id = false)
    {
//        $id = $request->user()->id;
        $r =  $this->chatRep->conversations(
            $id ?
                User::findOrFail($id) :
                Auth::user()
        );

        return response()
            ->json($r);

    }
}
