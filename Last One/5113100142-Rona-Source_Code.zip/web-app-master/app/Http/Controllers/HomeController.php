<?php

namespace App\Http\Controllers;

use App\Models\Item;
use App\Models\ItemImage;
use App\Repositories\ItemImageRepository;
use Illuminate\Http\Request;
use App\Repositories\ItemRepository;
use Illuminate\Support\Facades\Auth;

class HomeController extends Controller
{

    private $itemRepository, $itemImageRepository;
    function __construct(ItemRepository $itemRepository,
                         ItemImageRepository $itemImageRepository)
    {
        $this->itemRepository = $itemRepository;
        $this->itemImageRepository = $itemImageRepository;
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data['items'] = Item::all()->sortByDesc('updated_at');
        $data['activebid'] = $this->itemRepository->getActiveItem();

        return view('pages.general.landing',$data);
    }

    public function debug()
    {
        dd($this->itemImageRepository->getItemImage(10));
    }

    

}
