<?php
/**
 * Created by PhpStorm.
 * User: rona
 * Date: 08/05/2017
 * Time: 1:45
 */

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use App\Repositories\CategoryRepository;

class CategoryController extends Controller
{
//    this should not use auth middleware

        private $expiration = 60 * 24 * 60 ;//60 days


    public function all(){
        return response()
                ->json(
                    CategoryRepository::all()
                );
    }

    public function top()
    {
        return response()
            ->json(
                CategoryRepository::top()
            );
    }

    public function another()
    {
        return response()
            ->json(
                CategoryRepository::getAnother()
            );
    }
}