<?php

namespace App\Http\Controllers;

use App\Http\Requests\Item\CreateItemRequest;
use App\Http\Requests\Item\UpdateItemRequest;
use App\Models\Item;
use App\Models\Bid;
use App\Models\User;
use App\Repositories\UserRepository;
use App\Services\ItemService;
use Carbon\Carbon;
use App\Repositories\BidRepository;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Repositories\ItemRepository;
use Validator;

class ItemController extends Controller
{

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    private $pageFolder = 'item';
    private $itemRep, $bidRepository;

    function __construct(ItemRepository $itemRep,
                         BidRepository $bidRepository)
    {
        $this->middleware('auth');
        $this->itemRep = $itemRep;
        $this->bidRepository = $bidRepository;
    }

    public function submitwinner(Request $request){
        $id = $request->only('bidx');
        $return = $this->itemRep->setItemWinner($id['bidx']);
        if( !$return | !$return[0] ){

            return redirect()->back()->with('error', is_array($return) ? $return[1] : 'Maaf permintaan anda tidak dapat dilakukan.');
        }
        return redirect('item/'. Bid::find($id)->id_item )->with('success', 'Selamat! Lelang anda sudah selesai.');
    }

    public function index()
    {
        $data['items'] = $this->itemRep->getUserItem();
        return view('pages.'.$this->pageFolder.'.index',$data);
    }

    public function create()
    {
        $data['additionAsset'] = [];
        $data['additionAsset']['js'] = [
            'bootstrap-datetimepicker-master/js/bootstrap-datetimepicker.min.js',
            //'javascript/canvas-to-blob.min.js',
            'javascript/fileinput.js'
            ];
        $data['additionAsset']['css'] = [
            'bootstrap-datetimepicker-master/css/bootstrap-datetimepicker.min.css',
            'css/fileinput.min.css'
            ];
        return view('pages.'.$this->pageFolder.'.create', $data);
    }

    public function store(Request $request)
    {
        $unserialize = $this->unserializeForm($request['data']);
        $unserialize['start_time'] .=':00+00';
        $unserialize['end_time'] .=':00+00';
//        $validate = Validator::make($unserialize, $this->itemRep->rules(), $this->itemRep->messages());

        if(false){
            return ['success'=>false, 'msg' => $validate->messages()];
        }
        else{
            return ['success' => true, 'id' =>  10];
        }
    }

    public function show($id)
    {
        $data['item'] = $this->itemRep->find($id);
        // dd($data);
        if($data['item']->bid_status == 1 )
        {
            $data['currentPrice'] = ItemRepository::getCurrentPrice($id);
        }
        if($data['item']->bid_status == -1 && $data['item']->winner_chosen_status )
            $data['winnername'] = User::find($data['item']->id_user)->name;
        return view('pages.'.$this->pageFolder.'.detail', $data);
    }

    public function edit($id)
    {
        $data['item'] = $this->itemRep->find($id);

        if($data['item']->bid_status==1){
            return redirect()->back()->with('errorItem','Maaf barang yang sedang dilelang tidak dapat diedit!');
        }
        if($data['item']->id_user!=Auth::user()->id){
            return redirect()->back()->with('errorItem','Maaf anda tidak terotorisasi!');
        }

        $data['additionAsset'] = [];
        $data['additionAsset']['js'] = [
            'bootstrap-datetimepicker-master/js/bootstrap-datetimepicker.min.js',
            'javascript/canvas-to-blob.min.js',
            'javascript/fileinput.js',
        ];
        $data['additionAsset']['css'] = [
            'bootstrap-datetimepicker-master/css/bootstrap-datetimepicker.min.css',
            'css/fileinput.min.css',
        ];
        return view('pages.'.$this->pageFolder.'.update', $data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateItemRequest $request, $id)
    {
        if($this->itemRep->find($id)->bid_status==0){
            return redirect('item/'.$id)->with('error','Barang yang sedang dilelang tidak dapat diperbarui');

        }

        $unserialize = $this->unserializeForm($request['data']);

        $unserialize['start_time'] .=':00+00';
        $unserialize['end_time'] .=':00+00';


        $result = $this->itemRep->update($id, $unserialize);

//        $validate = Validator::make($unserialize, $this->itemRep->rules(), $this->itemRep->messages());

        if(false){
            return ['success'=>false, 'msg' => $validate->messages()];
        }
        else{
            return ['success' => true, 'id' =>  10];
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    private function unserializeForm($str) {
        $returndata = array();
        $strArray = explode("&", $str);
        $i = 0;
        foreach ($strArray as $item) {
            $array = explode("=", $item);
            $returndata[$array[0]] = $array[1];
        }

        return $returndata;
    }

    private function parseDate($stringdate, $offset){
        $myDateTime = new DateTime($stringdate.':00');
        $myDateTime->add(-$offset);
        return $myDateTime->format('Y-m-d H:i:s') . '+00';

    }

    public function search(Request $request)
    {
        $data = [];
//        if($request->except('token'))
//        {
            ItemService::find($request->except('_token'));
//        }
        return view('pages.item.search');
    }



}
