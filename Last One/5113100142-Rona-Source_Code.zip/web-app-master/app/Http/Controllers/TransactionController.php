<?php

namespace App\Http\Controllers;

use App\Repositories\TransactionRepository;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class TransactionController extends Controller
{
    private $transactionRepository;
    function __construct(TransactionRepository $transactionRepository)
    {
        $this->middleware('auth');
        $this->transactionRepository = $transactionRepository;
    }

    public function buyout($id)
    {
        $result = $this->transactionRepository
                        ->buyout(Auth::id(),$id);
        if($result){
            return redirect('item/'.$id)
                ->with('success','Sukses membeli barang!');
        }
        else{
            return redirect('item/'.$id)
                ->with('fail','Sukses membeli barang!');
        }
    }
}
