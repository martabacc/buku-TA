<?php

namespace App\Http\Controllers;

use App\Repositories\ChatRepository;
use App\Repositories\UserRepository;
use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Auth;

class UserController extends Controller
{

    private $pageFolder;
    private $userRep;

    function __construct(UserRepository $rep)
    {
        $this->middleware('auth');
        $this->pageFolder = 'pages.user.';
        $this->userRep = $rep;
    }

    public function show($id)
    {
        $data['user'] = $this->userRep->find($id);
        $data['flag'] = (Auth::check() && Auth::user()->id == $data['user']->id) ? true : false;
        return view($this->pageFolder . 'detail', $data);
    }

    public function inbox()
    {
        return view('pages.user.inbox');
    }



}
