<?php

namespace App\Http\Requests\Review;

use Illuminate\Foundation\Http\FormRequest;

class CreateReviewRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'id_user' => 'required|exists:users,id',
            'description' => 'required|min:25',
            'star_count' => 'required|integer|max:5|min:1'
        ];
    }

    public function messages()
    {
        return[
            'id_user:exists' => 'Maaf tapi user tersebut tidak terdaftar!',
        ];
    }
}
