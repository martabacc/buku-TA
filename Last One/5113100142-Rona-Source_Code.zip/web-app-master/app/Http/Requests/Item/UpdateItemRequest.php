<?php

namespace App\Http\Requests\Item;

use Illuminate\Foundation\Http\FormRequest;

class UpdateItemRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'name' => 'required|max:255|min:10',
            'description' => 'required|min:20',
            'start_time' => 'required',
            'end_time' => 'required|after:start_time',
            'starting_price'=> 'required|integer|min:30000',
//            'expected_price'=> 'integer|min:starting_price'
        ];
    }

    public function messages(){
        return [

            'name.required' => 'Nama barang dibutuhkan!',
            'name.max' => 'Nama barang hanya sebatas 255 karakter',
            'name.min' => 'Nama barang minimal harus sepanjang 10 karakter',
            'description.required' => 'Deskripsi barang harus diisi',
            'description.min' => 'Deskripsi barang minimal harus sepanjang 10 karakter',
            'start_time.after' => 'Waktu awal lelang harus setelah waktu sekarang',
            'end_time.after' => 'Waktu akhir lelang harus sesudah waktu awal lelang',
            'starting_price.integer' => 'Harga harus dalam bentuk angka',
            'starting_price.min' => 'Harga minimal harus diatas 30.000',
            'expected_price.integer' => 'Harga harus dalam bentuk angka',
            'expected_price.min' => 'Harga yang ingin dicapai harus diatas harga awal lelang'
        ];
    }
}
