<?php
/**
 * Created by PhpStorm.
 * User: rona
 * Date: 28/11/2016
 * Time: 17:56
 */

namespace App\Repositories;

use App\Models\Bid;
use App\Models\Review;
use App\Models\User;
use DB;
use Validator;


class ReviewRepository
{

    public static function isReviewSubmitted($idbid, $iduser )
    {
        $bid = BidRepository::getBidDetail($idbid);
        $stat = '';

        if($bid->id_user == $iduser ) //as the bidder, rate the auctioneer/seller
        {
            $bool= DB::table('ratingauctioneers')
                        ->where([
                            'id_user_auctioneer'=> $bid->item->id_user,
                            'id_user_rater' => $iduser,
                            'bid_time' => $bid->bid_time
                        ])->count() > 0;
            $stat = 'bidder';
        }
        else if($bid->item->id_user == $iduser ) //as the seller/auctioner, rate the bidder
        {
            $bool= DB::table('ratingbidders')
                    ->where([
                        'id_user_bidder'=> $bid->id_user,
                        'id_user_rater' => $iduser,
                        'bid_time' => $bid->bid_time
                    ])->count() > 0 ;
            $stat = 'seller';
        }
        if(isset($bool)) return [ 'bool' => $bool, 'valid' => $stat ];
        else return ['valid'=>false];

    }

//    public function


    public static function submit(Bid $bid, $information, User $user)
    {
        $constructArray = [
            'rate' => $information[0],
            'rate_message' => $information[1]
        ];

        $validator = Validator::make($constructArray, self::rule(), self::message());

        if ($validator->fails()) {
            return ['valid'=>false, 'msg'=> $validator->errors() ];
        }

        //stting user yang mau dirate as $user2
        if($user->id == $bid->id_user)
        {
            $user2 = $bid->item->user;
            $isBidder = true;
        }
        else if($user->id == $bid->item->user->id){
            $user2 = $bid->user;
            $isBidder = false;
        }

        $constructQuery = [
            'id_user_rater' => $user->id,
            'nama_user_rater' => $user->name,
            'rate' => $constructArray['rate'],
            'rate_message' => $constructArray['rate_message'],
            'id_item' => $bid->id_item,
            'bid_time' => $bid->bid_time
        ];

//        merge with

        if($isBidder)
            array_merge($constructQuery,
                ['id_user_auctioneer'=> $user2->id, 'nama_user_auctioneer' => $user2->name]);
        else
            array_merge($constructQuery,
                ['id_user_bidder'=> $user2->id, 'nama_user_bidder' => $user2->name]);

        $id = DB::table( $isBidder ? 'ratingauctioneers' : 'ratingbidders')
                ->insertGetId($constructQuery);

        if($id) return ['valid' => true];
            else return ['valid' => false, 'msg' => 'Maaf kesalahan server, silahkan coba lagi'];

    }

    private static function rule()
    {
        return[
                'rate' => 'required|between:1,5',
                'rate_message' => 'nullable|max:255'
            ];
    }
    private static  function message()
    {
        return[
            'rate.required' => 'Rating harus diisi',
            'rate.between' => 'Nilai rating harus berada diantara 1 & 5'
        ];
    }


}