<?php
/**
 * Created by PhpStorm.
 * User: rona
 * Date: 28/03/2017
 * Time: 22:08
 */

namespace App\Repositories;

use App\Models\Coupon;
use App\Models\Item;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class CouponRepository
{
    private $defaultErrorMsg, $defaultSuccessMsg;
    function __construct()
    {
        $this->defaultErrorMsg = 'Maaf kupon yang anda masukkan tidak valid/tidak berlaku';
        $this->defaultSuccessMsg = 'Sukses , kupon yang anda masukkan berlaku.';
    }

    public function submitCoupon( $user, $bid,
                                            $user_facing_coupon)
    {
//        if( $bid->user_id != $user->id || !$bid->win_status )
//            throw new \Exception('Request Invalid! Coba Refresh Halaman');


        $dt = Carbon::now();
        DB::beginTransaction();


        $coupon = DB::table('coupon')
                          ->where(
                              'customerfacingcoupon',$user_facing_coupon)->lockForUpdate()->first();


        if(!$coupon || ($coupon->id_user!=null && $user->id!=$coupon->id_user) ){
            DB::rollback();
            return ['status'=>false, 'msg' => 'Maaf kupon yang anda masukkan tidak dapat digunakan.'];
        }

        if(DB::table('coupon_usages')
                    ->where([  'id_user'=>$user->id,
                                'id_item' => $item->id,
                                'id_item_time'=>$item->bid_time,
                                'id_coupon'=> $coupon->coupon_id])->first())
        {
//            duplicated usage
            DB::rollback();
            return ['status'=>false, 'msg' => 'Maaf kupon yang anda masukkan sudah pernah anda gunakan'];
        }


        DB::table('coupon')
            ->where('coupon_id',$coupon->coupon_id)
            ->decrement('usages');

        //updating price
        $coupon_usage = DB::table('coupon_usages')
            ->insertGetId([  'id_user'=>$user->id,
                            'id_item' => $bid->id,
                            'id_item_time'=>$item->bid_time,
                            'id_coupon'=> $coupon->coupon_id,
                            'price_after' => ($coupon->free_shipping ? -1 : ((1-$coupon->price) * $item->bid_price) )]);

        DB::table('items')->where('id',$item->id)->update(['id_coupon_usage'=>$coupon_usage]);

        if(DB::table('coupon')->where('coupon_id',$coupon->coupon_id)->first()->usages<0) {
            //race condition
            DB::rollback();
            return ['status'=>false, 'msg' => "Maaf kupon yang anda masukkan tidak valid" ];
        }
        else {
//            no problemo
            DB::commit();
            return ['status'=>true, 'new_price' => $coupon->free_shipping ? -1 : ((1-$coupon->price) * $item->bid_price)  ];
        }

    }


    public static function isCouponSubmitted($idbid, $iduser)
    {
        $bid = BidRepository::getBidDetail($idbid);

        //first check winning status / user authorization
        if( $bid->id_user!=$iduser || !$bid->win_status ) return ['valid'=>false];


        return DB::table('coupon_usages')
                ->where([
                    'id_user'=> $iduser,
                    'id_item' => $bid->id_item,
                    'id_item_time'=> $bid->bid_time
                ])
                ->count() > 0;
    }

    public static function couponUsageDetails($idbid, $iduser){

        $bid = BidRepository::getBidDetail($idbid);
        if( $bid->id_user!=$iduser || !$bid->win_status ) return ['valid'=>false];

        $coupon =  DB::table('coupon')
                       ->where('coupon_id' ,
                                    (DB::table('coupon_usages')
                                    ->where([
                                        'id_user'=> $iduser,
                                        'id_item' => $bid->id_item,
                                        'id_item_time'=> $bid->bid_time
                                    ])->first(['id_coupon']))->id_coupon)->first(['customerfacingcoupon','free_shipping','price']);

        $q = "Anda sudah menggunakan kupon " . $coupon->customerfacingcoupon
                . ($coupon->free_shipping ? " untuk promo <i> Free Shipping</i>" :
                                            (" dan mendapat diskon sebesar " . $coupon->price*100 . "%" ) ) . " untuk barang ini.";

        return ['valid'=>true, 'msg'=>$q ];


    }



}