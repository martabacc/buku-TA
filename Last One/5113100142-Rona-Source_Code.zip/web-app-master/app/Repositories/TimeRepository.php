<?php
/**
 * Created by PhpStorm.
 * User: rona
 * Date: 28/11/2016
 * Time: 17:56
 */

namespace App\Repositories;

use DB;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;

class TimeRepository
{
    public function returnToCarbon($date){
    	$ptr = true;
    	dd($date);
    	if(strpos($date, '+')){
    		$time = explode("+",$date);
    		$ptr = false;
    	}
    	else 
    		$time = explode("-",$date);

    	$carbon = Carbon::parse($time[0]);
    	if($ptr){
    		$carbon->subHours((int)$time[1]);
    	}
    	else $carbon->addHours((int)$time[1]);

    	return $carbon;
    }
}