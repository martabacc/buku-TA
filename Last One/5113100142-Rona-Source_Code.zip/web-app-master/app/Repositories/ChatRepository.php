<?php
/**
 * Created by PhpStorm.
 * User: rona
 * Date: 05/05/2017
 * Time: 1:32
 */

namespace App\Repositories;


use App\Models\Chatroom;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use MongoDB\BSON\UTCDateTime;

//use MongoDB\BSON\UTCDateTime;

class ChatRepository
{
    private $chatroom;
    function __construct(Chatroom $chatroom)
    {
        $this->chatroom = $chatroom;
    }

    public function conversations(User $user)
    {
        $this->chatroom->setIdComp($user->id);
         return $this->chatroom->where('id_user_1',strval($user->id))
                                ->orWhere('id_user_2',strval($user->id))
                                ->with('friend')
                                ->orderBy('updatedAt','desc')
                                ->get();
    }

    public static function getLastChatDetail(User $user, $room)
    {
        $res = DB::connection('mongodb')
                ->collection('userchat')
                ->where('room', $room)
                ->orderBy('sent','desc')
                ->first(['msg','sender','sent']);

        $partner = explode("-", $room);
        $partner = $partner[0] != $user->id ? $partner[0] : $partner[1];
//        get dat url
//        $partner = "https://lelangapa.com/chat/" + $partner;
        return ( [
            'msg' => $res['msg'],
            'sent' => $res['sent'] ?
                        (new Carbon($res['sent']->toDateTime()->format('r')))->diffForHumans() : "Unknown",
            'partner' => $partner,
            'isSender' => $res['sender'] == $user->id
        ]);

    }

}