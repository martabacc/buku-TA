<?php
/**
 * Created by PhpStorm.
 * User: rona
 * Date: 08/03/2017
 * Time: 13:30
 */

namespace App\Repositories;


use App\Models\ItemImage;

class ItemImageRepository
{
    public function getItemImage($id)
    {
        return ItemImage::where('item_id', strval($id))->first();
    }

    public function uploadImage($data)
    {
        /*THE DATA SHOULD BE FILTERED FIRST*/
        require ('/home/img/upload-test.php');
    }

    public function updateImage($data)
    {
        /*THE DATA SHOULD BE FILTERED FIRST*/
        require ('/home/img/update-aws.php');
    }

}