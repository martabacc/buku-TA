<?php
/**
 * Created by PhpStorm.
 * User: rona
 * Date: 21/07/2017
 * Time: 0:30
 */

namespace App\Repositories;


use App\Models\Item;
use Illuminate\Support\Facades\DB;

class TransactionRepository
{
    public function buyout($id_user, $id)
    {

        $stringExecute = "SELECT public.buy_now_option(".$id_user.",
                            ".$id.")";
        $result = DB::select($stringExecute);

        return $result[0]->buy_now_option;
    }

    public static function priceSuggestion($id_item)
    {
        $stringExecute = "select price_bid
                            from bids
                            where id_item=". $id_item. "
                            order by price_bid desc
                            limit 3";
        $item = Item::findOrFail($id_item);
        $adding = 0;

        $incr = ItemRepository::getCurrentPrice($id_item)->bid_price;
        $result = DB::select($stringExecute);


        if($result == []){
            return [
                1.1*$item->starting_price,
                1.2*$item->starting_price
            ];
        }
        if(isset($result[1]) && isset($result[2]))
        {
            $adding = (($result[0]->price_bid - $result[1]->price_bid) + ($result[1]->price_bid - $result[2]->price_bid))/2;
            return[
                ($adding)+$incr,
                (2*$adding)+$incr,
            ];
        }
        if(!isset($result[2]))
        {
            $adding =  $result[0]->price_bid - $result[1]->price_bid;
            return[
                ($adding)+$incr,
                2*$adding+$incr,
            ];
        }
    }
}