<?php
/**
 * Created by PhpStorm.
 * User: rona
 * Date: 28/11/2016
 * Time: 17:56
 */

namespace App\Repositories;

use App\Models\Bid;
use DB;
use Illuminate\Support\Facades\Auth;

class BidRepository
{
	public function getHistoryBid($id){
        $stringExecute = "SELECT MAX(b.id) as bid_id_r, b.id_item, b.id_user, u.name, i.name,
							i.bid_status, b.bid_time, b.win_status, MAX(b.price_bid) as price_bid ,MAX(b.bid_timestamp)
							FROM bids b
							left JOIN users u ON u.id = b.id_user
							left JOIN items i ON i.id = b.id_item
							WHERE b.id_user = ".Auth::user()->id."
							GROUP BY b.id_item, b.id_user, u.name, i.name, i.bid_status, b.bid_time,
							b.win_status
							ORDER BY bid_id_r DESC;";

        $result = DB::select($stringExecute);
        return $result;
	}

	public function getItemHistoryBid($id_item, $bid_time)
	{
		$stringExecute = 'select price_bid, users.name, bids.id_user , bids.id, bids.bid_timestamp
							from bids
							left join users on users.id = bids.id_user
							where bids.id_item = '.$id_item.'
							and bids.bid_time = '.$bid_time.'
							order by bids.bid_timestamp desc';
		$result = DB::select($stringExecute);

		return $result;
	}

	public static function getBidDetail($idbid){
	    return Bid::findOrFail($idbid);
    }


    public function getPriceRecomendation()
    {
        $latest3Bid = $this->get3LatestBid();
        dd($latest3Bid);
    }

    private function get3LatestBid()
    {
        $sstringExecute = "select limit 3 * from bids".
                          "order by bid_timestamp desc";

        $result = DB::select($sstringExecute);
        return $result;
    }
	

}