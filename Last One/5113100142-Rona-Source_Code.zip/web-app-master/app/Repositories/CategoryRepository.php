<?php
/**
 * Created by PhpStorm.
 * User: rona
 * Date: 08/05/2017
 * Time: 1:48
 */

namespace App\Repositories;


use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;

class CategoryRepository
{

    private $minutes = 60 * 24 * 60; //assumed 60 days expiration

    public static function all()
    {
        return  Cache::remember('categories', $this->expiration, function()
        {
            return DB::table('categories')
                ->get();
        });
    }

    public static function top()
    {
        return  Cache::remember('categories', $this->expiration, function()
        {
            return DB::table('categories')
                ->take(5)
                ->get();
        });
    }

    public static function getAnother()
    {
        return  Cache::remember('categories', $this->expiration, function()
        {
            return DB::table('categories')
                ->skip(5)
                ->get();
        });
    }


}