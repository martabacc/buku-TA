<?php
/**
 * Created by PhpStorm.
 * User: rona
 * Date: 28/11/2016
 * Time: 17:56
 */

namespace App\Repositories;

use App\Models\Item;
use DB;
use Illuminate\Support\Facades\Auth;


class ItemRepository
{

    public function rules()
    {
        return [
            'name' => 'required|max:255|min:10',
            'description' => 'required|min:20',
            'start_time' => 'required|date|after:now',
            'end_time' => 'required|date|after:start_time',
            'starting_price'=> 'required|integer|min:30000',
            'expected_price'=> 'integer'
        ];
    }

    public function messages(){
        return [

            'name.required' => 'Nama barang dibutuhkan!',
            'name.max' => 'Nama barang hanya sebatas 255 karakter',
            'name.min' => 'Nama barang minimal harus sepanjang 10 karakter',
            'description.required' => 'Deskripsi barang harus diisi',
            'description.min' => 'Deskripsi barang minimal harus sepanjang 10 karakter',
            'start_time.after' => 'Waktu awal lelang harus setelah waktu sekarang',
            'end_time.after' => 'Waktu akhir lelang harus sesudah waktu awal lelang',
            'starting_price.integer' => 'Harga harus dalam bentuk angka',
            'starting_price.min' => 'Harga minimal barang adalah 30.000',
            'expected_price.integer' => 'Harga harus dalam bentuk angka',
            'expected_price.min' => 'Harga yang ingin dicapai harus diatas harga awal lelang'
        ];
    }

    public function create($data)
    {
        $stringExecute = "SELECT public.insert_items(".Auth::user()->id.",'"
                .$data['name']."','".$data['description']."',"
                .$data['starting_price'].",".$data['expected_price'].",'"
                .$data['start_time']."','".$data['end_time']."')";

        $result = DB::select($stringExecute);

        if($result) return $result[0]->insert_items;
    }

    public function findAll(){
        return Item::all()->sortByDesc('end_time');
    }

    public static  function find($id){
        return Item::findOrFail($id);
    }

    public function getUserItem(){
        return Auth::user()->item()->orderBy('end_time','desc')->get();
    }

    public function getActiveItem()
    {
        /*
         * Getting item ids first
         * then map it with base model laravel
         * to array of models*/

        $result =  [];
        foreach(DB::select('SELECT public.get_active_bidding_item()') as $x){array_push($result, (int)$x->get_active_bidding_item);
        }

        $models = Item::findOrFail($result);
        return $models;
    }

    public function delete($id){
        $item = $this->find($id);
        $item->delete();
    }

    public function update($id, $data)
    {
        // yang bisa diedit yang belum mulai & sudah selesai tp blm dihapus

        $stringExecute = "SELECT public.update_items(".$id.",'"
                .$data['name']."','".$data['description']."',"
                .$data['starting_price'].",".$data['expected_price'].",'"
                .$data['start_time']."','".$data['end_time']."')";

        $result = DB::select($stringExecute);

        return $result[0]->update_items;

        
        // $item = $this->find($id);
        // $item->update($data);
    }

    public static function getCurrentPrice($id){
        try{
            $result = DB::select('select items_cached.bid_price, items_cached.id_user, users.name
                    from items_cached, users
                    where items_cached.id_user = users.id
                    and items_cached.id =' . $id);
            return $result[0];
        }
        catch(\Exception $e){
            $result =  DB::select('select items.bid_price, items.id_user, users.name
                    from items, users
                    where items.id_user = users.id
                    and items.id =' . $id);
            return $result[0];
        }
    }

    public function setItemWinner($id)
    {
        $bid = \App\Models\Bid::findOrFail($id);

        if(!$bid) 
            return [false,'Penawaran tersebut tidak tersedia.'];


        $item = $this->find($bid->first()->id_item);

        if( !$item | $item->delete_status ){
            return [false,'Barang sudah dihapus!'];
        }
        elseif ($item->cancel_status) {
            return [false,'Barang sudah dicancel!'];
        }
        elseif ($item->winner_chosen_status) {
            return [false,'Barang sudah dicancel!'];
        }
        else{
            $stringExecute = "SELECT public.stop_and_select_bidder_winner(".$id.")";
            $result = DB::select($stringExecute);

            return $result[0]->stop_and_select_bidder_winner;
        }
    }

    public static function getDashboardDetail($id)
    {
        /*
         * returning json with these criteria:
         * "price_now" => , "bid_count" =>
         * */
        $strBidCount = 'select count(*) as jumlah from bids where bids.id_item='. $id;
        $result = DB::select($strBidCount)[0]->jumlah;
        $name = Item::find($id)->name;
        return response()
                ->json([ "price_now" => self::getCurrentPrice($id), "name" => $name,"bid_count" => $result ]);
    }

}