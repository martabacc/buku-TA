<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Announcement extends Model
{
    //
    protected $table = 'announcements';
    protected $primaryKey = 'id';
    public $incrementing = true;
    public $timestamps = true;

    protected $fillable =
        [   'title',
            'description',
            'start_time',
            'end_time',
            'html_code',
            'created_at',
            'updated_at'];

    
}
