<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UserIssue extends Model
{
    protected $table = 'userissues';
//    protected $primaryKey = 'id_issue';
    public $incrementing = true;
    public $timestamps = false;

    protected $fillable =
        [  'id_user',
            'id_issued_user',
            'description'];

    public function user(){
        return $this->belongsTo('App\Models\User','id_user');
    }

    public function issued_user(){
        return $this->belongsTo('App\Models\User','id_issued_user','id_user');
    }
}
