<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;

class Item extends Model
{
    protected $table = 'items';
    protected $primaryKey = 'id';
    public $incrementing = true;

    protected $fillable =
        [   'name',
            'description',
            'start_time',
            'end_time',
            'id_user',
            'bid_status',
            'starting_price',
            'expected_price',
            'id_user_winner', 
            'winner_chosen_status',
            'delete_status', 'cancel_status',
            'winning_status'
        ];
    public $timestamps = false;


    public function user(){
        return $this->belongsTo('App\Models\User', 'id_user');
    }

    public function isDeleted(){
        return $this->delete_status == true;
    }

    //1 sedang mulai, 0 blm dimulai, -1 selesai


    public function favorites()
    {
        return $this->belongsToMany('App\Models\User','favorites','id_item_favorite','id_user');
    }

    public function favorited()
    {
        return (bool) Favourite::where('id_user', Auth::user()->id)
                                ->where('id_item_favorite', $this->id )
                                ->first();
    }



}
