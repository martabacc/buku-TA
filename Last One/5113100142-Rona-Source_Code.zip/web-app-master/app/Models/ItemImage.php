<?php

namespace App\Models;

use Moloquent;

class ItemImage extends Moloquent
{

    protected $connection = 'mongodb';
    protected $collection = 'itemimages';

}
