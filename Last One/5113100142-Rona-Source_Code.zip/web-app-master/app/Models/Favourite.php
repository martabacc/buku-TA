<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Favourite extends Model
{

    protected $table = 'favorites';
    protected $primaryKey = 'id';
    public $incrementing = true;

    protected $fillable =
        [
            'id_user',
            'id_item_favorite'
        ];
    public $timestamps = false;
}
