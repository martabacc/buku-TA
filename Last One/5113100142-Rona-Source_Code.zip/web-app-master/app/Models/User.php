<?php

namespace App\Models;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Jenssegers\Mongodb\Eloquent\HybridRelations;
class User extends Authenticatable
{
    use Notifiable, HybridRelations;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $connection = 'pgsql';
    protected $tables = 'users';
    protected $primaryKey = 'id';

    protected $fillable = [
        'name', 'email', 'password','address','verification', 'is_banned','id_image','phone','id_city','id_province',
        'username'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    public $incrementing = true;
    protected $hidden = [
        'password', 'remember_token',
    ];
    public $timestamps = true;
    public $timestamp = [ 'verification', 'is_banned' ];

    public function item(){
        return $this->hasMany('App\Models\Item','id_user');
    }

    public function codeusage(){
        return $this->hasMany('App\Models\Item','id_user');
    }

    public function issued(){
        return $this->hasMany('App\Models\Issue','id_issued_user');
    }

    public function isVerified()
    {
        return $this->verification == null;
    }

//    defining favorited items by user
    public function favorites()
    {
        return $this->belongsToMany('App\Models\Item','favorites','id_user','id_item_favorite');
    }

    public function senderRooms()
    {
        return $this->hasMany('App\Models\Chatroom','id_user_1');
    }
    public function receiverRooms()
    {
        return $this->hasMany('App\Models\Chatroom','id_user_2');
    }

    public function rooms()
    {
        return collect($this->senderRooms())
                ->merge(
                    collect($this->receiverRooms())
                )->all();
    }


}
