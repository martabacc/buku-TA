<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Rating extends Model
{
    protected $table = 'reviews';
    protected $primaryKey = 'id';
    public $incrementing = true;

    protected $fillable =
        [   'id_user',
            'id_reviewer',
            'description',
            'star_count'];


    public function user(){
        return $this->belongsTo('App\Models\User','id_user');
    }

    public function reviewer(){
        return $this->belongsTo('App\Models\User','id_reviewer');
    }

    public $timestamps = false;
}
