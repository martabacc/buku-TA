<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Bid extends Model
{
	protected $table = 'bids';
    protected $primaryKey = 'id';
    public $incrementing = true;
    public $timestamps = false;

    protected $fillable =
        [
              'id_user',
              'id_item',
              'price_bid',
              'win_status',
              'bid_timestamp',
              'bid_time',
              'is_cancelled',
        ];

    public $timestamp = ['bid_timestamp'];

    public function item(){
        return $this->belongsTo('App\Models\Item', 'id_item');
    }

    public function user(){
        return $this->belongsTo('App\Models\User', 'id_user');
    }
}
