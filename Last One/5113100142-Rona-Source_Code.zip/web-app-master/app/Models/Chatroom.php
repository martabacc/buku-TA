<?php

namespace App\Models;

use Moloquent;

class Chatroom extends Moloquent
{

    protected $connection = 'mongodb';
    protected $collection = 'chatroom';


    public function friend()
    {
        return $this->belongsTo('App\Models\User',
                        $this->comp == $this->id_user_1 ?
                            'id_user_1' : 'id_user_2'
                    )
                    ->select(['id','name']);
    }

    public function setIdComp($id)
    {
        $this->comp = $id;
    }


}
