<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Issue extends Model
{
    protected $table = 'issues';
//    protected $primaryKey = 'id_issue';
    public $incrementing = true;
    public $timestamps = false;

    protected $fillable =
        [   'id_issue_type',
            'id_user',
            'id_issued_object',
            'issue_status',
            'description',
            'resolve_status',
            'resolve_description'];

    public function user(){
        return $this->belongsTo('App\Models\User');
    }

    public function item(){
        return $this->belongsTo('App\Models\Item','id_issued_object','id');
    }

    public function issuetype(){
        return $this->belongsTo('App\Models\IssueType','id_issue_type');
    }


}
