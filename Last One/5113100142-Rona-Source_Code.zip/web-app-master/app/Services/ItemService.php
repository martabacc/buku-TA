<?php
/**
 * Created by PhpStorm.
 * User: rona
 * Date: 18/05/2017
 * Time: 18:44
 */

namespace App\Services;


use App\Models\Item;

class ItemService
{

    private  static  $itemMap = [
            'key' => 'name',
            'st' => 'start_time',
            'en' => 'end_time'
        ];


    public static function find($key)
    {
        $map = self::itemMap;

        foreach($key as $index => $val )
        {
            $key[$map[$index]] = $val;
            unset($key[$index]);//efficiently using memory
        }



    }


}