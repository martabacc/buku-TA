<?php

Route::group(['prefix'=>'admin'], function(){
    Route::get('login','AdminAuthController@login');
    Route::resource('announce','AnnouncementController');
});