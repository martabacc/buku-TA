    <?php


    Route::get('/','HomeController@index');
    Route::get('ajax/categories','AjaxController@getCategory');

    Route::get('ajax/item/snap/{id}', 'AjaxController@getItemProperties');
    Route::get('ajax/bid/top3/{id}','AjaxController@topThree');
    Auth::routes();
    Route::get('ajax/getitembidlist/{id}', 'AjaxController@getBidItemDetail');


//    item management
    Route::resource('item','ItemController');
    Route::post('item/{id}','TransactionController@buyout');
    Route::get('item/suggest/{id}','AjaxController@suggestion')->name('price.suggestion');


    Route::group(['prefix'=>'user'], function(){
       Route::get('{id}', 'UserController@show')->name('user.show');
       Route::post('{id}', 'ReviewController@add')->name('review.add');
    });

    Route::get('choosewinner/{id}', 'BidController@pickWinner');
    Route::get('bidhistory', 'BidController@userHistory');
    Route::get('bidhistory/status/{bid}', 'BidController@getStatus');

    Route::post('submitwinner', 'ItemController@submitWinner');
    Route::get('itembidhistory/{id}', 'BidController@itemBidHistory');
    Route::get('user/activation/{token}', 'Auth\RegisterController@activateUser')->name('user.activate');

    Route::group(['prefix'=>'ajax/report/'], function(){
    Route::post('user', 'IssueController@user')->name('report.user');
    Route::post('item', 'IssueController@item')->name('report.item');
    Route::get('types', 'IssueController@types')->name('report.types');
});

Route::post('ajax/image/itemUpload', 'ImageController@uploadItemImage')->name('uploadimage');
Route::post('ajax/image/itemUpdate', 'ImageController@updateItemImage')->name('item.updateimage');

Route::group(['prefix'=>'ajax/coupon/'], function(){
    Route::post('check/{coupon}', 'CouponController@check')->name('coupon.check');
    Route::post('submit', 'CouponController@submitCoupon')->name('coupon.submit');
    Route::any('usages/{idbid}', 'CouponController@couponUsageDetail');
});

Route::post('sendMail', 'Auth\RegisterController@sendActivationMail');
Route::get('token', 'TokenController@token')->name('tokenreq');

Route::get('search/i','ItemController@search')->name('item.search');

Route::group( [], function(){
//    this groups all routes that is consumed by vue components
//    refactored later after knows the base practices on using vue

    Route::group(['prefix'=>'ajax/favourite/'], function(){
        Route::post('{item}', 'FavouriteController@fav')->name('fav.add');
        Route::post('un/{item}','FavouriteController@unfav')->name('fav.remove');
    });

    //chatting
    Route::get('chat/{id}', 'ChatController@chat')->name('chat.user');
    Route::get('inbox', 'UserController@inbox');
    Route::get('inbox/data', 'ChatController@retrieveInbox');
    Route::post('inbox/lastDetail','ChatController@getLastMsgDetail');

    //categories
    Route::group(['prefix'=>'cat'], function(){
        Route::get('/', 'CategoryController@all');
        Route::get('top', 'CategoryController@top');
        Route::get('other', 'CategoryController@another');
    });

    //item image find first id
    Route::group(['prefix'=>'get/img/item'], function(){
        Route::get('{id}', 'ImageController@getImageUrl');
    });

});


Route::group(['prefix'=> 'review'], function(){
    Route::any('submit/{id_bid}', 'ReviewController@submit');
});

/*  sorry to define here
    later moved to another structured file. todo !
*/
define('SERVER_IP', config('app.url') );
define('BID_SERVER', 'https://bidding.lelangapa.com' ) ;
define('CHAT_SERVER', 'https://chatting.lelangapa.com' );
define('IMG_SERVER', config('app.imgurl') );

//ini buat bidding. masukin di src
define('BID_SERVER_SOCKET_URL', 'https://bidding.lelangapa.com');
define('CHAT_SERVER_SOCKET_URL', 'https://chatting.lelangapa.com');
